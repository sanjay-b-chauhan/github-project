# Edit styles for "Edits": a field guide with numbers

Research for Edits, a tool that lets anyone brief Claude to make After Effects quality motion in code (HTML/GSAP, HyperFrames, Remotion, three.js). Compiled 27 Oct 2026 from web sources plus three measured open-source studies of professional motion. Read-only research: nothing downloaded, installed or paid for.

## 0. How to read this

**Two kinds of numbers.** Every number is tagged.
- **[V]** verified: it comes from a named source in the Sources list (a creator, studio, standard, or a measured study).
- **[WD]** working default: a craft range I am giving you to build with. It is consistent with the measured studies below but is not a quoted measurement. Treat it as a starting value for a lint rule or a preset, then tune by eye.

Where a source is a vendor blog or a secondary write-up, the text says so. Where I could not verify something the brief asked for, the text says that too.

**Name collision, flag first.** Meta already ships a video editor called **Edits** (Instagram's CapCut rival, announced by Adam Mosseri in January 2025, live on iOS and Android on 22 April 2025, with auto captions, background replacement, no watermark and 4K export) [V: Social Samosa, PhoneArena, Android Authority]. "Edits" as a product name will fight Meta for search and app store results. Worth a trademark check before launch.

**Frame math (use everywhere).**

| Time | f @ 24 | f @ 30 | f @ 60 |
|---|---|---|---|
| 1 frame | 41.7 ms | 33.3 ms | 16.7 ms |
| 0.1 s | 2.4 | 3 | 6 |
| 0.2 s | 4.8 | 6 | 12 |
| 0.333 s | 8 | 10 | 20 |
| 0.5 s | 12 | 15 | 30 |
| 1 s | 24 | 30 | 60 |

Frames per beat = fps x 60 / BPM. At 30 fps: 90 BPM = 20 f, 100 = 18 f, 120 = 15 f, 128 = 14.06 f, 140 = 12.86 f, 150 = 12 f, 174 = 10.34 f. At 60 fps double those. Tempos that do not divide evenly drift; round cut frames per beat from the absolute beat time (beat_n x 60/BPM x fps), never by adding a rounded beat length repeatedly.

**Measured baselines from professional motion (the anchor for every [WD]).** Three open studies measured real films frame by frame:

1. **motionmaxxing** (github.com/Tejashmakwana/motionmaxxing, Apache-2.0, 1.1k stars): 53 frame-accurate "pro moments", about 4,288 distinct moves, 12 measured eases [V]. Headline findings [V]:
   - Median move 10 f at 30 fps (0.33 s). Histogram: 2 f 8%, 3 f 5%, 4 to 5 f 13%, 6 to 8 f 18%, 9 to 12 f 15%, 13 to 18 f 14%, 19 to 30 f 15%, 31 to 60 f 10%, 61+ f 2%.
   - Default entry durations: translate and scale 12 f, opacity 6 f, blur 7 f; exits 13 to 14 f for translate, 10 f for scale; p25 to p75 edges 6 f and 24 f.
   - Pros use 3,392 transform entries versus 584 opacity fades. About 96% of moments use hard cuts. In 3 to 7 s moments, something moves on about 99% of frames.
   - Sibling stagger: median 3 f between onsets (p25 to p75: 1 to 5 f). Letters and tiles 1 f apart; whole words 2 to 5 f (8 to 12 f when voice-led); CTA stacks widen to about 8 f.
   - Overshoot: 88% peak after 35% of the duration (median t = 0.65 to 0.70), a slow lean of 15 to 24 f, not a fast spring. Recommended "popOver": peak 1.08 at t = 0.72 over 15 f, at most once per beat.
   - Landings ease out (60 to 72% of travel in the first 4 f); exits accelerate and end at peak speed.
   - Drift moves: median 26 f, about 2.5 px/f on a 1280x720 stage, scale about 1.16x.
2. **echris6/motion-video-kit** (`business-motion-film`, MIT): 28 SaaS launch films, 48 minutes, 81,647 frames analysed [V]. Pacing for a 30 s business film: 12 to 15 compositions; beats 1.4 to 3.5 s; no motionless stretch longer than about 0.6 s; frame 0 is a finished composition; reading holds only on report and CTA frames with a slow 3 to 5% push; end card about 1.5 to 2 s readable. Lead subject fills 60 to 85% of the usable frame in feature beats; 1 to 2 reading targets at once.
3. **HyperFrames internal craft skills** (github.com/heygen-com/hyperframes, `.claude/skills/cut-the-curve`, Apache-2.0) [V]: partial travel about 12% of frame (about 230 px at 1920) instead of full off-screen moves; mirrored eases across a cut (exit `power4.in`, entry `power4.out`, same distance and duration, so velocity matches at the cut); blur scaled to subject: 10 px for text, 18 to 20 px only for full-frame; group slides as a three-phase "nudge": 10% ramp-in (`power3.in`), 65% linear burst, 25% `power4.out` tail.

**Loudness targets.** EBU R128: -23 LUFS integrated, -1 dBTP true peak (broadcast); EBU's streaming supplement allows -18 LUFS, -16 for music-heavy content. YouTube, Spotify, Tidal and Amazon Music normalise to about -14 LUFS, and YouTube only turns loud content down, never quiet content up [V: EBU R128 summary on Wikipedia]. Ship social video at -14 LUFS, -1 dBTP [WD]. motionmaxxing's mix defaults: music ducks -9 dB under voice with an 80 ms attack and 300 ms release; SFX peak-normalised to -3 dBFS before mixing; clear the music 8 to 15 dB for 0.2 to 0.5 s before the biggest move [V].

**Flash safety (applies to styles 1, 4, 12 and to flash frames).** WCAG 2.3.1: no more than 3 general flashes and/or 3 red flashes in any one second, unless the combined flashing area is under 0.006 steradians (25% of a 10 degree field, about 341 x 256 px at 1024 x 768). A general flash is a pair of opposing changes in relative luminance of 10% or more where the darker state is below 0.80; a red flash involves saturated red (R/(R+G+B) >= 0.8) [V: W3C]. The UK ITC/Ofcom note uses 20 cd/m² changes where the darker image is below 160 cd/m², counts transitions to or from saturated red as harmful regardless of luminance, requires more than 25% of the screen to change, and warns that flashing sequences over 5 seconds may be a risk even when compliant [V: Ofcom gn_flash.pdf, ASA Citroën ruling]. Build this into the renderer as a lint: compute mean luminance per frame over a grid of 341x256 windows and fail any window with more than 3 opposing transitions per second.

---

## 1. Hook and viral short-form cuts

**What.** Vertical 9:16 edits engineered for the first 1 to 3 seconds and for minute-by-minute retention: pattern interrupts, word-synced captions, constant visual change.

**When.** Reels, TikTok, Shorts; ads; any clip judged by the swipe. YouTube Shorts can run 3 minutes since October 2024, Instagram Reels 3 minutes since January 2025 [V: Social Media Today, Storyboard18], but the format still lives in the first seconds.

**Exemplars.**
- **MrBeast** (youtube.com/@MrBeast). His leaked 36-page onboarding handbook "How to Succeed in MrBeast Production" (posted by Rosanna Pansino, August 2024; authenticity confirmed to Passionfruit by two former producers, not by MrBeast) [V]: the process starts with title and thumbnail; the first minute must prove the thumbnail's promise; the example says losing 21 million of 60 million initial clickers in the first minute is "a reasonably good result"; minutes 1 to 3 and 3 to 6 each have defined jobs; a "wow factor" ideally early (in "100 Days in the Circle" a house arrives by crane about 30 seconds in) [V: Simon Willison, Tubefilter, Creator Handbook]. A German summary (OMR) describes a re-engagement beat roughly every three minutes [V, secondary].
- **Alex Hormozi** (youtube.com/@AlexHormozi). Captions are the style: uppercase, word by word, key word highlighted in yellow. Submagic documents two eras: older captions in TheBoldFont, uppercase with shadow and no stroke; newer ones in Anton, uppercase, slight shadow, yellow stroke, pop-in from bottom to top [V: Submagic]. Choppity measures his cuts every 1 to 3 seconds [V: Choppity, vendor analysis].
- **Ali Abdaal** (youtube.com/@aliabdaal). Choppity's analysis of his Shorts: 2 to 5 s per shot, cuts at thought transitions; mostly greyscale grade with yellow as the only accent (also on highlighted caption words); captions phrase by phrase beside the speaker, not over him; medium framing slightly wider than Hormozi's, subject off-centre to leave caption room; hook (question or reframe) inside 10 s; lo-fi music barely audible [V: Choppity, vendor analysis].
- **Iman Gadzhi** (youtube.com/@ImanGadzhi). No primary breakdown exists. Everything published is freelancer listings describing "fast cuts, bold text, dynamic zooms, motion graphics, cinematic grade" [V that this is how the market describes it; not a verified description of his own edit].
- **Dan Koe** (youtube.com/@DanKoeTalks). No verified breakdown found; listings only ask for "Dan Koe style" in After Effects. Observable on his channel: slow essay pacing, dark or monochrome frames, sparse text, ambient bed. Treat as unverified.

**2025 to 2026 trends with sources.**
- **Authenticity over polish.** Several 2026 trend pieces argue the "3 second hook, trending sound, aggressive text" formula became "a blur of sameness" and that raw process content now beats polish [V, marketing blogs: Powerdrill, mean.ceo]. No platform-published first-3-second benchmark exists; vendor claims (average Short about 33 s, many viral Shorts 20 to 40 s) are weak.
- **Split-screen "content sludge."** Clips paired with Subway Surfers or Minecraft gameplay, 2 to 4 unrelated videos at once; a psychologist in Kotaku links it to "visual tactility" [V: Kotaku, Trill]. Subway Surfers' developer credits split-screen virality for growth [V].
- **Velocity edits and sped-up audio** (see style 4).
- **FOOH (faux out-of-home) CGI.** Jacquemus' giant Bambino bags rolling through Paris (April 2023, CGI by Origiful, over 48 million views per WWD Japan) and Maybelline's mascara train and tram [V: fooh.com library, WWD Japan]. A 3D pattern a code tool can borrow: real street plate, one impossible object, handheld camera.
- **Collage and "brat" maximal-minimal type** (see style 12).

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| First visual change | by frame 15 to 30 at 30 fps (0.5 to 1 s); frame 0 already a finished, readable composition | WD, frame 0 rule V (echris6) |
| Hook text on screen | 3 to 7 words, readable in under 1.5 s, inside the safe zone | WD |
| Shot length, Hormozi-type | 1 to 3 s (30 to 90 f @30) | V (Choppity) |
| Shot length, Abdaal-type | 2 to 5 s (60 to 150 f @30) | V (Choppity) |
| Pattern interrupt cadence | a change of framing, graphic, sound or location every 2 to 4 s | WD |
| Caption page | 1 to 3 words; word appears 0 to 2 f before it is spoken | lead V (motionmaxxing: text leads voice 2 f; reveals that must be complete when spoken lead up to 5 f) |
| Caption pop | scale 0.8 to 1.0 or y +12 px to 0 over 4 to 6 f, ease out; highlight colour on the stressed word only | WD |
| Punch-in on jump cut | alternate 100% and 112 to 120% | WD |
| Safe zone 9:16 | keep captions and faces out of the bottom 20% and right 12% (platform UI) | WD; check charlie947 `reel-export` for exact zones |

**Sound grammar.** Voice first and loud. One whoosh per transition, one pop per caption emphasis (not per word), a riser into the payoff, silence for 4 to 8 f before the punchline [WD]. Hormozi-style edits run a low music bed or none; Abdaal-style lo-fi barely audible [V Choppity].

**Ratio and length.** 9:16 at 1080 x 1920. 15 to 60 s for most hooks; up to 3 min allowed [V].

**Cheap vs premium.** Cheap: every word a different colour and animation, emoji on every line, zoom on every sentence, stock whooshes on every cut, captions over the face, 1-frame jitter from bad auto-reframe. Premium: one caption system, one accent colour, highlight on meaning not on rhythm, cuts that land on speech boundaries, and a hook that shows the payoff instead of announcing it.

**Build in code.**
- Captions: Whisper word timestamps (Remotion `template-tiktok` or HyperFrames `hyperframes-media` transcribe) to JSON; one DOM node per word; GSAP `fromTo(word, {y:12, scale:0.9}, {y:0, scale:1, duration:5/30, ease:"power3.out"})` placed at `word.start - 2/30`. Highlight by swapping a class, not by animating colour across many frames.
- Punch-ins: wrap the A-roll `<video>` in a container; at each cut set `scale` instantly (no tween) between 1.0 and 1.15; anchor `transform-origin` on the face box from a one-time face detection pass.
- Seek-safe: every tween on one paused timeline; no `setTimeout`, no `requestAnimationFrame`, seeded randomness only (HyperFrames determinism rule) [V].
- ffmpeg fallback for cuts: `-vf "select='between(t,a,b)+between(t,c,d)',setpts=N/FRAME_RATE/TB"` with matching `aselect`/`asetpts`.

---

## 2. Vlog edits

**What.** First-person story edits around a day, trip or project: talking to camera, B-roll, montage, music.

**When.** Personal brand, founder diaries, travel, behind-the-scenes, product-in-life.

**Exemplars.**
- **Casey Neistat** (youtube.com/@casey). Editor Sven Pape's catalogue of his moves: the "Neistat Cut-Off" (a shot ends mid-sentence), the "Neistat Montage" (one task compressed into rapid, usually sped-up cuts), the "continuous thought" (one sentence across locations), associative cuts to film clips [V: Artlist, No Film School]. Whip pans repeated across clips to jump location; edits strictly in order from the first frame; mostly straight cuts, little grading, few effects; timelapses usually carry a large camera move (Nerdwriter analysis) [V: Indepthcine, PremiumBeat, Laughing Squid].
- **Peter McKinnon** (youtube.com/@PeterMcKinnon). In-camera transitions made by moving the camera fast so motion blur joins two clips; vlogs open with a "cinematic intro" of B-roll; B-roll shot at 120 fps for slow motion; Lumetri grading in Premiere [V: No Film School, Videomaker].
- **Sam Kolder** (instagram.com/samkolder). Travel transitions: luma fades between clips by brightness, zooms that keep zooming past the cut, speed ramps, masking; preset recipes cut 10 frames either side of the edit and apply the transition on an adjustment layer [V: tutorial and forum sources; no primary Kolder breakdown found].
- **Matt D'Avella** (youtube.com/@mattdavella). Director and cinematographer of "Minimalism" (2015) [V: onesheet]. No verified source for his framing, grade or frame rate; observable: locked-off symmetrical frames, muted grade, deadpan comedic cuts. Unverified.
- **Emma Chamberlain** (youtube.com/@emmachamberlain). Known for zooms, on-screen text, pauses and mid-edit interjections; said she spent 20 to 30 hours editing each weekly vlog with no assistant; widely imitated; has since moved to a simpler documentary style [V: Wikipedia, Tubefilter, W Magazine].
- **Aesthetic day-in-the-life.** Mood-first: consistent colour and light, breathing room, chronological routine [V, vendor guides only]. I could not verify a creator named "Kelsey" as the reference; if a specific creator was meant, send the handle.
- **Indian creators.** I found no reliable editing breakdown of an Indian vlog channel. Indian references are stronger in documentary (Dhruv Rathee, style 10) and podcasts (Raj Shamani, style 3).

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| Montage cut (Neistat) | 4 to 12 f per shot @30, footage sped 2x to 8x | WD |
| Timelapse | 1 s of screen = 5 to 30 min of real time; always with a camera move (slider, pan) | move V (Nerdwriter); ratio WD |
| In-camera whip | 6 to 10 f @30 of blur either side of the cut | WD; see whip pan in grammar |
| Speed ramp (Kolder) | 100% to 300 to 800% to 100%, ramp segments 4 to 8 f, slow payoff at 20 to 40% | WD |
| B-roll ratio | intro montage 10 to 20 s, then B-roll every 10 to 20 s in the body | WD; the 10 to 20 s figure also appears in vendor guides |
| Slow motion | shot at 120 fps, played at 24 or 30 (20 to 25% speed) | V (McKinnon guide) |

**Sound grammar.** Music carries montage and is cut on the downbeat; natural sound (door, pour, footsteps) punched up 3 to 6 dB under montage as rhythm; VO or to-camera line lands after the music dips 6 to 10 dB [WD; duck values V motionmaxxing]. Neistat's cut-off often lands on a music hit.

**Ratio and length.** 16:9 for YouTube (8 to 20 min); 9:16 cutdowns of 30 to 90 s.

**Cheap vs premium.** Cheap: preset transition packs (spins, glitches) between unrelated shots, LUT on everything, music wall-to-wall with no dynamics. Premium: transitions motivated by motion in the footage, natural sound as rhythm, one memorable shot per minute (Neistat's ladder drone, McKinnon's macro coffee), honest roughness on purpose.

**Build in code.**
- Speed ramp on real footage: time-remap function `src(t)`; drive `<video>.currentTime = src(t)` per frame in a seek-driven renderer (HyperFrames and Remotion both seek video deterministically). Use a smootherstep between speed segments: integrate speed s(t) to get source time.
- Luma fade: WebGL shader `mix(a, b, step(lum(a), p))` with a 0.05 to 0.15 soft edge, p from 0 to 1 over 10 to 15 f [WD]. gl-transitions has `luma` and many relatives (MIT, pure function of from, to, progress) [V].
- Timelapse from stills: `ffmpeg -framerate 30 -i %04d.jpg -vf "deflicker,zoompan=z='min(zoom+0.0008,1.15)':d=1"`.
- In-camera whip fake: see grammar (directional blur at peak velocity).

---

## 3. Talking head and podcast clip edits

**What.** A-roll of a person speaking, tightened with jump cuts, varied with punch-ins and B-roll, carried by captions.

**When.** Founder content, podcast clips, explainers to camera, LinkedIn video.

**Exemplars.**
- **The Diary of a CEO** (youtube.com/@TheDiaryOfACEO). Runs a separate "The Diary of a CEO Clips" channel (over 2M subscribers per an Opus Clip case study) so short clips do not break the main channel's long-session expectations [V: Opus, vendor case study]. Its short-form editor brief: teasers, clips and shorts optimised for retention, watch time and shareability across TikTok, Instagram and Facebook [V: FlightStory job listing].
- **Raj Shamani, Figuring Out** (youtube.com/@rajshamani). Shamani writes that his first 50 episodes drew "almost zero audience" and that he structures episodes like a film: guest background, a problem, a resolution [V: The Current]. An editor reports the "Raj Shamani Shorts" channel grew from 600k to 813k subscribers by October 2024 [V, self-reported].
- **Hormozi and Ali Abdaal** (style 1) are also the two poles of talking-head pacing: 1 to 3 s cuts versus 2 to 5 s cuts [V Choppity].
- **Opus Clip, Submagic, Vizard**: the auto-clipping tools that set the current default look (word captions, auto reframe, punch-ins on sentence starts) [V: vendor pages].

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| Jump cut | remove pauses over 6 to 10 f @30; keep a 2 to 4 f breath before a new thought | WD |
| Punch-in | alternate wide 100% and tight 115 to 130%; land zooms at sentence starts, not mid-clause | zoom-on-sentence V (Vizard vendor page); % WD |
| Resolution headroom | 4K source to 1080p output = 200% punch-in with no upscaling (3840/1920) | arithmetic |
| Slow push | 100% to 105 to 108% over a 4 to 8 s thought, linear | WD (echris6 uses 3 to 5% pushes on reading holds) |
| B-roll insert | 1.5 to 3 s, cut in on the noun, out before the next noun | WD |
| Clip length | 20 to 45 s for podcast Shorts; 5 to 6 Shorts per episode | V, vendor guides only |
| Reaction cut (L cut) | cut to the listener while the speaker's last 1 to 2 words play | V (dialogue editing guides) |

**Sound grammar.** Dialogue at the top of the mix, -16 to -12 dBFS peaks [V motionmaxxing]. Room tone filled under every jump cut so cuts do not "click"; 2 to 4 ms audio crossfades at every cut [WD]. Music only in the hook and outro, or a bed at -20 to -24 dB below voice [WD]. One SFX family (a soft tick for graphics, a low hit for the key line).

**Ratio and length.** 9:16 clips; 16:9 full episodes; 1:1 or 4:5 for LinkedIn feed.

**Cheap vs premium.** Cheap: punch-in on every cut (the zoom loses meaning), zooms that cycle faster than thoughts, captions covering the mouth, auto reframe that hunts. Premium: punch-ins reserved for emphasis and topic change, a second camera angle to hide cuts, captions in one designed system, B-roll that shows the noun being spoken.

**Build in code.**
- Transcript-driven cut list: Whisper words to sentences; remove gaps over a threshold; generate an EDL as JSON `{srcIn, srcOut, scale, anchor}`; render each segment as a `<video>` with `currentTime` mapped.
- Punch-in: per-segment `transform: scale(1.18)` with origin at the face box centre; no tween at the cut (an instant change reads as a camera change; an animated zoom reads as a move).
- Morph-cut alternative: a 3 to 5 f crossfade between two jump-cut frames only works when the head barely moves; otherwise cut to the tight framing instead (see grammar).
- ffmpeg: `afade` 2 to 4 ms at each audio joint, `loudnorm=I=-14:TP=-1:LRA=11` on export.

---

## 4. Music-synced edits

**What.** Edits where the music is the clock: beat cuts, velocity edits, fan "edits" and AMVs, flash and strobe accents.

**When.** Hype reels, sports, fan edits, fashion, launch teasers under 30 s, idents.

**Exemplars.**
- **AMV culture.** The first anime music video is credited to Jim Kaposztas in 1982 (Star Blazers cut to a Beatles song); AnimeMusicVideos.org was launched in 2000 by Kris "Phade" McCormic and became the community hub; AMV Hell began at Otakon 2004 [V: Wikipedia, Fanlore, Anime Herald, UK Anime Network].
- **Velocity edits.** Slow motion broken by sudden speed changes, synced to beats; CapCut's Speed > Curve presets are Montage, Hero, Bullet, Jump Cut, Flash In and Flash Out, with custom curves from 0.1x to 10x, plus an "Auto Velocity" style [V: CapCut, VideoProc, Nemo]. Best practice: slow only the payoff, keep entry and exit fast, trim dead space after the slow section [V, tutorial consensus].
- **"Edit audio" and sped-up songs.** Sped-up, pitch-raised versions descend from nightcore (mid-2000s, Norwegian students) and chipmunk-soul sampling; they have revived older songs (Lady Gaga's "Bloody Mary") and pushed artists to release official sped-up versions [V: Alternative Press, Know Your Meme].
- **Pentagram for MTV World Creative Studio**: logomarks are short waveforms animated and equalised to the beat of music [V: pentagram.com]. A brand-scale example of music driving motion.
- **Measured pro cadence**: four consecutive cuts exactly 10 f apart at 30 fps, then an 8 f cut; service swaps every 11 f "like a steady drum"; strobe plates 4 f at 60 fps; music-only kinetic words hard-cut 3 to 4 f apart (6 to 7 f at 60) and held 0.9 s [V: motionmaxxing M962, M921 to M924].

**Signature techniques with numbers.**

| Technique | @30 fps | @60 fps | Tag |
|---|---|---|---|
| Cut on beat | on the beat frame or 1 f early (the eye needs a frame to register) | 1 to 2 f early | WD |
| Cut grid | choose one unit g (a quarter or eighth note) and cut only on multiples | same | V (motionmaxxing rule) |
| Strobe montage | 4 f plates, first plate 2 f | 8 f plates, first 4 f | V (M948: 14 plates, about 15 plates/s) |
| Velocity ramp | ramp in 4 to 8 f to 20 to 30% speed, hold 10 to 20 f, snap out in 2 to 4 f | double | WD |
| Flash frame | 1 to 2 f white or brand colour on the drop | 2 to 4 f | WD; cap at 3 flashes per second |
| Shake on bass hit | 6 to 14 px at 1080p, decay over 6 to 10 f | 12 to 20 f | WD |
| Zoom bump on kick | scale 1.00 to 1.04 to 1.00 over 4 to 6 f | 8 to 12 f | WD |

**Strobe and flash rules.** At 30 fps, a white flash every other frame is 15 flashes per second, five times the WCAG limit. Allow full-frame luminance flips at most 3 per second; for faster strobes, keep the change under 10% relative luminance (dark-on-dark plates), keep flashing area under 25% of a 341x256 window, avoid saturated red flips entirely, and keep any strobe run under 5 s [V thresholds: W3C, ITC]. Offer a "photosensitive safe" toggle that clamps all of this.

**Sound grammar.** The track is the edit. Drop on the hero visual; a 0.2 to 0.5 s gap or filter sweep before the drop [V motionmaxxing: clear the sound before the biggest move]. SFX sparse: risers into drops, impacts on the hit, nothing on every cut.

**Ratio and length.** 9:16, 7 to 30 s for velocity and fan edits; AMVs run full song length 16:9.

**Cheap vs premium.** Cheap: cutting on every beat with no phrasing (the 4-bar phrase is the real unit), shake on every hit, flashes that fail WCAG, sped-up audio with clipping. Premium: cuts that follow phrase structure (change pattern every 4 or 8 bars), holds that let one shot breathe across a bar, motion inside shots aligned to beats, not just cuts.

**Build in code.**
- Beat map offline: librosa (ISC) `beat_track` and `onset_detect` to `beats.json`; avoid essentia.js (AGPL) and aubio (GPL) in shipped code [V licences, prior repo audit].
- Cut times: `frame = Math.round(beatTime * fps) - lead`. Put each as a GSAP label: `tl.addLabel("b"+n, frame/fps)`.
- Velocity on footage: piecewise speed curve integrated to source time; for rendered graphics apply the same remap to the timeline: `tl.time(remap(t))`.
- Strobe: array of plates, `plate = Math.floor(t*fps/4) % n`; flash: overlay div with `opacity` set per frame from a lookup, not a tween.
- Starters: Sunwood `hyperframes-motion-reel` (b(n) beat grid at 120 BPM, 60 fps), HyperFrames `beat-freeze-cut`, `beat-accent`, `beat-pulse-background` [V repo audit].

---

## 5. SaaS and product launch films

**What.** 20 to 90 s films that show software doing one thing well: camera moves over UI, cursor, typing, results, name, CTA.

**When.** Launch day posts on X and LinkedIn, landing page heroes, changelog videos, keynote openers.

**Exemplars.**
- **Figma Config.** The 2024 open film was shaped by Figma's motion design lead Chad Colby with the Danish studio Relay on motion; the Config identity was a ten-month, mostly in-house project [V: It's Nice That]. Config 2026 identity notes from brand motion designer Ben Hill (static and animated elements designed in parallel) [V: Figma blog]. Figma announced "Figma Motion" (animation on the canvas) at Config 2026 [V: Tecnoblog].
- **Linear** (linear.app). Makes brand and product video in-house: its careers page lists a "Motion Storyteller" on the Magic Team for product demos, brand videos and educational content [V]. Linear's release films are the reference for dark UI, slow camera over interface, single accent.
- **Vercel** and **Stripe**. Both hire in-house motion designers for launches; Stripe's "Motion Designer, Experiential" role covers mainstage scenic content for Sessions, coordinates external motion studios and asks for Notch, TouchDesigner, Disguise [V: job listings].
- **The Browser Company (Arc, Dia).** Video-first marketing: casual vlog-style YouTube, a TikTok build-up series, and product announcements by CEO Josh Miller on camera [V: Tella, TechCrunch]. Proof that a founder on camera can be the launch film.
- **Measured set** (echris6, 28 films, all linked on X): Replit "Slides", "Canvas", "Parallel Agents"; Cognition "Devin Voice"; Bolt.new; Contra "Indy" and "Creative Arena"; Browserbase; Work Louder; Extend [V]. These are the current (2025 to 2026) X launch-film genre.
- **Apple** (apple.com product pages and event films). Product pages scrub image sequences on a pinned canvas as you scroll (CSS-Tricks rebuilt the AirPods Pro page this way) [V]. Apple's HIG says motion should support the experience, never be the only carrier of information, and be cancellable [V].
- Raycast: I found no credit or breakdown for its launch films; leave it as an unverified look reference.

**The 30 s structure.** Combining echris6 (12 to 15 compositions, beats 1.4 to 3.5 s, end card 1.5 to 2 s) with motionmaxxing's beat roles and word budgets [V]:

| Beat | Time | f @30 | Job | Words of VO (2.5 to 3 w/s) |
|---|---|---|---|---|
| Hook | 0 to 4.5 s | 0 to 135 | the problem or the claim, frame 0 complete | 4 to 10 |
| Turn | 4.5 to 9 s | 135 to 270 | the product name lands on or just after its reveal (wordmark complete 5 f before it is spoken) | 6 to 12 |
| Proof x2 or x3 | 9 to 24 s | 270 to 720 | one real task per proof, 4 to 7 s each; proofs may be silent | 0 to 14 each |
| CTA | 24 to 28.5 s | 720 to 855 | offer and name; entries halve to 6 f | 3 to 8 |
| End card | 28.5 to 30 s | 855 to 900 | readable 1.5 to 2 s, gentle drift; hold after last element 0.6 to 1.4 s | 0 |

Total: about 60 to 80 VO words at 30 s, 28 to 38 at 15 s [V motionmaxxing, marked "practice"].

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| Camera over UI | continuous canvas: camera moves over one layout; selected item sharp, neighbours blurred 4 to 10 px | mechanism V (echris6 #6); blur WD |
| Scale on UI | hero UI at 1.4 to 3.3x; lead subject 60 to 85% of frame | 3.3x card V (motionmaxxing T12); 60 to 85% V (echris6) |
| Cursor press | squash 2 to 3 f, click flash 1 f, result visible within 6 f | squash and flash V (motionmaxxing); 6 f WD |
| Typing | 21 to 30 characters per second, or bursts of about 3.4 characters per frame | V (motionmaxxing M914, M928, M931) |
| Text leads voice | 0 to 2 f; reveals that must be complete when spoken, up to 5 f | V |
| Transitions | the foreground becomes the transition (headline or logo flies through the camera into a pre-placed scene); hard cuts when subject, scale, direction and material match | V (echris6 rules 1 and 5) |
| Selection to expansion | a selected card expands into the workspace, 10 to 16 f | mechanism V (echris6 #3); time WD |
| Logo as portal | the brand shape grows until its counter becomes the next frame; scale 1 to about 22x in 0.53 s at constant octave rate | V (motionmaxxing T13) |

**Sound grammar.** Typing and clicking are the sound of proof: keep proofs under music and SFX, VO only on hook, turn and CTA [V motionmaxxing]. Typing: quiet keyboard texture for the span, never a tick per character (-16 to -22 dB). Click: one dry layer on the press frame (-6 to -10 dB). Logo slam: low hit plus 0.6 to 1.0 s tail. Pick 3 to 5 SFX kinds per film and reuse them [V motionmaxxing, marked "practice"].

**Ratio and length.** 16:9 for keynote and site hero; 1:1 or 4:5 for X and LinkedIn feed; 9:16 cutdown. 15, 30, 45 or 60 s.

**Cheap vs premium.** Cheap: screen recording at 1x zoom with a fake cursor gliding in straight lines; UI floating on a gradient void with drop shadows; every panel fading in; "Meet X", "seamless", "Not just X. It's Y." copy [V motionmaxxing copy tells]. Premium: real UI rebuilt in HTML at 2x, camera that frames one interaction at a time, cursor paths with acceleration and overshoot, cause and effect on every action, one accent, a real case with real content.

**Build in code.** This is the style code does best, because the UI already is HTML.
- Rebuild the UI as DOM at real size; wrap in a "camera" div; animate the camera's `transform: translate3d() scale()` rather than the UI.
- Depth of field: duplicate the canvas layer with `filter: blur(6px)` and mask it with a radial or rectangular `mask-image` that follows the selected element.
- Cursor: SVG pointer with a path from a cubic Bezier between targets, eased `power3.inOut`, overshoot 4 to 8 px then settle in 6 f [WD]; press: `scale(0.9)` for 2 f.
- Typing: `text.slice(0, Math.floor((t - t0) * cps))` evaluated per frame, so it is seek-safe.
- Scroll-scrubbed product shots: pre-rendered image sequence drawn to `<canvas>` by frame index (Apple method).
- Starters: echris6 `business-motion-film`, tugrawork-creator `saas-motion-kit` (24-transition atlas, variety audit), Vincentwei1021 `video-shotcraft` (124 recipe cards distilled from ClickUp, Perplexity, Slack, Notion, Figma, Framer, Bear, Raycast, Pitch, Miro, Superhuman, Loom; Remotion, 1920x1080 at 30 fps) [V].

---

## 6. Kinetic typography

**What.** Words as the picture: type that enters, transforms and exits in rhythm with voice or music.

**When.** Brand manifestos, title sequences, lyric videos, idents, quote posts, event identities.

**Exemplars.**
- **Saul Bass.** "The Man with the Golden Arm" (1955): a black cut-paper arm, an alternative to static title cards (projectionists were told to pull the curtain before the titles); "Anatomy of a Murder" (1959): cut-out names across body parts; also "Vertigo" (1958) and "North by Northwest" (1959). His stated aim: "to create a climate for the story that's about to unfold" (Bass on Titles, 1977) [V: BFI, Art of the Title, MovieMaker].
- **Kyle Cooper.** "Se7en" (1995): directed by Cooper, shot by Harris Savides, cut by Angus Wall; hand-made, scratched look as if made by the killer; co-founded Imaginary Forces in 1996, founded Prologue in 2003 [V: Imaginary Forces, Wikipedia].
- **Studio Dumbar** (studiodumbar.com, Rotterdam). North Sea Jazz identity with kinetic type in Gravity and Monument Grotesk (Dinamo); Amsterdam Sinfonietta: custom code turns music into patterns of the AS acronym; DEMO festival: a variable typeface whose shape changes by a self-written script; "Cities in Motion" custom variable typeface [V: TypeRoom, studiodumbar.com].
- **Animography** (animography.net, Amsterdam, by Jeroen Krielaars of Calango): animated typefaces shipped as After Effects files; the "Franchise" project gave one glyph each to 110 animators, max 1 second, 25 frames, 4 colours [V: Cartoon Brew, AIGA Eye on Design].
- **DixonBaxi** (dixonbaxi.com). The CW (2024): a stretching "stage" logo that becomes clapperboard, navigation or lens; F37 Bolton; sonic identity by We Are Audio [V: It's Nice That, Creative Review].
- **Jordan Bergren** (School of Motion alum; HBO, Hulu, Netflix, Adidas, Coach) [V: School of Motion]. I could not verify kinetic type as his specialty; check his reel before citing him for this style.

**Signature techniques with numbers.**

| Technique | @30 | @60 | Tag |
|---|---|---|---|
| Word cadence, music only | words hard-cut 3 to 4 f apart, hold 0.9 s | 6 to 7 f | V (motionmaxxing M921 to M924) |
| Word cadence, voice-led | 8 to 12 f between words; pop cadences slow toward phrase end (4 then 6 f) | 16 to 24 f | V |
| Emphasis word | a longer gap before it (6 to 7 f then 10 f at 60 fps) or glyph-by-glyph every 3 f | | V (M921, M966) |
| Letter stagger | 1 f per letter, uneven gaps (3,2,2,2,2,2) so the wave reads as one gesture under 0.6 s | 2 f | V (motionmaxxing R1.8) |
| Line replace | clip edge sweeps through the line in 5 f, accelerating, cutting mid-glyph; never crossfade | 10 f | V (motionmaxxing R8.1) |
| Text blur on cut | 10 px for text; 20 px smears letterforms and reads as a glitch | | V (HyperFrames) |
| Tracking (lettering) | -0.035em at 30px and up, -0.02em below | | house rule from the brief owner |
| Slam | scale 1.5 to 3.5x to 1.0 in 3 to 5 f, 2 to 3 f of 4 to 10 px shake | | slam from 3.5x V (motionmaxxing); shake WD |
| Reading time (no VO) | 0.3 s per word + 0.5 s, minimum 1 s per line | | WD |

**Sound grammar.** Either the voice is the clock (word onsets) or a beat grid is (music-only). motionmaxxing's rule: voice-led films cut on words, music-led films cut on a grid, and a film that tries both "cuts to nothing" [V]. On-screen text is not the transcript: measured pro films never caption their VO, and the claim on screen often differs from the spoken line [V motionmaxxing].

**Ratio and length.** Any; 9:16 lyric clips 10 to 30 s; titles 60 to 180 s; stings 3 to 7 s.

**Cheap vs premium.** Cheap: every word fading up, typewriter on everything, five fonts, centre-aligned paragraphs bouncing in, "Not just X. It's Y." Premium: one or two families, a grid, type that does something only type can do (a counter becomes the next frame, a letter becomes an object), strong asymmetric holds, scale contrast.

**Build in code.**
- GSAP SplitText (free with all plugins since GSAP 3.13, May 2025; rewritten with 50% smaller size, masking built in) splits into chars, words, lines with masks for reveals [V: GSAP, Webflow].
- Mask reveals: line wrapper with `overflow: hidden` (or SplitText `mask: "lines"`), child `yPercent: 100 -> 0` over 10 to 12 f, `power4.out`.
- Variable fonts: animate `font-variation-settings: "wght" 100 -> 900` per letter with stagger; this is how Dumbar-style shape-shifting works.
- Clip-edge erase: `clip-path: inset(0 0 0 X%)` with X from 0 to 100 over 5 f, `power2.in`.
- Text on 3D: three.js `TextGeometry` or troika-three-text; Codrops kinetic typo demos (MIT) wrap type on tori and tubes [V repo audit].

---

## 7. 2D motion graphics and explainers

**What.** Illustrated or vector worlds that explain an idea: flat shapes, characters, morphs, diagrams, narrated.

**When.** Concepts, science, product mechanics, onboarding, education, nonprofit stories.

**Exemplars.**
- **Kurzgesagt** (youtube.com/@kurzgesagt). "How to Make a Kurzgesagt Video in 1200 Hours": at least 1,200 hours per video; research and script take weeks with expert checks; 2 to 3 animators work scene by scene over 8 to 10 weeks; everything that moves is animated by hand; 2 to 4 videos in parallel; music composed to the finished picture [V: Kottke, LingQ transcript, Gigazine].
- **Buck** (buck.co). Founded 2004 by Jeff Ellermeyer, Ryan Honey and Orion Tait; LA, New York, Sydney, Amsterdam, London; four Sundance shorts including "Come Together", animated in 3D then rebuilt as laser-cut stop motion [V: Wikipedia, Motion Array].
- **Giant Ant** (giantant.ca, Vancouver). Founded 2007 by Jay Grandin and Leah Nelson; clients include TOMS, Target, Facebook, Slack; 2 Emmys; original film "Tangles" on Alzheimer's [V: Communication Arts, FITC].
- **Ordinary Folk** (ordinaryfolk.co, Vancouver). Founded 2019 by Jorge R. Canedo Estrada; Google Search On 2020 motion; "The Gospel Animated" 2-minute piece; self-initiated "Mainframe" [V: Motionographer, Stash, School of Motion].
- **Vox** (youtube.com/@Vox). Estelle Caswell's "Earworm" (2017 to 2022), described as self-taught motion graphics; art director Joey Sendaydiego on animation for attention [V: Film Independent, Storybench].
- **Spotify Wrapped 2025** used Rive for its motion layer, prototyped with dummy data [V: Rive, vendor case study].

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| Scene length | 3 to 8 s per idea, one idea per scene | WD |
| Character secondary motion | idle breathing 1 to 2% scale at 0.25 to 0.5 Hz; blinks every 2 to 6 s, 4 to 6 f long @30 | WD |
| Shape morph | 12 to 24 f, `power2.inOut` or `expo.inOut`; matching point counts | WD |
| Anticipation | 3 to 6 f opposite move before a big action; overshoot about 1.08 settling over 15 f | overshoot V (motionmaxxing); anticipation WD (motionmaxxing saw it in 5% of overshoots) |
| On 2s | hand-drawn feel by holding each drawing 2 f (12 fps at 24) | WD; HyperFrames `stop-motion-cadence` quantises time |
| Camera | slow 2.5D parallax, 3 to 5 layers, foreground 1.5 to 2x background speed | WD |
| Diagram build | each element arrives on its spoken noun, 0 to 2 f early | V (word-lead rule) |

**Sound grammar.** Narration-led. Original or tailored score that follows scenes (Kurzgesagt composes to picture) [V]. Small foley for every physical action (pops for shapes, swishes for morphs) at -14 to -20 dB, never louder than the voice [WD].

**Ratio and length.** 16:9, 3 to 15 min for YouTube; 60 to 120 s for product explainers; 9:16 cutdowns.

**Cheap vs premium.** Cheap: stock character kits with rubber-hose arms, icon grids sliding in, every object popping with the same back-ease, text bullets on screen reading the VO. Premium: a defined world (palette, light direction, texture), shape language with a reason, one metaphor ridden through the film, motion that explains (a thing changes because of another thing), hand-tuned timing.

**Build in code.**
- Vector scenes in inline SVG; morphs with GSAP MorphSVG (free since 3.13) or flubber (MIT, by Noah Veltman) for arbitrary path pairs [V].
- Characters: Rive state machines or Lottie (seekable; HyperFrames seeks Lottie natively) [V]; or SVG bones driven by GSAP.
- Texture: SVG `feTurbulence` + `feDisplacementMap` for wobble lines (seed the filter, animate `baseFrequency` stepwise for boil on 2s).
- Lottie authoring by Claude: diffusionstudio `text-to-lottie` skill (MIT) [V repo audit].

---

## 8. 3D motion

**What.** Rendered objects and worlds: product turntables, Apple-style hero shots, abstract loops, 3D title fly-throughs, FOOH.

**When.** Hardware and physical product launches, brand worlds, logo stings, premium social loops.

**Exemplars.**
- **ManvsMachine** (mvsm.com, London and LA). Founders Mike Alderson and Tim Swift; part of The Landor Group; Nike Air Max Day campaigns (2018 mixed live action, 3D, typography and cel animation; 3D-scanned shoes so CG matches product); also Apple, Pepsi, Squarespace. Pipeline: Cinema 4D, Arnold and V-Ray, Houdini for complex simulation, After Effects and Nuke for comp [V: Motion Array, It's Nice That, Maxon].
- **Andrew Kramer** (videocopilot.net). Main title designer on "Star Trek Into Darkness" (2013): over 30 title sequences built as one fluid camera fly-through in After Effects with Video Copilot's Element 3D; also credited for "Star Trek" (2009) titles; VFX credits on "The Force Awakens" (hologram effects) [V: AWN, Digital Production, Memory Alpha, IMDb].
- **Apple product renders** (apple.com). Scroll-scrubbed image sequences on canvas (AirPods Pro page, rebuilt by CSS-Tricks) [V]. Look: one product, black or white seamless, rim light, slow 15 to 45 degree rotations, macro on materials [WD description].
- **FOOH** (fooh.com library): Jacquemus Bambino bags through Paris (2023, Origiful, 48M+ views), Maybelline mascara train and tram (2023), Sky High airport carousel (2024) [V].

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| Turntable | 360 degrees in 6 to 12 s, or a 30 to 60 degree arc in 3 to 5 s with ease-in-out; never constant spin in a hero shot | WD |
| Camera lens | 50 to 85 mm equivalent for product (FOV 27 to 40 degrees vertical at 16:9), 24 to 35 mm for worlds | WD |
| Exploded view | parts separate along their assembly axis over 18 to 30 f, hold, recombine | mechanism V (echris6 #10); time WD |
| Motion blur | 180 degree shutter: blur over half the frame interval (16.7 ms at 30 fps) | standard |
| Depth of field | f/2.8 to f/5.6 look; focus pull 12 to 20 f | WD |
| Title fly-through | one continuous camera path; type in Z with 1.5 to 3 world units between cards | concept V (Kramer); spacing WD |

**Sound grammar.** Material sounds (metal ting, glass tick, fabric rustle), low sub swells under reveals, silence before the product's first full frame [WD; silence-before-hit V motionmaxxing].

**Ratio and length.** 16:9 hero 10 to 30 s; 1:1 loops 4 to 8 s; 9:16 FOOH 10 to 20 s.

**Cheap vs premium.** Cheap: default HDRI with no shaping, plastic materials with no roughness variation, no contact shadows, constant-speed spins, bloom on everything, chrome with nothing to reflect. Premium: studio lighting (key, rim, kicker), materials with roughness maps and wear, contact shadow and ambient occlusion, real insides for exploded views, a camera that behaves like a dolly with weight.

**What three.js can do (and cannot).**
- Can: physically based materials via `MeshPhysicalMaterial` (clearcoat for car paint and lacquer, transmission with thickness and IOR for glass, iridescence, sheen for fabric; the docs say transmission beats opacity for thin glass, an environment map is required for good results, and the material is the most expensive per pixel) [V: threejs.org docs]. glTF extensions for transmission, volume, IOR, specular, clearcoat, sheen, iridescence, anisotropy, dispersion load directly from Blender exports [V: Khronos]. Postprocessing (pmndrs/postprocessing): bloom, DOF, SSAO, chromatic aberration, noise. Image-based lighting with `PMREMGenerator`. Instancing for thousands of objects. Text geometry.
- Can, with care: path-traced stills via gkjohnson's `three-gpu-pathtracer` (accumulates samples; render offline per frame).
- Cannot well in real time: high-sample global illumination, caustics, cloth and fluid simulation, true volumetrics. Bake those in Blender (lightmaps, simulation caches as glTF morph targets or alembic to vertex animation textures), then play back.
- Determinism: drive every object from `t` (`object.rotation.y = f(t)`), render with `renderer.render()` once per seek; no `clock.getDelta()`. HyperFrames seeks three.js scenes for you [V].
- Motion blur in a seek renderer: render 8 to 16 subframes across the shutter interval and average them (howseen `claude-motion-design` does subframe shutter blur) [V].
- Starters: HyperFrames `product-turntable` (drop in a GLB), `extruded-logo`, `exploded-stack`, `chrome-orb`, `liquid-metal` [V repo audit].

---

## 9. Brand idents and stings

**What.** 2 to 10 s logo reveals and network or brand stings, often with a sonic logo.

**When.** Video openers and closers, platform intros, event stings, app launch screens.

**Exemplars.**
- **Netflix "ta-dum."** Created by Netflix VP of Product Todd Yellin with Oscar-winning sound editor Lon Bender; built from Yellin's wedding ring knocking a cabinet, a slowed anvil and a reversed old electric guitar; a goat bleat was a finalist. The 2019 visual (colour ribbons streaming out of the N) kept the same sound [V: BGR, Slashfilm, Boing Boing]. No designer credit found for the 2019 animation.
- **DixonBaxi for Hulu** (2021): a "Vessel" device whose rounded corners come from the "u" in the wordmark; a four-beat sonic mnemonic with Zelig; a new network ID before every Hulu Original [V: Design Week, Creative Review]. **The CW** (2024, see style 6).
- **Pentagram.** EDP: the spiral mark is drawn by a dot tracing a circular path, so the logo originates in motion; MTV World Creative Studio: waveform logos animated to music; Satalia: a core "timeline" animation with gradient waves [V: pentagram.com].
- **Studio Dumbar** DEMO festival: a script animates every word its own way [V].

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| Length | 2 to 4 s for app and video stings; 5 to 10 s for network IDs | WD |
| Build | mark assembled in about 7 f, or stems built over 7 f; wordmark slam from 3.5x | V (motionmaxxing transition table) |
| Resolve | final value present from frame 1, resolving through 12 to 15 px squares to real glyphs while scaling 96 to 176 px, hold 0.47 s | V (motionmaxxing M945) |
| Pixel dissolve in | coverage 90% to 0% over 0.33 s (10 f), never a 20 f opacity fade | V (motionmaxxing) |
| Hold on final | 0.6 to 1.4 s after the last element resolves | V (motionmaxxing gate G3) |
| Sonic logo | 2 to 4 notes or hits, 1 to 2 s, the last hit on the mark's final frame | WD; Hulu's mnemonic is four beats V |

**Sound grammar.** The sound is half the ident: one low hit plus 0.6 to 1.0 s tail on the name slam; a lingering mark gets nothing or a soft shimmer at -18 dB or lower [V motionmaxxing]. Design the sting so it works muted and so the sound works without picture (Netflix's ta-dum does) [WD].

**Ratio and length.** Deliver 16:9, 1:1, 9:16 and a transparent (alpha) version.

**Cheap vs premium.** Cheap: logo spins, light sweep across the wordmark, particle explosion assembling the logo, lens flare, generic "whoosh plus boom." Premium: motion derived from the mark's own construction (EDP's dot, Hulu's vessel), one sound that belongs to the brand, restraint, an ending that holds.

**Build in code.**
- SVG logo with paths as strokes: draw-on with `stroke-dasharray` / `stroke-dashoffset` (or GSAP DrawSVG) over 7 to 15 f, then fill.
- Pixel and cell dissolves: canvas or WebGL with a step function per cell, `cell visible = hash(i) < progress`, seeded hash.
- Construction-led motion: compute the mark's geometry in code (a dot on a circular path that leaves a trail = EDP principle) so the animation is the logo's recipe.
- Alpha export: render PNG sequence with transparent background, then `ffmpeg -c:v prores_ks -profile:v 4444 -pix_fmt yuva444p10le` or WebM VP9 with alpha.

---

## 10. Documentary and Vox style

**What.** Reported video essays: archival footage, documents, maps, paper textures, highlighter annotations, narrated.

**When.** History, geopolitics, business stories, "how X works", investigative explainers.

**Exemplars.**
- **Johnny Harris** (youtube.com/@johnnyharris). Former Vox reporter; makes his maps with the GEOlayers plugin for After Effects (used for about 8 years), with Mapbox Studio for custom map styles; music by Tom Fox [V: aescripts, Glasp summary of his tutorial]. Emmy-winning; collaborates with OldMapsOnline [V].
- **Vox** (youtube.com/@Vox). Explainers built on visual evidence, numbers, shape annotations and VO [V: Press Gazette, Kapwing].
- **Dhruv Rathee** (youtube.com/@dhruvrathee). Hindi-English narration with charts, graphics, news clippings, and map animations that zoom into regions and highlight borders [V: Khaleej Times; freelance briefs describing the look].
- **NYT video** (nytimes.com/video). A Motion Graphics team in Digital News Design builds animated graphics for news explainers and Visual Investigations (maps, charts, diagrams) [V: NYT job listings].

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| Map fly-to | continent to city in 2 to 4 s with `power2.inOut` on zoom (zoom is logarithmic, so ease in log space) | WD |
| Border highlight | stroke draws on in 12 to 20 f, then fill to 20 to 30% opacity | WD |
| Document reveal | scanned page slides in 12 f, camera pushes to the key line, highlighter wipes left to right at about 40 to 60 characters per second | WD |
| Archival treatment | grain 3 to 6% amplitude, gate weave 0.5 to 1.5 px, vignette at frame edges only | WD |
| Halftone | 45 degree screen angle, 60 to 120 lines across the frame for a print look | WD |
| Ken Burns on stills | 3 to 6 s, 100% to 110 to 115% scale | WD |

**Sound grammar.** VO-led, intimate mic; archival audio with its own hiss left in; paper and page-turn foley on document moves; a tense score with drops to silence at revelations [WD].

**Ratio and length.** 16:9, 8 to 25 min; 9:16 single-fact cutdowns of 45 to 90 s.

**Cheap vs premium.** Cheap: Google Earth zoom with watermark, stock "old paper" overlay on everything, red circles and arrows, highlighter that does not follow text lines. Premium: custom map style in the brand palette, archival treated consistently, documents real and sourced on screen, annotations that track the exact words.

**Build in code.**
- Maps: MapLibre GL (open, WebGL) with a styled vector source; set the camera per frame with `map.jumpTo({center, zoom, bearing, pitch})` computed from `t`, and wait for the `idle` event before capture so tiles are loaded. Or render TopoJSON (world-atlas) with d3-geo to SVG for fully deterministic, offline maps.
- Interpolate the fly path with d3's `interpolateZoom` (van Wijk and Nuij smooth zoom), which is the same math MapLibre's `flyTo` uses.
- Paper: SVG `feTurbulence` (fractal noise, seeded) blended with `mix-blend-mode: multiply` at 10 to 20%; or a scanned paper texture.
- Halftone and grain: stateless fragment shaders from `t` (HyperFrames `halftone-field`, `grain-overlay`, media-treatment presets) [V repo audit].
- Highlighter: a rect behind the text line with `scaleX` 0 to 1, `transform-origin: left`, one rect per line from `getClientRects()`.

---

## 11. Data and chart motion

**What.** Charts that build, morph and annotate in time with a narrative.

**When.** Reports, finance, climate, product metrics, any claim with a number.

**Exemplars.**
- **Bloomberg, "What's Really Warming the World?"** (2015) by Eric Roston and Blacki Migliozzi, with NASA GISS data; a scrollytelling sequence that adds one factor at a time against observed temperature; inspired by the children's book "Where's Spot?"; also criticised for its charting choices [V: Data Stories ep. 59, Daily Maverick].
- **The Pudding** (pudding.cool). Visual essays with fewer words than conventional journalism; a small collective of journalist-engineers; a piece takes days to months; runs mostly on scroll-triggered reveals, pinned sections and progress-linked animation [V: Wikipedia, Storybench].
- **John Burn-Murdoch, FT.** Coronavirus trajectory charts in D3 under a strict FT chart style guide, log y-axis for growth [V: Eye Magazine, WEF].
- **Hans Rosling, "200 Countries, 200 Years, 4 Minutes"** (BBC Four, The Joy of Stats, 2010): about 120,000 data points, life expectancy vs income from 1810, 4:48, AR overlay, sports-commentator narration [V: Brain Pickings, Transcend, HNN].
- **NYT Graphics and Motion Graphics** (see style 10).

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| Build order | frame and axes first (8 to 12 f), then data, then annotation on the spoken number | WD |
| Number shown before spoken | the figure on screen before the voice finishes saying it | V (motionmaxxing M945) |
| Bar grow | 12 to 20 f, `power3.out`, bars staggered 1 to 3 f | WD; stagger V |
| Line draw | 1 to 3 s for a full series, linear in x (time is linear), with the leading point marked | WD |
| Counter | one value per frame for the roll, end on the final frame with a tick or a soft riser | V (motionmaxxing SFX table) |
| Chart morph | bar to line or scale change 15 to 24 f, `power2.inOut`; keep the highlighted series identity (colour, label) through the morph | WD |
| Highlight | one series in colour, others 30 to 40% grey | WD |
| Reading hold | 1.5 to 3 s on a final chart; slow 3 to 5% push | V (echris6 push) |

**Sound grammar.** Ticks on counters (every 3rd to 4th value), a soft riser across rolls, silence on the key number, VO states the insight not the axis [V tick rule motionmaxxing; rest WD].

**Ratio and length.** 16:9 for explainers; 1:1 or 4:5 for social charts; 10 to 30 s per chart beat.

**Cheap vs premium.** Cheap: chart-junk 3D bars, every bar bouncing, counters with too many decimals, legends instead of direct labels, pie charts spinning. Premium: direct labels, one highlighted series, honest axes (zero baseline for bars), annotation in plain language, motion that shows change (the morph is the insight).

**Build in code.**
- D3 for scales and shapes, but not D3 transitions (they are clock-based and not seekable). Compute `y = d3.interpolate(a, b)(ease(p))` from `t` per frame.
- Path morphs between different chart types: flubber; line draw via `stroke-dashoffset` on a measured `getTotalLength()`.
- Counters: `Math.round(lerp(a, b, ease(p)))` with `font-variant-numeric: tabular-nums` so digits do not jitter.
- HyperFrames `nyt-graph` example and `animated-chart` skill as starters [V repo audit].

---

## 12. Collage, mixed media and Gen Z editorial

**What.** Cut-out photos, paper, tape, stickers, scans, flash photography, stop-motion cadence, loud type, layered like a zine; the 2025 to 2026 Instagram editorial look.

**When.** Fashion, music, youth brands, event promos, carousels turned into reels, personal brand.

**Exemplars.**
- **Trend signal.** Storyblocks' 2026 Video Trends Guide names collage and mixed-media animation (drawn subjects layered over paper cutouts, clay and objects) as a rising trend; Prolific Studio's 2025 piece cites collages, painted textures and "motion that feels off on purpose" as a reaction against gloss [V, industry blogs].
- **Lucinda Schreiber for Target x Christian Robinson** (Not To Scale): frames drawn digitally, rebuilt in hand-painted paper with a vector cutter, shot in sequence in camera [V: nottoscale.tv].
- **Alfalfa Studio for Kate Spade New York**, "Chocolate": paper-collage stop motion [V: alfalfastudio.com].
- **"brat"** (Charli XCX, 2024): cover by Brent David Freaney of Special Offer Inc.; five months of design, about 500 shades of green tested, a stretched Arial Narrow-like lowercase set to feel "off-putting and kind of garish" [V: AOL/NYT interview, Poster House, Fontmeme]. The meme template became a summer-long editorial format.
- **Spotify Wrapped 2025**: a "visual mixtape" art direction from 80s and 90s DIY audio culture and club flyers, reduced palette, heavy imagery; motion built in Rive; design by Spotify's Global Brand and Creative team with Good Soup Collective [V: Spotify Newsroom, Creative Review, Rive].
- **It's Nice That** collage tag (itsnicethat.com/media/collage), including a June 2026 feature on animator Dhrutika Khimani's tactile approach [V].

**Signature techniques with numbers.**

| Technique | Value | Tag |
|---|---|---|
| Stop-motion cadence | quantise time to 8 to 12 fps (hold each pose 3 or 2 f at 24; 3 to 4 f at 30) | WD; method V (HyperFrames `stop-motion-cadence`, floor(t*fps)/fps) |
| Element jitter on hold | 0.5 to 2 px and 0.3 to 1 degree per pose, seeded per element | WD |
| Cutout entry | lands in 1 to 3 f with a 2 to 5 degree rotation, no easing (a hand placing it) | WD |
| Flash photo cut | 1 to 2 f white, then the image with blown highlights and hard shadow; max 3 per second | WD + WCAG V |
| Freeze-frame dressing | freeze the subject on the beat, cut them out, add tape, outline (4 to 8 px white) and a shadow offset | concept V (HyperFrames `freeze-frame-dressing`) |
| Shot length | 4 to 10 f per plate in montage, 0.5 to 1.5 s on hero frames | WD |
| Type | one condensed grotesk or one narrow sans, oversized, tight, in a single acid or neutral colour | WD |

**Sound grammar.** Paper rustle, tape, shutter clicks, camera flash pops, record scratches; a song with a hard drop; cuts on snares [WD].

**Ratio and length.** 9:16 and 4:5, 7 to 20 s.

**Cheap vs premium.** Cheap: stock "torn paper" PNG packs, every image with the same white border and drop shadow, AI-generated collage with mushy edges, random stickers. Premium: real scanned materials (paper grain, tape translucency), a consistent hand (cut edges with the same scissors), a grid under the chaos, photographs that carry real light (on-camera flash), and the type doing the editorial work.

**Build in code.**
- Cutouts: local background removal (HyperFrames `hyperframes-media` uses u2net) to transparent PNGs; outline via CSS `filter: drop-shadow(0 0 0 white)` stacked 4 to 8 times, or an SVG `feMorphology dilate` outline.
- Torn edges: SVG mask with a seeded jagged polyline; paper texture as a multiply layer.
- Cadence: `const tq = Math.floor(t * 10) / 10;` then compute every position from `tq`.
- Flash: full-frame white overlay 1 to 2 f, then the photo with `filter: contrast(1.3) brightness(1.15)` decaying to normal over 6 f.
- Method: generate or shoot one approved still, split into 3 to 5 layers, move only those (aijiduonadegou `Paper-Cut`, MIT) [V repo audit].

---

## 13. Cut and transition grammar

The global rule from the measured studies: a cut works when A accelerates into it (biggest step in the last 3 to 8 f) and B's first frame is already moving or already built [V motionmaxxing]. About 96% of pro moments use hard cuts [V]. Walter Murch's "Rule of Six" (In the Blink of an Eye) ranks what a cut must serve: emotion 51%, story 23%, rhythm 10%, eye-trace 7%, 2D screen plane 5%, 3D space 4% [V, secondary reproductions]. For an automated editor, eye-trace is the one code can measure: put B's focal point within about 10% of frame of where A's focal point was on the last frame [WD]. Everything below is a variation on hiding or emphasising that moment.

### Hard cut
- **Definition.** Instant switch from A to B.
- **Length.** 0 f.
- **Works when.** Always the default; strongest when cut on action at peak velocity.
- **Code.** Two scenes, swap visibility on the cut frame: `tl.set(a, {autoAlpha:0}, T).set(b, {autoAlpha:1}, T)`. Start B's internal tweens a few frames before T so it enters mid-motion.

### J cut and L cut (split edits)
- **Definition.** J: B's audio starts before B's picture. L: A's audio continues over B's picture [V: Wikipedia, Adobe].
- **Length.** J lead 6 to 24 f; L tail 15 to 45 f (the speaker's last 1 to 2 words over the listener) [WD].
- **Works when.** Dialogue and interviews (L is the default for conversation), scene changes led by sound (J builds anticipation).
- **Code.** Separate audio and picture tracks in the timeline model: `{video:{in,out}, audio:{in:in - lead, out:out + tail}}`. ffmpeg: `adelay` on B's audio, `atrim` on A's.

### Match cut (graphic, action, sound)
- **Definition.** A and B share shape and position (graphic), a continuing movement (action) or a sound bridge (sound).
- **Length.** 0 f.
- **Numbers.** Match position within about 2% of frame, plus scale, colour and velocity vector; start B mid-motion [V motionmaxxing: a dot at (0.28, 0.50) becomes the next shape's seed at (0.27, 0.50)].
- **Code.** Pre-position B's object at A's last coordinates (`getBoundingClientRect` of A, set B's transform before the cut); continue the same tween velocity across the cut using mirrored eases. Sound match: carry one sound across both sides.

### Smash cut
- **Definition.** An abrupt cut from intensity to calm or the reverse, usually with an audio cut to silence or to loud.
- **Length.** 0 f; often after a 2 to 6 f pre-lap of silence [WD].
- **Works when.** Comedy, reveals, contrast hooks.
- **Code.** Hard cut plus instant audio state change (`volume` 1 to 0 on the cut frame); no tail on SFX.

### Jump cut
- **Definition.** A cut within the same framing that skips time.
- **Length.** 0 f; cuts typically 1 to 5 s apart in talking heads [V Choppity ranges].
- **Works when.** Removing pauses; showing time passing in one place (Neistat montage).
- **Code.** EDL from transcript gaps; alternate punch-in scale to hide or embrace the jump.

### Punch-in
- **Definition.** Cut (not zoom) to a tighter crop of the same shot.
- **Length.** 0 f; hold the tight framing at least 1.5 s [WD].
- **Numbers.** 112 to 130% [WD]; 4K to 1080 gives 200% headroom.
- **Code.** Instant `scale` change on the cut frame with origin on the subject.

### Whip pan
- **Definition.** A very fast pan that blurs, cutting inside the blur.
- **Length.** Measured median 8 f, peak about 13% of frame width per frame at t = 0.25 of the move; one crisp version moved 27% of travel in the first 10 f, 31% in 2 f, 49% in the 4 f around the peak [V motionmaxxing]. Tutorials use 7 to 15 f total, cut placed 5 f into a 10 f move, or 5 f before and 10 f after [V: Shotcut forum, Creative Cow, tutvid]. At 60 fps double the frame counts.
- **Works when.** Location or topic jumps with energy; vlogs, music edits.
- **Code.** Translate the whole scene container on a `power4.in` / `power4.out` pair; directional blur at peak: CSS `filter: blur()` is isotropic, so use an SVG `feGaussianBlur stdDeviation="40 0"` (x only), or a WebGL directional blur sampling 12 to 24 taps along the motion vector; tutvid's Premiere version uses Directional Blur at 90 degrees, length 250 [V]. SFX: airy whoosh 0.3 to 0.5 s starting 3 to 4 f before peak velocity [V motionmaxxing].

### Speed ramp
- **Definition.** A continuous change of playback speed within one shot.
- **Length.** Ramps of 4 to 10 f between speeds; slow section 10 to 30 f [WD]. CapCut range 0.1x to 10x [V].
- **Works when.** Payoff moments in action, sport, travel, product hero.
- **Code.** Define speed s(t), integrate to source time; for footage set `video.currentTime`; for graphics `timeline.time(src(t))`. For real slow motion from 30 fps sources, frame interpolation is needed: `ffmpeg -vf "minterpolate=fps=120:mi_mode=mci"` then sample, or use RIFE offline.

### Zoom-through (and inverse)
- **Definition.** Push into A until it blows past the camera, B arrives from depth (inverse: A recedes, B arrives from in front).
- **Numbers (HyperFrames cut-the-curve)** [V]: exit scale 1 to 1.2, blur 0 to 10 px, opacity 1 to 0.15, 0.2 s `power3.in` (opacity on its own linear tween); entry scale 0.75 to 1, blur 10 to 0 px, 0.5 s `expo.out`; total about 0.7 s, 30% exit and 70% entry. Inverse: exit 1 to 0.8, entry 1.25 to 1. Z scale-sign rule: if A grows, B must also come from smaller to normal (the camera keeps moving forward).
- **Blur-matched variant** [V motionmaxxing]: ramp the exit blur over 3 to 8 f, end it at 18 px; start the entrance at 80 px and resolve in about 8 f.
- **Code.** Two layers with transforms and `filter: blur()`; or gl-transitions `CrossZoom`.

### Morph cut
- **Definition.** Adobe Premiere Pro's transition (added 2015) that uses face tracking and optical-flow interpolation to hide a jump cut in a talking head.
- **Length.** Short, about 4 to 12 f [WD]; works only when head position barely changes and the background is static.
- **Code.** True morph needs optical flow (RIFE or ffmpeg `minterpolate` between the two frames). Cheaper and often better: a punch-in or a B-roll insert over the joint.

### Light leak
- **Definition.** Warm light bleeding across the frame, usually over a cut.
- **Length.** 12 to 30 f @30 [WD].
- **Works when.** Nostalgia, memory, warm brand films, wedding and travel.
- **Code.** Stateless shader of low-frequency noise from `t`, additive blend, anchored to a frame edge (keep it off the centre). HyperFrames ships `light-leak` and `organic-light-leak-overlay` [V].

### Flash frame
- **Definition.** 1 to 2 frames of white (or colour) at the cut.
- **Length.** 1 to 2 f @30, 2 to 4 f @60. Measured "click (1 f flash)" and "ring pop (1 f at 3x)" as single-frame hits [V motionmaxxing].
- **Works when.** Beats, camera-flash looks, impact.
- **Code.** Overlay `opacity` 1 on the cut frame, 0 one or two frames later (no tween). Limit to 3 per second (WCAG).

### Film burn
- **Definition.** Orange and white emulsion burn sweeping through the frame, as when film runs out.
- **Length.** 12 to 24 f [WD].
- **Works when.** Endings, analog moods, music videos.
- **Code.** Shader: threshold an animated fbm noise field, colour ramp from transparent to orange to white, additive; or pre-rendered overlay plates with `mix-blend-mode: screen`.

### Glitch
- **Definition.** Digital corruption: slice offsets, RGB split, blocks.
- **Length.** Measured: localized rectangles for 6 f with one hard cut inside, sizes matched to A's last and B's first object; never a whole-frame glitch pass [V motionmaxxing].
- **Works when.** Tech, error states, music; sparingly.
- **Code.** `clip-path: inset()` slices with seeded x offsets, or a shader with `hash(floor(uv.y*rows), floor(t*fps))`. Avoid three.js `GlitchPass` and pmndrs `GlitchEffect` in a seek renderer: both call `Math.random()` [V prior source audit].

### Luma and mask wipe
- **Definition.** B revealed through a mask: a luminance matte (luma), a feathered edge, or a moving clip edge.
- **Length.** Clip edge sweep 5 f accelerating, cutting mid-glyph; two soft masks with the erase front about 0.1 s ahead of the reveal front [V motionmaxxing]. Luma fades 10 to 20 f [WD].
- **Code.** CSS `mask-image: linear-gradient()` with an animated position; luma via WebGL `smoothstep(p - e, p + e, luminance(texB))`.

### Shape wipe
- **Definition.** A graphic shape (bar, circle, tile grid, stair) sweeps across and leaves B behind.
- **Length.** Stair wipe with 80 px steps; tile wipe used sparingly as a chapter break [V motionmaxxing, echris6]. 8 to 15 f [WD].
- **Code.** A grid of divs scaling 0 to 1 with a diagonal stagger of 1 f; or an SVG shape whose transform covers the frame at the midpoint, with the scene swap hidden at full cover.

### Push and slide
- **Definition.** B pushes A out of frame (or slides over it).
- **Numbers.** Prefer partial travel (about 12% of frame) with an early fade and mirrored `power4` eases: exit 0.34 s `power4.in`, entry 0.3 s `power4.out` at word level [V HyperFrames]. Full-frame pushes 8 to 15 f [WD].
- **Code.** Container `xPercent` tweens on one timeline, exit and entry halves of one `power4.inOut`.

### Rack focus
- **Definition.** Focus shifts from one plane to another; as a cut, A blurs out and B resolves in.
- **Numbers.** Eases `power2.in` / `power2.out` (soft optics, not momentum); entry at least as long as exit; 10 px blur for text, 18 to 20 px for full frame [V HyperFrames].
- **Code.** `filter: blur()` on the two planes; in three.js the pmndrs DepthOfField effect with an animated focus distance.

### Iris
- **Definition.** A circle opens on or closes to a point.
- **Length.** 10 to 20 f [WD].
- **Works when.** Retro, comedic endings, focusing on a subject before a cut.
- **Code.** `clip-path: circle(R at x y)` with R from 0 to the frame diagonal; ffmpeg `xfade=transition=circleopen`.

### Crossfade (dissolve)
- **Definition.** A fades out while B fades in.
- **Length.** 10 to 24 f [WD].
- **Why it reads cheap.** During a dissolve both images sit at partial contrast, so the frame turns to mush and the eye has nothing to hold; it is the default transition of every slideshow tool, so it signals "template." Measured pros used 584 opacity fades against 3,392 transform entries, and motionmaxxing's rule is no crossfades between scenes: hard cut, mask wipe, or let an effect become the next scene; fade only a single object [V].
- **When it still works.** Passage of time in documentary, a slow music-led montage, a memory, a deliberate long dissolve (2 s+) used as a style.
- **Code.** `opacity` tweens, or ffmpeg `xfade=transition=fade:duration=0.5:offset=T`.

**ffmpeg xfade transitions** available for quick assembly: fade, fadeblack, fadewhite, dissolve, wipeleft and relatives, slideleft and relatives, circleopen, circleclose, radial, pixelize, hblur, zoomin and others: `ffmpeg -i a.mp4 -i b.mp4 -filter_complex "xfade=transition=pixelize:duration=0.4:offset=4.6" out.mp4`.

---

## 14. How people make motion videos with Claude in 2026

**Claude Motion (Anthropic).** Announced in beta on 8 October 2026 alongside Claude Dashboards, for Team and Enterprise plans: prompts become playable animated explanations; Claude writes code that animates text, charts, shapes and images (no video generation model), editable in place or by asking Claude, downloadable as MP4. Docs, Slides and Design left beta at the same time [V, secondary coverage: TestingCatalog, FourWeekMBA, Pasquale Pillitteri]. I found no first-party Anthropic post in search results. This is Edits' most direct competitor.

**HyperFrames by HeyGen** (github.com/heygen-com/hyperframes, Apache-2.0). HTML, CSS, media and seekable animation rendered to deterministic MP4 through headless Chrome and FFmpeg; Node 22+; open-sourced 17 April 2026 per one listing; skills install with `npx skills add heygen-com/hyperframes`; a Claude connector exists (claude.com/connectors/hyperframes-heygen) [V]. Determinism rule: no `Date.now`, no `requestAnimationFrame`, no unseeded `Math.random`; it seeks GSAP, CSS, Anime.js, Lottie, three.js, WAAPI and TypeGPU itself [V]. Registry of about 457 seek-safe blocks (whip-pan, camera-shake, glitch, light-leak, beat-freeze-cut, paper-collage-reveal, product-turntable and more) and six internal craft skills in `.claude/skills` (motion-doctrine, cut-the-curve, seam-craft, captions-overlay, oversized-cursor, changelog-video) [V repo audit, 22 Oct 2026].

**Claude Code + Remotion.** Remotion launched Agent Skills in early January 2026 (`npx remotion skills add`; remotion-dev/skills, 12 skills including captions, render, docs); officially supports Claude Code, Codex, Kimi Code and OpenCode [V: StartupHub, Tella]. Licence: free for individuals and companies up to 3 employees, paid company licence above that [V]. Templates: template-tiktok (Whisper captions), template-audiogram, template-three.

**Higgsfield.** A "MCP for Motion Designers" guide connects Claude to Higgsfield's MCP server with a downloadable "Motion Design Skill" file; "Vibe Motion" is a no-code, Claude-powered motion graphics product; Higgsfield posted a pipeline where Claude orchestrates Higgsfield visuals, Blender 3D and After Effects and outputs an editable AE project [V: higgsfield.ai blog, Lets Data Science, AIPostHub]. A Mammoth Club course on Claude Code + After Effects with the Higgsfield MCP is taught by James Dabalus [V]. **I could not verify a guide by "Sanji Chien"** in any search; send the post URL if it exists.

**Howseen** (github.com/howseen-ai/claude-motion-design, MIT). Pure `seek(t)` HTML rendered with Playwright and ffmpeg; pipeline: brief, beat map (every scene on a beat, the drop on the key visual), 4 approved stills before the full render, subframe shutter motion blur, SFX placed on measured peaks, loudness at -14 LUFS, loop-seam QA, harsh critique loop [V: Trendshift, SkillsLLM, repo].

**Josh Blatchford's motion library** (instagram.com/joshuablatch; reel Dej-O7zKLww for @attuned_health). A numbered library page of motion graphics in one look (MG01 Signal, MG02 Transitions...); a rule file `Motion/OPPORTUNITIES.md` ("Ideas only. Josh picks from options before anything is built"); Claude reads each new transcript against the catalogue and logs a pitch (timestamp, exact line, idea, why nothing existing works); approve or pass; 2 to 3 directions as stills; build; add to the library [V: transcribed from the reel, 22 Oct 2026]. The idea for Edits: a brand's own component library as the memory that stops every Claude film looking the same.

**motionmaxxing** (github.com/Tejashmakwana/motionmaxxing, Apache-2.0, about 1.1k stars). HTML motion with measured timing (the numbers used throughout this doc), render checks, a slop autopsy of 25 default AI patterns; author reports 9 of 10 blind picks favoured the with-skill film (one rater, earlier version) [V].

**Other repos worth reading** (stars and licences checked via GitHub API on 22 Oct 2026) [V]:
- echris6/motion-video-kit (MIT): `business-motion-film`, builder-is-never-the-judge critic loop, 16 mechanisms, 28 launch films.
- charlie947/motion-graphics-skills (MIT): `brand-intake` (brand.md + MOTION.md), `reel-export` (9:16 safe zones, bt709, ffprobe check), `reference-to-motion`, `vox-explainer`, `title-sequence-3d`.
- Barty-Bart/motion-graphics (MIT, CC0 SFX): `sound-effects` (beat grid against kick drums, one SFX per cue, -16 LUFS, true peak below -4 dBFS), `motion-broll`, `explainer-high-energy`. Its sound pass credits a prompt by @Voxyz_ai (x.com/Voxyz_ai/status/2109358372873183564, 11 Oct 2026).
- Sunwood-ai-labs/hyperframes-motion-reel-skill (MIT): `b(n)` beat grid, bans plain fade chains.
- lemomo-ai/lemo-opuscar (MIT, about 5k stars): 59 film styles as STYLE.md specs with demo code (risograph, halftone-dossier, swiss-motion, cel-anime-80s, kino-montage, papercut-red).
- tugrawork-creator/saas-motion-kit (MIT): 101 themes, 24-transition atlas, variety audit.
- latent-spaces/brag (MIT): repo to 20 s launch video.
- Vincentwei1021/video-shotcraft (Apache-2.0): 124 recipe cards, Remotion.
- zhuyansen/awesome-claude-video-skills: an index of about 180 video skill repos, security-graded.
- Licence traps: imMamdouhaboammar/motion-graphics-skills is "all rights reserved"; feitangyuan/onetake and pv-tool are non-commercial; OpenMontage, DepthFlow and essentia.js are AGPL; Remotion needs a company licence above 3 people [V repo audit].

**Patterns common to the serious pipelines** (what Edits should bake in):
1. Seek-driven rendering: every pixel a pure function of `t`; seeded randomness; stateful effects (datamosh, feedback trails) pre-rendered.
2. A beat map or word map first; cuts placed on frames from it, not on round numbers.
3. Stills before motion: 3 to 4 frames approved before a full render (Howseen, Josh, xilo-opus-video).
4. A critic that is not the builder, plus automated gates (no static stretch over 0.6 s, hold 0.6 to 1.4 s at the end, loudness, flash safety).
5. A brand kit and a component library as memory.

---

## Sources

Hook and short-form
- Tubefilter, MrBeast leaked production guide: https://www.tubefilter.com/2024/09/17/mrbeast-internal-production-guide-leaked-key-points/
- Simon Willison, How to succeed in MrBeast production: https://simonwillison.net/2024/Sep/15/how-to-succeed-in-mrbeast-production/
- Creator Handbook, MrBeast document takeaways: https://www.creatorhandbook.net/leaked-document-allegedly-reveals-mrbeasts-secrets-to-youtube-success-the-key-takeaways/
- Passionfruit, leaked handbook: https://passionfru.it/mrbeast-leaked-document-81151/
- OMR (German summary): https://omr.com/de/daily/mrbeast-doc-pdf-leak
- Submagic, Hormozi captions: https://www.submagic.co/blog/how-to-make-alex-hormozi-captions
- Kapwing, Hormozi captions template: https://www.kapwing.com/explore/hormozi-style-captions-template
- Choppity, Ali Abdaal style: https://www.choppity.com/tools/recreate-video-editing-style/ali-abdaal/
- SendShort, Iman Gadzhi style: https://sendshort.ai/guides/iman-gadzhi-style/
- Social Media Today, Reels to 3 minutes: https://www.socialmediatoday.com/news/instagram-officially-expands-reels-length-3-minutes/737766/
- Storyboard18, Reels 3 minutes: https://www.storyboard18.com/amp/digital/instagram-extends-reels-to-three-minutes-and-updates-profile-layout-54043.htm
- PhoneArena, Instagram Edits app: https://www.phonearena.com/news/instagram-just-launched-edits-a-video-editing-app-that-capcut-should-be-worried-about_id169658
- Social Samosa, Edits announced: https://www.socialsamosa.com/news-2/instagram-announces-new-video-editing-app-edits-8636483
- Android Authority, Edits: https://www.androidauthority.com/instagram-announces-edits-app-3518054
- Powerdrill, short-form fatigue: https://powerdrill.ai/blog/why-your-tiktok-and-reels-views-are-down
- mean.ceo trends June 2026: https://blog.mean.ceo/short-form-video-marketing-trends-june-2026/
- Kotaku, Subway Surfers split screen: https://kotaku.com/subway-surfers-tiktok-corecore-video-collage-psychology-1850061976
- Trill, split screen: https://www.trillmag.com/life/social-media/is-the-tiktok-split-screen-destroying-modern-movie-watching/
- FOOH library, Jacquemus: https://fooh.com/library/jacquemus-driving-bags-rolling-in-paris
- FOOH library, Maybelline: https://fooh.com/library/137-maybelline-subway-bus-lashes-fooh-ad
- WWD Japan, Jacquemus views: https://www.wwdjapan.com/articles/1714246

Vlog
- Artlist, Casey Neistat techniques: https://artlist.io/blog/editing-storytelling-techniques-casey-neistat/
- No Film School, Neistat storytelling: https://nofilmschool.com/2016/08/7-storytelling-techniques-you-can-learn-filmmaker-youtube-star-casey-neistat
- Indepthcine, Casey Neistat: https://indepthcine.com/videos/casey-neistat
- Laughing Squid, Nerdwriter on Neistat: https://laughingsquid.com/an-insightful-analysis-showcasing-the-unique-style-of-casey-neistats-seemingly-effortless-daily-vlog/
- PremiumBeat, Neistat interview: https://www.premiumbeat.com/blog/casey-neistat-creative-video-content/
- No Film School, in-camera transitions: https://nofilmschool.com/2017/12/check-out-awesome-method-making-your-own-camera-transitions
- Videomaker, B-roll cinematic: https://www.videomaker.com/videonews/2017/09/use-more-b-roll-to-instantly-make-your-videos-look-more-cinematic/
- 4K Shooters, Sam Kolder style transitions: https://4kshooters.net/2018/06/14/download-these-dope-sam-kolder-style-free-premiere-pro-transitions
- Adobe Community, Kolder fly-through: https://community.adobe.com/questions-529/sam-kolder-fly-through-effect-35432
- Onesheet, Matt D'Avella: https://onesheet.org/person/matt-d-avella
- Tubefilter, Emma Chamberlain editing hours: https://tubefilter.com/2019/06/10/emma-chamberlain-30-hours-editing-each-vlog/
- Wikipedia, Emma Chamberlain: https://en.wikipedia.org/wiki/Emma_Chamberlain
- W Magazine, Emma Chamberlain: https://www.wmagazine.com/story/emma-chamberlain-youtube-interview

Talking head and podcast
- Opus Clip, DOAC clips channel case: https://opus.pro/how-doac-scaled-to-2m-subscribers-using-opuslip
- FlightStory short-form editor listing: https://www.netinfluencer.com/jobs/short-form-content-editor-the-diary-of-a-ceo-at-flightstory/
- The Current, Raj Shamani: https://www.thecurrent.com/opinion/partners-audience-trust-podcast-figuring-out-raj-shamani
- Fueler, Raj Shamani Shorts editor: https://fueler.io/yasinalyani/shortsreels-for-figuring-out-by-raj-shamani
- Vizard, punch-in cadence: https://agent.vizard.ai/how-to/stop-the-punch-ins-cycling-too-fast-in-a-talking-head-edit.html
- Subscribr, talking head editing: https://subscribr.ai/p/editing-talking-head-videos-engaging
- Rizzle, podcast shorts: https://rizzle.com/blog/post/what-to-include-in-your-podcast-shorts

Music-synced and safety
- CapCut, velocity edit: https://www.capcut.com/explore/capcut-velocity-edit
- VideoProc, velocity edit: https://www.videoproc.com/video-editor/how-to-make-a-velocity-edit.htm
- Nemo, CapCut speed ramp: https://www.nemovideo.com/blog/capcut-slow-motion-speed-ramp
- Alternative Press, sped-up songs: https://www.altpress.com/tiktok-sped-up-songs-music-explained/
- Know Your Meme, sped-up audios: https://knowyourmeme.com/editorials/guides/why-are-sped-up-tiktok-audios-so-popular-how-to-speed-up-songs-for-tiktok-explained
- Wikipedia, Anime music video: https://en.wikipedia.org/wiki/Anime_music_video
- Anime Herald, AMV.org history panel: https://www.animeherald.com/2026/08/15/anime-boston-2026-the-animemusicvideos-org-history-panel-with-phade/
- UK Anime Network, AMV Hell: https://uk-anime.net/newsitem/AMV_Hell_Returns
- W3C, Understanding SC 2.3.1: https://www.w3.org/WAI/WCAG21/Understanding/three-flashes-or-below-threshold
- Ofcom (ITC) flashing images guidance: https://www.ofcom.org.uk/__data/assets/pdf_file/0021/16248/gn_flash.pdf
- ASA ruling, Citroën: https://www.asa.org.uk/rulings/citroen-uk-ltd-a11-164759.html
- DAISY KB, three flashes: https://kb.daisy.org/publishing/docs/wcag/three-flashes-or-below-threshold.html
- Wikipedia, EBU R 128: https://en.wikipedia.org/wiki/EBU_R_128

SaaS and launch films
- echris6/motion-video-kit: https://github.com/echris6/motion-video-kit
- motion-grammar.md: https://raw.githubusercontent.com/echris6/motion-video-kit/main/business-motion-film/references/motion-grammar.md
- launch-film-notes.md: https://raw.githubusercontent.com/echris6/motion-video-kit/main/business-motion-film/references/launch-film-notes.md
- Vincentwei1021/video-shotcraft: https://github.com/Vincentwei1021/video-shotcraft
- It's Nice That, Figma Config 2024 identity: https://www.itsnicethat.com/features/figma-config-2024-identity-graphic-design-spotlight-090724
- Figma blog, Config 2026 visual identity: https://www.figma.com/de-de/blog/the-visual-identity-behind-config-2026/
- Tecnoblog, Figma Motion: https://tecnoblog.net/noticias/figma-quer-peitar-after-effects-com-motion-gerado-por-ia/
- Linear careers, Motion Storyteller: https://linear.app/careers/2cf28db7-821f-44a0-99ee-ee0b7b7581af
- Vercel motion designer listing: https://www.workingnomads.com/jobs/motion-designer-brand-vercel
- Stripe, Motion Designer Experiential: https://stripe.com/jobs/listing/motion-designer-experiential/8047129
- Tella, The Browser Company video: https://www.tella.com/blog/the-browser-company-video
- CSS-Tricks, Apple scroll animation: https://css-tricks.com/?p=308477
- Apple HIG, Motion: https://developer.apple.com/design/human-interface-guidelines/motion

Kinetic type
- BFI, Saul Bass essential titles: https://www.bfi.org.uk/lists/celebrating-saul-basss-centenary-10-essential-title-sequences
- Art of the Title, Anatomy of a Murder: https://www.artofthetitle.com/title/anatomy-of-a-murder
- MovieMaker, title sequences: https://www.moviemaker.com/using-movie-title-sequences-effectively/
- Wikipedia, Kyle Cooper: https://en.wikipedia.org/wiki/Kyle_Cooper
- Imaginary Forces, Se7en: https://imaginaryforces.com/project/se7en
- TypeRoom, Studio Dumbar: https://www.typeroom.eu/from-north-sea-jazz-festival-to-amsterdam-sinfonietta-type-like-music-with-studio-dumbars-forward-thinking-kinetic-typographic-brilliance
- Studio Dumbar, Cities in Motion: https://studiodumbar.com/work/cities-in-motion
- Cartoon Brew, Animography: https://cartoonbrew.com/internet-blogs/animography-wants-to-bring-animated-typography-to-the-masses-84065.html
- AIGA Eye on Design, animated fonts: https://eyeondesign.aiga.org/new-animated-fonts-that-will-make-your-stationery-serif-seem-dead-by-comparison/
- School of Motion, Jordan Bergren: https://schoolofmotion.com/blog/jordan-bergren-interview
- It's Nice That, DixonBaxi The CW: https://www.itsnicethat.com/news/dixonbaxi-the-cw-graphic-design-240124
- GSAP 3.13 release: https://gsap.com/blog/3-13/
- Webflow, GSAP becomes free: https://webflow.com/blog/gsap-becomes-free

2D explainers
- Kottke, Kurzgesagt 1200 hours: https://also.kottke.org/20/02/how-to-make-a-kurzgesagt-video-in-just-1200-hours
- Gigazine, Kurzgesagt process: https://gigazine.net/gsc_news/en/20200217-science-animation-making
- LingQ transcript, Kurzgesagt: https://www.lingq.com/en/learn-english-online/courses/689474/how-to-make-a-kurzgesagt-video-in-120-4887128/
- Wikipedia, Buck: https://en.wikipedia.org/wiki/Buck_(design_company)
- Motion Array, Buck spotlight: https://motionarray.com/learn/motion-design/industry-spotlight-buck/
- Communication Arts, Giant Ant: https://commarts.com/features/giant-ant
- FITC, Jay Grandin: https://fitc.ca/speaker/jay-grandin
- Motionographer, Ordinary Folk: https://motionographer.com/2019/09/16/join-the-movement/
- Stash, Ordinary Folk Mainframe: https://www.stashmedia.tv/ordinary-folk-rescues-mainframe-motion-project-from-the-bin-of-destiny/
- Film Independent, Estelle Caswell: https://www.filmindependent.org/blog/explainer-an-interview-with-vox-pop-video-essayist-estelle-caswell/
- Rive, Spotify Wrapped 2025: https://rive.app/blog/spotify-used-rive-for-spotify-wrapped-2025

3D
- Motion Array, ManvsMachine: https://motionarray.com/learn/motion-design/studio-spotlight-manvsmachine/
- It's Nice That, ManvsMachine Air Max Day: https://www.itsnicethat.com/news/manvsmachine-air-max-day-2018-graphic-design-160418
- Maxon, Man vs Machine: https://maxon.net/en/article/man-vs-machine-fusing-creativity-with-technology-with-the-help-of-cinema-4d
- AWN, Star Trek Into Darkness titles: https://awn.com/vfxworld/boldly-go-where-no-titles-have-gone
- Digital Production, Star Trek title: https://digitalproduction.com/2013/09/12/making-of-star-trek-title/
- Memory Alpha, Andrew Kramer: https://memory-alpha.fandom.com/wiki/Andrew_Kramer
- three.js MeshPhysicalMaterial: https://threejs.org/docs/pages/MeshPhysicalMaterial.html

Idents
- BGR, Netflix ta-dum: https://bgr.com/entertainment/netflix-opening-sound-goat-bleating-almost-became-intro-noise/
- Slashfilm, Netflix sound: https://slashfilm.com/netflixs-signature-launch-sound-was-almost-the-bleating-of-a-goat
- Design Week, DixonBaxi Hulu: https://www.designweek.co.uk/issues/5-11-april-2021/dixonbaxi-hulu-rebrand/
- Creative Review, Hulu branding: https://creativereview.co.uk/hulu-branding
- Creative Review, The CW: https://www.creativereview.co.uk/dixonbaxi-rebrand-us-tv-network-the-cw/
- Pentagram, EDP: https://pentagram.com/work/edp/story
- Pentagram, MTV World Creative Studio: https://www.pentagram.com/work/mtv-world-creative-studio
- Pentagram, Satalia: https://pentagram.com/work/satalia/story

Documentary and data
- aescripts, How Johnny Harris makes maps: https://aescripts.com/learn/how-johnny-harris-makes-maps/
- aescripts, GEOlayers 3: https://aescripts.com/geolayers/
- Glasp, Johnny Harris map tutorial summary: https://glasp.co/youtube/GsojLuJpe_0
- Press Gazette, Vox video: https://pressgazette.co.uk/?p=184694
- Kapwing, Vox-style videos: https://kapwing.com/resources/how-to-make-informational-videos-like-vox
- Storybench, Vox art director: https://www.storybench.org/?p=21229
- Khaleej Times, Dhruv Rathee: https://www.khaleejtimes.com/uae/indian-influencer-dhruv-rathee-youtube-videos-fact-checked?amp=1
- NYT Motion Graphics listing: https://job-boards.greenhouse.io/thenewyorktimes/jobs/4595602005
- Data Stories ep. 59, Bloomberg warming: https://datastori.es/behind-the-scenes-of-whats-really-warming-the-world-with-the-bloomberg-team-ds59/
- Daily Maverick critique: https://www.dailymaverick.co.za/opinionista/2015-07-06-bloomberg-global-warming-chart-proves-nothing/
- Wikipedia, The Pudding: https://en.wikipedia.org/wiki/The_Pudding
- Storybench, The Pudding visual essays: https://www.storybench.org/?p=8613
- Eye Magazine, John Burn-Murdoch: https://eyemagazine.com/feature/article/conversation-with-john-burn-murdoch
- WEF, coronavirus graphics: https://weforum.org/agenda/2020/04/data-visualization-5-questions-coronavirus
- Brain Pickings, Hans Rosling Joy of Stats: https://www.brainpickings.org/2010/12/03/hans-rosling-bbc/
- Transcend, 200 Countries: https://transcend.org/tms/?p=10316

Collage and editorial
- Storyblocks 2026 trends: https://www.storyblocks.com/resources/?p=33019
- Prolific Studio, animation trends: https://prolificstudio.co/blog/animation-trends/
- Not To Scale, Target x Christian Robinson: https://nottoscale.tv/work/target-bookworm
- Alfalfa Studio, Kate Spade Chocolate: https://alfalfastudio.com/chocolate
- AOL, brat cover took 5 months: https://www.aol.com/entertainment/charli-xcx-viral-brat-album-141800917.html
- Poster House, the rise and fall of brat: https://www.posterhouse.org/blog/the-rise-and-fall-of-brat/
- Fontmeme, brat font: https://fontmeme.com/brat-album-font/
- Creative Review, Spotify Wrapped 2025: https://www.creativereview.co.uk/spotify-wrapped-2025-film-lewis-capaldi-jade-pinkpanthress/
- It's Nice That, collage: https://www.itsnicethat.com/media/collage

Cuts and transitions
- Wikipedia, J cut: https://en.wikipedia.org/wiki/J_cut
- Adobe, J cut and L cut: https://www.adobe.com/creativecloud/video/discover/j-cut-and-l-cut
- tutvid, whip pan in Premiere: https://tutvid.com/premiere-pro/whip-pan-blurring-transition-effect-premiere-pro/
- Shotcut forum, whip pan: https://forum.shotcut.org/t/motion-blur-transitions-a-demo-video-tutorial-in-progress/20498
- Creative Cow, whip pan in AE: https://creativecow.net/?p=2451776
- No Film School, whip pan: https://nofilmschool.com/how-to-do-a-whip-pan
- Adobe, Morph Cut (page returned 403 to the fetcher): https://helpx.adobe.com/premiere-pro/using/morph-cut.html
- UT Austin wiki, Murch's Rule of Six (emotion 51%, story 23%, rhythm 10%, eye-trace 7%, 2D plane 5%, 3D space 4%): https://cloud.wikis.utexas.edu/wiki/spaces/rtf318/pages/80022510/Murch+s+Rule+of+Six
- gl-transitions: https://github.com/gl-transitions/gl-transitions

Claude and code pipelines
- TestingCatalog, Claude Dashboards and Motion: https://www.testingcatalog.com/claude-launches-dashboards-and-motion-in-beta.md
- FourWeekMBA, Claude Motion: https://fourweekmba.com/ai-anthropic-adds-claude-dashboards-and-motion-docs-exit-beta/
- Pasquale Pillitteri, Claude Motion beta: https://pasqualepillitteri.it/en/news/21703/anthropic-launches-claude-dashboards-motion-beta
- Layer3 Labs, Claude Motion vs Remotion: https://www.layer3labs.io/comparisons/claude-motion-vs-remotion
- HyperFrames repo: https://github.com/heygen-com/hyperframes
- HyperFrames connector: https://claude.com/connectors/hyperframes-heygen
- The Menon Lab, HyperFrames: https://themenonlab.blog/blog/heygen-hyperframes-video-as-code
- Tella, Remotion agent skills with Claude Code: https://www.tella.com/blog/how-to-use-remotion-agent-skills-with-claude-code.md
- StartupHub, Remotion AI video: https://www.startuphub.ai/ai-news/general/2026/remotion-ai-video-makes-production-code-from-plain-prompts
- remotion-dev/skills: https://github.com/remotion-dev/skills
- Higgsfield, MCP for motion designers: https://higgsfield.ai/blog/MCP-For-Motion-Designers
- Higgsfield, Vibe Motion guide: https://higgsfield.ai/blog/Higgsfield-Vibe-Motion-Guide-AI-Motion-Design
- AIPostHub, Higgsfield x Claude AE workflow: https://www.aiposthub.com/higgsfield-claude-opus-5-5-motion-design-mcp-after-effects/
- Mammoth Club course: https://mammothclub.com/course/build-motion-design-in-claude-code-and-after-effects-with-higgsfield-mcp
- howseen-ai/claude-motion-design: https://github.com/howseen-ai/claude-motion-design
- Trendshift, claude-motion-design: https://trendshift.io/repositories/265851
- Josh Blatchford reel: https://www.instagram.com/reel/Dej-O7zKLww/
- motionmaxxing: https://github.com/Tejashmakwana/motionmaxxing
- charlie947/motion-graphics-skills: https://github.com/charlie947/motion-graphics-skills
- Barty-Bart/motion-graphics: https://github.com/Barty-Bart/motion-graphics
- Sunwood hyperframes-motion-reel-skill: https://github.com/Sunwood-ai-labs/hyperframes-motion-reel-skill
- lemomo-ai/lemo-opuscar: https://github.com/lemomo-ai/lemo-opuscar
- tugrawork-creator/saas-motion-kit: https://github.com/tugrawork-creator/saas-motion-kit
- latent-spaces/brag: https://github.com/latent-spaces/brag
- zhuyansen/awesome-claude-video-skills: https://github.com/zhuyansen/awesome-claude-video-skills
- Voxyz_ai sound pass prompt: https://x.com/Voxyz_ai/status/2109358372873183564
- aijiduonadegou/Paper-Cut: https://github.com/aijiduonadegou/Paper-Cut
- flubber: https://github.com/veltman/flubber
- pmndrs/postprocessing: https://github.com/pmndrs/postprocessing
