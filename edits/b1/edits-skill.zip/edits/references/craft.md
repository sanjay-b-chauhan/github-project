# Edits: motion craft research (numbers, type, colour, compositing, code, references)

Researched 27 Oct 2026 for "Edits", the tool that lets anyone brief Claude to make After Effects quality motion in code (HTML/CSS/GSAP, HyperFrames, Remotion, WebGL, three.js). Read-only web research. Nothing downloaded, nothing paid.

Legend used on every number:
- **[S]** sourced: taken from the cited doc, spec or source code.
- **[D]** derived: calculated by me from sourced numbers (formula shown).
- **[P]** proposed Edits default: practitioner convention or my recommendation. Not a citation. Tune by eye.
- **[H]** house rule from Sanjay's own standing rules (SANJAY.md). Edits should ship with these on.

---

## 0. The ten findings that change how Edits is built

1. **GSAP licence has a clause aimed at tools like Edits.** The Standard "No Charge" GSAP License (effective 30 Apr 2025, modified 30 May 2025) is free for commercial use and now includes every former Club plugin (SplitText, MorphSVG, DrawSVG, ScrambleText, CustomEase, CustomBounce, CustomWiggle and more). But it defines a Prohibited Use as GSAP inside "tools that allow users to build visual animations without code" that compete with Webflow, and a Competitive Product as software that lets users "create, edit, or manage animations through a visual interface". Prior written consent is required for that. The FAQ says AI-generated GSAP code is not a Prohibited Use. [S] Practical read: Claude writing GSAP for a user is fine; a visual timeline editor in Edits that drives GSAP is the grey zone. Ask GSAP in writing before shipping a GUI timeline on top of GSAP.
2. **Remotion is not free for a company product.** Free only for individuals, non-profits and for-profits with up to 3 employees; otherwise a Company License. A separate "Remotion for Automators" plan for prompt-to-video and video-editor products is $0.01 per render with a $100/month minimum. [S]
3. **HyperFrames (HeyGen) is Apache-2.0**, renders with headless Chrome seeking each frame plus FFmpeg, needs Node 22+, and accepts GSAP, CSS, Lottie, three.js, anime.js, WAAPI or a custom frame adapter. [S] This is the safest engine licence for Edits.
4. **After Effects Easy Ease is cubic-bezier(0.333, 0, 0.667, 1).** Speed 0, influence 33.33% both sides. AE's `ease()` expression matches (0.33, 0, 0.66, 1) within about 1e-6. [S]
5. **Apple's spring maths is public and exact.** `Spring(duration: 0.5, bounce: 0.3)` = mass 1, stiffness 157.9, damping 17.6. So stiffness = (2π / duration)², damping = 4π(1 - bounce) / duration, damping ratio = 1 - bounce. [S][D] Every spring in this doc can be converted with those three lines.
6. **Reading speed has hard numbers.** Netflix English: 20 characters per second for adult programmes, 17 for children, 42 characters per line, 2 lines. Netflix supplementals guide: minimum 5/6 second per event (20 frames at 24 fps), maximum 7 seconds. BBC: 160 to 180 wpm, 0.33 to 0.375 s per word. [S]
7. **Inter publishes its tracking curve:** tracking(em) = -0.0223 + 0.185 × e^(-0.1745 × size). It tends to -0.0223 em (about -2.2%) at display sizes. [S]
8. **pmndrs postprocessing defaults are a good "premium" baseline:** chromatic aberration offset (0.001, 0.0005) UV (about 1.9 px horizontal at 1920 wide), vignette offset 0.5 darkness 0.5, bloom luminanceThreshold 1.0 (only HDR values above 1 bloom). [S][D]
9. **Grain has published starting values** (Vindral Composer): 35mm standard = amount 25%, size 25, softness 30%, luminance 80%, chroma 20%, overlay blend, shadow protection 20 to 40%, animated per frame. A pro colorist's rule: grain should be "felt rather than seen". [S]
10. **Rive exports went paid on 20 Oct 2025** (editor free, runtimes MIT, Cadet plan $9/month annual for exports). [S] Lottie-web stays MIT but cannot play video, audio or image sequences. [S]

---

## A. Motion principles as numbers

### A1. Frame maths

| fps | 1 frame | 2 frames | 3 frames | 6 frames | 12 frames | 24 frames |
|---|---|---|---|---|---|---|
| 24 | 41.7 ms | 83 ms | 125 ms | 250 ms | 500 ms | 1000 ms |
| 25 | 40 ms | 80 ms | 120 ms | 240 ms | 480 ms | 960 ms |
| 30 | 33.3 ms | 67 ms | 100 ms | 200 ms | 400 ms | 800 ms |
| 60 | 16.7 ms | 33 ms | 50 ms | 100 ms | 200 ms | 400 ms |

[D] Rule for Edits: author timing in seconds, store it in frames at the render fps, and snap every key to a whole frame before render. HyperFrames and Remotion both seek by frame, so a key at 0.51 s on 24 fps lands on frame 12.24 and smears.

### A2. After Effects keyframe influence to cubic-bezier

- Easy Ease (F9): speed 0, influence 33.33% in and out. [S] Equivalent: `cubic-bezier(0.333, 0, 0.667, 1)`. AE's `ease()` expression behaves as (0.33, 0, 0.66, 1), difference about 1e-6 on a 0 to 1000 range. [S]
- Mapping with speed 0 on both keys [D]: outgoing influence a% on key 1 gives P1 = (a/100, 0); incoming influence b% on key 2 gives P2 = (1 - b/100, 1).

| AE graph | cubic-bezier | GSAP | Feel |
|---|---|---|---|
| 33.33 / 33.33 (Easy Ease) | (0.333, 0, 0.667, 1) | CustomEase "0.333,0,0.667,1" | AE default, close to sine |
| 50 / 50 | (0.5, 0, 0.5, 1) | close to power2.inOut | firmer |
| 75 / 75 | (0.75, 0, 0.25, 1) | close to power4.inOut | "designer" in-out |
| out 20 / in 90 | (0.2, 0, 0.1, 1) | CustomEase | fast start, long settle (Material emphasized family) |
| out 0 / in 100 (linear then hard ease) | (0, 0, 0, 1) | expo.out-like | snap and settle |

- **Flow** (AE plugin by Zack Lovatt and renderTom): ships 25 presets built on Robert Penner's easing functions; curve values are in the same (x1, y1, x2, y2) format as CSS cubic-bezier; curves apply as keys or expressions; community libraries exist, including one carrying Google Material presets. [S] So any Flow curve copies straight into CSS or `CustomEase.create("name", "x1,y1,x2,y2")`.
- **Motion Design School**: I found no published numeric easing spec from them. Treat their graph-editor lessons as the influence mapping above. (Not invented, simply not found.)

### A3. Penner eases, GSAP names and CSS equivalents

GSAP default ease for tweens is `power1.out`. [S] GSAP power1 = Quad, power2 = Cubic, power3 = Quart, power4 = Quint. CSS cubic-bezier values below are the easings.net approximations (a single cubic cannot reproduce quart, quint or expo exactly; use GSAP or CSS `linear()` when exactness matters). [S]

| GSAP | Penner | in | out | inOut |
|---|---|---|---|---|
| sine | Sine | (0.12, 0, 0.39, 0) | (0.61, 1, 0.88, 1) | (0.37, 0, 0.63, 1) |
| power1 | Quad | (0.11, 0, 0.5, 0) | (0.5, 1, 0.89, 1) | (0.45, 0, 0.55, 1) |
| power2 | Cubic | (0.32, 0, 0.67, 0) | (0.33, 1, 0.68, 1) | (0.65, 0, 0.35, 1) |
| power3 | Quart | (0.5, 0, 0.75, 0) | (0.25, 1, 0.5, 1) | (0.76, 0, 0.24, 1) |
| power4 | Quint | (0.64, 0, 0.78, 0) | (0.22, 1, 0.36, 1) | (0.83, 0, 0.17, 1) |
| expo | Expo | (0.7, 0, 0.84, 0) | (0.16, 1, 0.3, 1) | (0.87, 0, 0.13, 1) |
| circ | Circ | (0.55, 0, 1, 0.45) | (0, 0.55, 0.45, 1) | (0.85, 0, 0.15, 1) |
| back | Back | (0.36, 0, 0.66, -0.56) | (0.34, 1.56, 0.64, 1) | (0.68, -0.6, 0.32, 1.6) |
| elastic, bounce | Elastic, Bounce | no cubic equivalent | use GSAP or `linear()` | |

Other GSAP eases worth knowing [S]: `steps(n)` (stop-motion, split-flap ticks), `RoughEase` (defaults: points 20, strength 1, randomize true, taper "none", clamp false; good for flicker that is not random noise), `SlowMo` (fast, hold, fast: the "slow motion middle" for type that drifts through frame), `ExpoScaleEase` (correct-feeling zooms across big scale ranges), `CustomEase` (paste any bezier or SVG path), `CustomBounce` (strength 0.7, squash 0, endAtStart false by default), `CustomWiggle` (wiggles 10, type "easeOut" by default; types easeOut, easeInOut, anticipate, uniform, random). All are in the free `gsap` npm package since 3.13. [S]

CSS `linear()` easing (Chrome/Edge 113, Firefox 112, Safari 17.2; Baseline Dec 2023) can encode springs and bounces as point lists. Jake Archibald and Adam Argyle's Linear Easing Generator converts a JS easing or spring into an optimised `linear()` string, with Spring, Bounce, Simple elastic and Material emphasized presets. [S]

### A4. Material 3 motion tokens (from material-components-android)

Easing [S]:

| Token | Value |
|---|---|
| standard | cubic-bezier(0.2, 0, 0, 1) |
| standard decelerate | cubic-bezier(0, 0, 0, 1) |
| standard accelerate | cubic-bezier(0.3, 0, 1, 1) |
| emphasized | path M 0,0 C 0.05,0 0.133333,0.06 0.166666,0.4 C 0.208333,0.82 0.25,1 1,1 (two-segment curve, not a single cubic) |
| emphasized decelerate | cubic-bezier(0.05, 0.7, 0.1, 1) |
| emphasized accelerate | cubic-bezier(0.3, 0, 0.8, 0.15) |
| linear | cubic-bezier(0, 0, 1, 1) |

Durations [S]: short1 to 4 = 50, 100, 150, 200 ms. medium1 to 4 = 250, 300, 350, 400 ms. long1 to 4 = 450, 500, 550, 600 ms. extra-long1 to 4 = 700, 800, 900, 1000 ms.

Springs (damping ratio, stiffness) [S], with perceptual period 2π/√k at mass 1 [D]:

| Token | ζ | k | Period [D] |
|---|---|---|---|
| fast spatial | 0.9 | 1400 | 0.168 s |
| default spatial | 0.9 | 700 | 0.237 s |
| slow spatial | 0.9 | 300 | 0.363 s |
| fast effects | 1.0 | 3800 | 0.102 s |
| default effects | 1.0 | 1600 | 0.157 s |
| slow effects | 1.0 | 800 | 0.222 s |

Note the split: spatial (position, size) gets a tiny overshoot (ζ 0.9 = 0.15% overshoot [D]); effects (colour, opacity) never overshoot (ζ 1). Copy that split into Edits. Material 3 Expressive adds bouncier spatial springs; a third-party Flutter port lists expressive default spatial stiffness 380, but I could not confirm the official numbers, so do not ship them as "M3 Expressive" until checked.

### A5. Apple springs (SwiftUI and Core Animation) [S]

| API | Defaults |
|---|---|
| `.spring(duration:bounce:blendDuration:)` | duration 0.5, bounce 0.0, blend 0 |
| `.smooth(duration:extraBounce:)` | base bounce 0, duration 0.5 |
| `.snappy(duration:extraBounce:)` | base bounce 0.15, duration 0.5 |
| `.bouncy(duration:extraBounce:)` | base bounce 0.3, duration 0.5 |
| `.spring(response:dampingFraction:blendDuration:)` | response 0.5, dampingFraction 0.825, blend 0 |
| `.interactiveSpring(response:dampingFraction:blendDuration:)` | response 0.15, dampingFraction 0.86, blend 0.25 |
| `CASpringAnimation` | stiffness 100, damping 10 (mass 1) |
| `Spring(duration: 0.5, bounce: 0.3)` | mass 1, stiffness 157.9, damping 17.6 |
| `Spring(mass: 1, stiffness: 100, damping: 10)` | duration 0.63, bounce 0.5 |

Bounce runs -1 (overdamped) to 1 (undamped); 0 is critically damped. "Duration" is perceptual: about the settling time, or the oscillation period for very bouncy springs. [S]

Conversion [D] (matches Apple's own examples above):
```
stiffness = (2π / duration)²          // mass = 1
damping   = 4π × (1 - bounce) / duration
ζ (damping ratio) = 1 - bounce
peak overshoot = exp(-ζπ / √(1 - ζ²))   for ζ < 1
```

Overshoot by spring [D]:

| Spring | ζ | Peak overshoot |
|---|---|---|
| `.smooth` / bounce 0 | 1.0 | 0% |
| M3 spatial | 0.9 | 0.15% |
| `.interactiveSpring` | 0.86 | 0.5% |
| `.snappy` (0.15) | 0.85 | 0.6% |
| `.spring(response:)` default | 0.825 | 1.0% |
| `.bouncy` (0.3) | 0.7 | 4.6% |
| bounce 0.5 = CASpringAnimation default = Remotion default | 0.5 | 16.3% |

Remotion's `spring()` defaults are mass 1, damping 10, stiffness 100, overshootClamping false [S], which is ζ 0.5 and a 16% overshoot [D]. That is cartoon-bouncy. Edits should override it (for example damping 20 to 26 at stiffness 100 for ζ 1.0 to 1.3, or derive from duration/bounce).

Motion (motion.dev) spring: duration-based by default, bounce 0.25 (range -1 to 1), `visualDuration` sets when it looks finished, restSpeed 0.1, restDelta 0.01; tween default duration 0.3 s. [S]

Apple's WWDC 2018 "Designing Fluid Interfaces" guidance, as summarised secondhand: default to damping 1.0 (no bounce) and only drop to about 0.8 when the motion carries gesture momentum (a flick or throw). [S, secondhand] For non-interactive film: overshoot reads as "physical object", so use it only on things that have mass in the story.

Springs in GSAP: GSAP has no spring ease. Sample a spring (Apple formula above or Motion's `spring()` generator) into 30 to 60 points and feed `CustomEase.create("spring", pathString)`, or emit a CSS `linear()` string for CSS-only scenes. [P]

### A6. Overshoot, anticipation, follow-through, overlap, secondary motion

| Principle | Numbers | Code |
|---|---|---|
| Overshoot | `back.out(1.7)` overshoots 10%. Penner's constant 1.70158 is the value that yields 10%. [S/D] Apple `.bouncy` 4.6%, `.snappy` 0.6%. [D] | `ease: "back.out(1.7)"`; lower to 1.2 for about 5% [P] |
| Anticipation | [P] dip 5 to 10% of the travel distance opposite to the move, over 4 to 8 frames (170 to 330 ms at 24 fps), then the main move | `tl.to(el,{x:-12,duration:.2,ease:"power2.out"}).to(el,{x:240,duration:.5,ease:"expo.out"})`, or `CustomWiggle` type "anticipate" |
| Follow-through | [P] trailing parts settle 2 to 6 frames after the lead; appendages 1 to 3 small oscillations | child uses the parent's value from the past: `valueAtTime(time - lag)` in AE, a delayed `gsap.quickTo` or a second tween offset in code |
| Overlapping action | [P] offset sibling layers 1 to 3 frames (42 to 125 ms at 24 fps); characters 1 to 2 frames, words 3 to 4, lines 5 to 6 | GSAP `stagger: 0.04` (chars) / `0.1 to 0.15` (words, lines), see B5 |
| Secondary motion | [P] 10 to 25% of the primary amplitude: tilt 2 to 6 deg as a card slides, shadow scale lags | separate tween on a child element so it can lag |
| Squash and stretch | [P] keep volume: scaleX × scaleY ≈ 1. 5 to 15% for UI objects; more is cartoon | `CustomBounce` with `squash` and `squashID` drives a scaleY ease from the same bounce [S] |

AE's Quick Offset (AE 25.4+) staggers selected layers or keys by dragging with Cmd+Option, with a per-layer gap readout; Sequence Layers is the older route. [S]

### A7. Motion blur and the 180 degree shutter

- Exposure per frame = (shutter angle / 360) / fps. 180 degrees at 24 fps = 1/48 s (20.8 ms); at 30 fps = 1/60 s; at 60 fps = 1/120 s. [D]
- Blur length (px) = object speed (px/s) × exposure. A title crossing 1920 px in 1 s at 24 fps / 180 degrees smears 40 px. [D]
- AE comp motion blur: shutter angle 180, samples per frame 16, adaptive sample limit 128 (defaults reported for AE CS3). Shutter phase = minus half the angle (so -90 for 180) centres the blur on the frame; older AE defaulted phase to 0 so the blur lagged the action. [S]
- Faking it in code:
  - **Sub-frame accumulation** (the honest way): render N time-offset copies and average. Remotion `<CameraMotionBlur>`: shutterAngle 180 default, samples 10 default, docs recommend 5 to 10 because averaging is "destructive to colors"; children must be absolutely positioned; uses `mix-blend-mode`, which Remotion's client-side renderer does not support. Remotion `<Trail>` (layers, lagInFrames, trailOpacity) is a stylised echo, not physical blur. [S]
  - **Directional blur on the moving axis only**: SVG `<feGaussianBlur stdDeviation="X 0">` where X ≈ blurLength / 3 for a Gaussian approximating a box smear [P]; drive X from velocity each frame. Never a uniform CSS `filter: blur()` on a horizontal move (it blurs both axes and reads as defocus). [P]
  - **Shader multi-tap**: sample the texture 8 to 16 times along the per-pixel velocity vector, length = velocity × angle/360. [P]
  - three.js: render the scene at k sub-frame times into an accumulation target and average. Costly; reserve for hero shots. [P]
- [P] When to use: anything moving faster than about 1 screen width per second. Off for type at rest, off for UI micro-motion.

### A8. "Nothing ever fully stops"

[P] Defaults (practice, not citation):
- Holds drift: scale 1.000 to 1.02 over a 3 s hold (about 0.7% per second), or a 0.5 to 2 px/s translate. Linear or `sine.inOut`, never an ease that stops.
- Camera in 3D: slow dolly 1 to 3% of subject distance per second plus handheld noise (see E6).
- Background textures: grain re-seeded every frame at 24 fps even when rendering at 30 or 60 (see C3).
- Exit any hold already moving: the exit tween starts from the drift velocity (GSAP: overlap the exit with the drift by 0.1 to 0.2 s using the position parameter `"-=0.15"`).

### A9. After Effects expressions people rely on, and their code equivalents

`wiggle(freq, amp, octaves = 1, amp_mult = 0.5, t = time)` [knowledge of the Adobe expression reference; the docs page did not load during research, verify before quoting]. Code equivalent: fractal noise, not `Math.random`.
```js
// seeded 1D value noise wiggle, deterministic for frame-seek renderers
import { createNoise2D } from "simplex-noise";          // MIT
const n = createNoise2D(seededRandom(layerIndex));
const wiggle = (t, freq, amp, oct = 1, mult = 0.5) => {
  let v = 0, a = amp, f = freq;
  for (let i = 0; i < oct; i++) { v += n(t * f, i * 17.3) * a; a *= mult; f *= 2; }
  return v;
};
// per frame: el.style.transform = `translate(${wiggle(t,2,8)}px, ${wiggle(t+99,2,8)}px)`
```
Rule: seed per layer (AE wiggle randomises per layer), and compute from `t`, never from accumulated state, so a seek to frame 400 gives the same pixel as playing to it. [P]

`loopOut(type = "cycle", numKeyframes = 0)` with types cycle, pingpong, offset, continue [knowledge, same caveat]. Code: GSAP `repeat: -1` (cycle), `yoyo: true` (pingpong), `repeatRefresh` or a modifier that adds the delta per loop (offset), and for continue extrapolate the last velocity: `v = (p[n]-p[n-1])/(t[n]-t[n-1]); p = p[n] + v*(t - t[n])`.

`valueAtTime(time - delay)` and the index trick `thisComp.layer(index-1).transform.position.valueAtTime(time - d)` [S]. Code: one master timeline, children read the master's value at `t - i*d`, or simply GSAP `stagger` with the same ease (identical result for identical motions).

Inertial bounce (circulated Dan Ebberts version; values amp .05, freq 4.0, decay 2.0 appear in forum copies; Ebberts warns `Math.exp(decay*t)` overflows at large t, so limit the window) [S]:
```js
// AE
amp = .05; freq = 4.0; decay = 2.0;
n = 0;
if (numKeys > 0){ n = nearestKey(time).index; if (key(n).time > time) n--; }
t = (n == 0) ? 0 : time - key(n).time;
if (n > 0 && t < 1){
  v = velocityAtTime(key(n).time - thisComp.frameDuration/10);
  value + v*amp*Math.sin(freq*t*2*Math.PI)/Math.exp(decay*t);
} else value;

// JS port: after any tween ends with velocity v (units/s)
const settle = (base, v, t, amp=.05, freq=4, decay=2) =>
  t < 0 || t > 1.5 ? base : base + v*amp*Math.sin(freq*t*2*Math.PI)/Math.exp(decay*t);
```
motionscript.com's simpler decaying sine: `amp*Math.sin(t*freq*Math.PI*2)/Math.exp(t*decay)` with amp 80, freq 1, decay 1; and a physical bounce-back expression with elasticity e = .7, gravity g = 5000, nMax = 9 bounces. [S] Port both as pure functions of time.

### A10. Duration tables

UI micro motion [S]:

| Source | Rule |
|---|---|
| NN/g | 100 to 500 ms overall; most 100 to 400; about 100 ms feels instant (toggles, checkboxes); 200 to 300 ms for a modal; 400 ms is "very slow"; 500 ms starts to drag; entrance slightly longer than exit (300 ms in, 200 to 250 out); the more often seen, the shorter |
| Material (M1/M2, archived) | mobile about 300 ms; enter 225 ms, exit 195 ms; full-screen up to 375 ms; tablet about 30% longer (300 becomes 390); desktop 150 to 200 ms |
| Material 3 tokens | 50 to 1000 ms in 50/100 ms steps (A4) |

Film motion (no published standard found; [P] Edits defaults at 24 fps):

| Beat | Duration | Frames @24 | Ease |
|---|---|---|---|
| Line of type rises through mask | 0.6 to 0.9 s | 14 to 22 | expo.out / (0.16, 1, 0.3, 1) |
| Word swap in place | 0.35 to 0.5 s | 8 to 12 | power3.inOut |
| Object entrance with mass | 0.7 to 1.2 s | 17 to 29 | spring ζ 0.7 to 0.85 |
| Scene transition (wipe, push, morph) | 0.5 to 0.9 s | 12 to 22 | power4.inOut / M3 emphasized |
| Exit | 60 to 75% of its entrance | | accelerate curve (power2.in or M3 emphasized accelerate) |
| Logo resolve | 1.0 to 1.6 s plus 1.5 s hold | 24 to 38 | expo.out |
| Camera move in 3D | 2 to 6 s | 48 to 144 | sine.inOut or linear with eased ends |
| Turntable revolution (hero) | 8 to 20 s | | linear |

### A11. Hold times for reading

Sourced anchors [S]: Netflix English adult 20 cps (children 17), 42 chars per line, 2 lines max; supplementals: min 5/6 s (20 frames @24), max 7 s per event. BBC 160 to 180 wpm = 0.33 to 0.375 s per word, about 0.3 s per word minimum. "Read it twice" rule (SSW): hold long enough to read twice at a slow 200 wpm = 0.6 s per word [D]. Six-second rule: two full subtitle lines in 6 s, about 145 wpm. Silent adult reading is often quoted at 238 to 260 wpm (weaker source).

Derived holds [D] (time fully legible, after the entrance finishes):

| Words | BBC fast (0.33 s/word, 5/6 s floor) | Read twice (0.6 s/word) | Edits default [P] |
|---|---|---|---|
| 1 | 0.83 s | 0.6 s | 1.2 s |
| 3 | 1.0 s | 1.8 s | 1.7 s |
| 5 | 1.65 s | 3.0 s | 2.5 s |
| 8 | 2.64 s | 4.8 s | 3.7 s |
| 12 | 3.96 s | 7.2 s | 5.3 s |
| 20 | 6.6 s | 12.0 s | split it; over 7 s violates the Netflix ceiling |

[P] Edits formula: `hold = max(1.2, 0.5 + 0.4 × words)` seconds for text the viewer reads silently; when the voice speaks the same words, `hold = spoken duration + 0.3 s`, and reveal on the word. [H] Voice carries the words: never print narration as on-screen text.

---

## B. Typography for motion

### B1. Typefaces that hold up in motion (licences checked)

OFL = SIL Open Font License 1.1 (free commercial use, embedding, video, apps; cannot sell the font alone). Axes from Google Fonts METADATA.pb. [S]

| Role | Typeface | Foundry / designer | Licence, where | Axes | Motion style it suits |
|---|---|---|---|---|---|
| Neo-grotesk | **Inter** | Rasmus Andersson | OFL, Google Fonts, rsms.me | opsz 14 to 32, wght 100 to 900 | product films, UI-in-film, captions; Inter Display lives on the opsz axis in v4 |
| Neo-grotesk | **Inter Tight** | Rasmus Andersson | OFL, Google Fonts | wght | big headlines, tight-set kinetic stacks |
| Neo-grotesk | **Geist** / **Geist Mono** | Vercel with Basement Studio (Andrés Briganti, Mateo Zaragoza, Guillermo Rauch, Evil Rabbit and others) | OFL, Google Fonts, github.com/vercel/geist-font | wght 100 to 900 | tech launches, clean Swiss-tech titles |
| Grotesk | **Mona Sans** | GitHub, Degarism Studio, Sebastian Carewe, Tobias Bjerrome Ahlin | OFL, Google Fonts | wdth 75 to 125, wght 200 to 900 | width animation without changing family; GT America feel |
| Grotesk | **Instrument Sans** | Rodrigo Fuenzalida, Jordan Egstad | OFL, Google Fonts | wdth 75 to 100, wght 400 to 700 | editorial sans next to Instrument Serif |
| Grotesk | **Space Grotesk** | Florian Karsten | OFL, Google Fonts | wght 300 to 700 | quirky tech, data overlays |
| Grotesk | **Bricolage Grotesque** | Mathieu Triay | OFL, Google Fonts | opsz 12 to 96, wdth 75 to 100, wght 200 to 800 | expressive display that tightens with opsz; Gen Z editorial |
| Grotesk | **Satoshi**, **General Sans**, **Switzer** | Indian Type Foundry (Fontshare) | ITF Free Font License: free for print, web, apps, broadcasting; no redistribution of files; download from fontshare.com | variable versions available | clean modern titles; Satoshi is the Söhne-adjacent free pick |
| Condensed display | **Anton** | Vernon Adams | OFL, Google Fonts | static 400 | poster punches, full-frame words |
| Condensed display | **Bebas Neue** | Ryoichi Tsunekawa, Dharma Type | OFL, Google Fonts | static | caps-only stacks, sports energy (overused, style it hard) |
| Condensed display | **Big Shoulders** | Patric King | OFL, Google Fonts | opsz 10 to 72, wght 100 to 900 | Druk-like tall caps; opsz keeps it crisp large |
| Condensed and wide | **Archivo** | Omnibus-Type | OFL, Google Fonts | wdth 62 to 125, wght 100 to 900 | one family from condensed to expanded: animate wdth 62 to 125 |
| Wide / extended | **Unbounded** | NaN | OFL, Google Fonts | wght 200 to 900 | wide rounded display, Y2K and acid looks |
| Wide / extended | **Anybody** | Tyler Finck | OFL, Google Fonts | wdth 50 to 150, wght 100 to 900 | the widest free width range: stretch and squash type |
| Wide / extended | **Clash Display**, **Panchang** | Indian Type Foundry (Fontshare) | ITF FFL | wght | fashion, music, bold hero words |
| Wide / expressive | **Syne** | Bonjour Monde, Lucas Descroix, George Triantafyllakos | OFL, Google Fonts | wght 400 to 800 | art-world, gallery titles |
| Serif display | **Fraunces** | Undercase Type, Phaedra Charles, Flavia Zimbardi | OFL, Google Fonts | opsz 9 to 144, wght 100 to 900, SOFT 0 to 100, WONK 0 to 1 | warm editorial; animate SOFT for a melt, WONK for personality |
| Serif display | **Playfair** (v2) | Claus Eggers Sørensen | OFL, Google Fonts | opsz 5 to 1200, wdth 87.5 to 112.5, wght 300 to 900 | high-contrast fashion; huge opsz range for giant type |
| Serif display | **Bodoni Moda** | Owen Earl | OFL, Google Fonts | opsz 6 to 96, wght 400 to 900 | luxury, perfume, Didone hairlines (keep big, hairlines alias when small) |
| Serif display | **Instrument Serif** | Rodrigo Fuenzalida, Jordan Egstad | OFL, Google Fonts | static Regular and Italic | condensed editorial serif; Canela/Editorial New mood |
| Serif text and display | **Newsreader** | Production Type | OFL, Google Fonts | opsz 6 to 72, wght 200 to 800 | documentary, essay films |
| Mono | **JetBrains Mono** | JetBrains, Philipp Nurullin, Konstantin Bulenkov | OFL, Google Fonts | wght 100 to 800 | code on screen, typewriter |
| Mono | **IBM Plex Mono**, **Space Mono** | IBM (Mike Abbink, Bold Monday); Colophon | OFL, Google Fonts | static weights | data readouts, timestamps, split-flap |
| Script | **Ballet** | Omnibus-Type, Maximiliano Sproviero | OFL, Google Fonts | opsz 16 to 72 | formal script with optical sizes; signatures, wedding, luxury |
| Script (paid) | **Sloop Script Pro** | Font Bureau (Richard Lipton) | commercial licence | static | Sanjay's portfolio start; licence check per project |
| Variable showcase | **Roboto Flex** | Font Bureau, David Berlow and team | OFL, Google Fonts | opsz 8 to 144, wght 100 to 1000, wdth 25 to 151, slnt -10 to 0, GRAD -200 to 150, XOPQ, XTRA, YOPQ, YTAS, YTDE, YTFI, YTLC, YTUC | the most animatable free font: 13 axes |
| Variable showcase | **Recursive** | Arrow Type, Stephen Nixon | OFL, Google Fonts | wght 300 to 1000, slnt -15 to 0, MONO 0 to 1, CASL 0 to 1, CRSV 0 to 1 | morph from code mono to casual sans on screen |

### B2. Famous fonts that are NOT free, and stand-ins

| Paid face | Foundry and licence | Free stand-in (feel, not a metric clone) |
|---|---|---|
| Neue Haas Grotesk | Christian Schwartz; distributed by Font Bureau and Linotype (Monotype); commercial | Inter at opsz 32, Geist |
| Helvetica Now | Monotype; commercial | Inter, Inter Tight |
| GT America, GT Walsheim, GT Sectra | Grilli Type; commercial | Mona Sans (America), Bricolage (Walsheim mood), Fraunces high opsz (Sectra) |
| Söhne, Founders Grotesk, Tiempos | Klim Type Foundry; commercial | Satoshi, Geist, Inter Tight; Newsreader for Tiempos |
| Graphik, Druk, Canela | Commercial Type; commercial | Instrument Sans; Anton or Big Shoulders 900 or Archivo wdth 62 Black (Druk); Instrument Serif or Fraunces SOFT 100 (Canela) |
| Ogg | Sharp Type; commercial | Fraunces WONK 1, Playfair high opsz |
| PP Neue Montreal, PP Editorial New, Neue Machina, PP Monument Extended | Pangram Pangram; free for personal use only, commercial use needs a paid licence (desktop, web, app sold separately) | Geist (Montreal), Instrument Serif (Editorial New), Unbounded (Machina), Anybody wdth 150 (Monument Extended) |
| Suisse Int'l | Swiss Typefaces; commercial | Inter |
| ABC Diatype | Dinamo; commercial | Geist, Space Grotesk |
| Aeonik | CoType Foundry; commercial | Satoshi, General Sans |
| SF Pro | Apple; licence limits it to mock-ups of software for Apple platforms; not for websites or embedding | Inter; `system-ui` in a browser on Apple devices |
| Telgra (SCD brand) | web-embedding licence unverified [H] | flag before any public launch |

### B3. Variable font axis animation

- Registered axes: `wght` (weight), `wdth` (width %), `slnt` (slant, negative degrees), `ital` (0 or 1), `opsz` (optical size). Custom axes are uppercase (GRAD, SOFT, WONK, CASL, MONO, CRSV). [S, OpenType registry convention]
- CSS mapping: `font-weight` drives wght; `font-stretch: 75%` drives wdth; `font-style: oblique 10deg` drives slnt; `font-optical-sizing: auto` sets opsz from the font size; anything else via `font-variation-settings: "SOFT" 100, "WONK" 1`. `font-variation-settings` interpolates in CSS transitions and in GSAP (numeric string tween). [S, CSS Fonts 4]
- Animate custom axes cleanly: register a CSS custom property with `@property --soft { syntax: "<number>"; inherits: true; initial-value: 0 }`, set `font-variation-settings: "SOFT" var(--soft)`, tween `--soft` with GSAP. [P]
- Roboto Flex `GRAD` changes stroke weight without changing advance width, so text does not reflow when it "gets heavier". Use GRAD (or a fixed-width box) for hover-like weight pulses; use wght only when reflow is wanted. [S, axis definition]
- Per-character axis waves: split to chars, give each char its own `--w`, drive with `gsap.to(chars, {"--w": 900, stagger: {each: 0.03, yoyo: true, repeat: 1}})`. Width changes ripple layout every frame, so wrap each line in a fixed-width container or animate wdth only on centred single words. [P]
- Performance: axis animation forces text re-layout and re-raster each frame. Fine in a frame-seek renderer (HyperFrames, Remotion), can drop frames live at 60 fps with hundreds of chars. [P]

### B4. Tracking and leading for large type

Inter's published dynamic metric [S]: `tracking(em) = -0.0223 + 0.185 × e^(-0.1745 × z)`, z = size in px. Values [D]:

| Size | 12 | 14 | 16 | 20 | 24 | 32 | 48+ |
|---|---|---|---|---|---|---|---|
| Tracking (em) | +0.0005 | -0.0062 | -0.0110 | -0.0167 | -0.0195 | -0.0216 | -0.0223 |

- Apple SF: tracking varies smoothly by size, with no hard switch at 20 pt; it interpolates between 17 and 28 pt (WWDC20 note). [S]
- [H] Sanjay's film rule: -0.035 em at 30 px and up, -0.02 em below. Do not shrink sizes to compensate.
- [P] Leading: display lines 0.88 to 1.0 for caps or tight grotesks, 1.05 to 1.15 for serifs with descenders; body captions 1.35 to 1.5. Wide fonts need slightly looser tracking than condensed ones at the same size.
- [P] All caps: add +0.02 to +0.06 em back (caps are designed for mixed case spacing). Mono: never negative tracking.

### B5. Kinetic type recipes with numbers

Line-by-line mask reveal (GSAP SplitText 3.13+) [S]:
```js
SplitText.create(".title", {
  type: "lines", mask: "lines", autoSplit: true,
  onSplit: (self) => gsap.from(self.lines, {
    yPercent: 100, duration: 0.6, stagger: 0.1, ease: "expo.out"
  })
});
```
The GSAP docs demo adds `opacity: 0`; [H] drop it: rise from the mask only, no opacity fades. `autoSplit: true` re-splits after fonts load or on width change; in a frame-seek renderer also `await document.fonts.ready` before building the timeline. `aria: "auto"` (default) puts the full string on an `aria-label`. `mask` accepts one of "lines", "words", "chars". [S]

Stagger numbers from GSAP's own demos [S]: chars `x: 150, duration: 0.7, ease: "power4", stagger: 0.04`; words `y: -100, rotation: "random(-80, 80)", duration: 0.7, ease: "back", stagger: 0.15`; lines `rotationX: -100, duration: 0.8, ease: "power3", stagger: 0.25`; responsive lines `yPercent: 20, duration: 3, stagger: 0.05`.

[P] Stagger budget: keep total stagger spread under about 0.6 s for a headline so the last char lands while the first is still fresh; for 30 chars that means about 0.02 s each.

Scramble (ScrambleTextPlugin) defaults [S]: chars "upperCase" (also "lowerCase", "upperAndLowerCase" or any custom string such as "01"), speed 1, revealDelay 0, tweenLength true, delimiter "" (set " " for word by word), rightToLeft false. [P] For premium scramble use a narrow charset matching the target (digits for numbers), revealDelay 0.2 to 0.4 s, duration about 0.04 s per char.

Typewriter (TextPlugin: delimiter, speed, type "diff", newClass, oldClass, padSpace, preserveSpaces, rtl) [S]. Speeds [D]: real typing at 40 wpm = 3.3 chars/s = 300 ms per char; 70 wpm = 171 ms per char; reading pace (Netflix 20 cps) = 50 ms per char. [P] Use 50 to 80 ms per char for narration-synced type, with a caret that blinks at 530 ms on, 530 ms off while idle and stays solid while typing (classic terminal behaviour).

Split-flap [S, component docs]: per-flap flip 300 ms (`ease-in-out`), 60 ms between characters (Svelte split-flap defaults); other components use 110 to 200 ms steps; Framer's component ranges 20 to 300 ms per flap with 0 to 300 ms random column stagger. Build: top and bottom half flaps, `rotateX`, `transform-style: preserve-3d`, `backface-visibility: hidden`, roll through the charset to the target; long runs accelerate then decelerate. [P] Add a 1 to 2 px dark seam and a 6 to 10% darker bottom half for the hinge shadow; a tick SFX per flap.

Kinetic layouts [P]:
| Layout | Rule |
|---|---|
| One word per beat | word fills 60 to 80% of frame width, cut on the beat, no tween longer than 4 frames |
| Stacked justified | each line set to the same width by changing size per line (or wdth axis); leading 0.9 |
| Grid-locked | type snaps to a 12-column grid; motion only along grid lines; Swiss look |
| Scale swap | the next word starts inside a letter counter of the previous and scales up with ExpoScaleEase |
| Path text | SVG `<textPath>` with `startOffset` tweened; keep curvature radius > 3× cap height |
| Extruded 3D | troika or TextGeometry with 2 to 4% bevel; one light, real shadow (E5) |
| Line mask cascade | lines rise through masks 0.1 s apart; exits drop the other way at 70% of the entrance duration |

---

## C. Colour

### C1. Palettes and looks for motion

Provenance column: **ref** = a named real colour or published token; **prop** = proposed starting values for Edits (tune per project).

| Look | Hex | Use | Provenance |
|---|---|---|---|
| Swiss / International | #FFFFFF, #000000, #DA291C (Swiss flag red, Pantone 485, RAL 3028 conversion) | grid-locked type, one red rule or block | ref (third-party conversion) |
| Apple product dark | #000000 page, #1D1D1F near-black, #F5F5F7 light grey, #86868B secondary text, #2997FF link on dark, #0071E3 CTA blue | product reveals on black, one blue accent | ref (third-party analysis of apple.com CSS) |
| Editorial cream | #F0EEE9 (Pantone 11-4201 Cloud Dancer, 2026 Colour of the Year), ink #161514, accent #7A2E1F | essays, documentary, quotes | Cloud Dancer ref; ink and accent prop |
| SCD brand | #FF0101 red, #FFFDE2 cream, #0B0B0B black | Sanjay's personal films | [H] |
| Monochrome plus one accent | #0B0B0B, #2A2A2A, #8C8C8C, #EDEDED + International Klein Blue #002FA7 | restraint; the accent marks the one thing spoken | IKB ref (RGB 0, 47, 167); greys prop |
| Gen Z acid | brat green #8ACE00 (RGB 138, 206, 0) with #000000 or #FFFFFF; optional hot pink #FF3EA5 | music, culture, loud social cuts | brat ref; pink prop |
| Y2K chrome | ramp #F4F6F8, #C9CED6, #8A929E, #3B4048, #0E1014; iridescent tints #9EE7FF, #E3B8FF | chrome type, metallic logos | prop |
| Cinematic teal and orange | shadows #0F3B44, mids #2E6E73, skin and highlights #F2A65A, #FFD7A8 | blockbuster grade; skin sits on the orange axis, shadows pushed to its complement | prop |
| Risograph | Fluorescent Pink #FF48B0, Blue #0078BF, Yellow #FFE800, Federal Blue #3D5588, Light Teal #009DA5, Scarlet #F65058, Fluorescent Red #FF4C65; paper #F7F2E7 | 2-colour print look with misregistration and grain | inks ref (print shop, "approximations"; fluorescents cannot display on screen); paper prop |
| Duotone | shadow #1B1B3A + highlight #FFE800; or #002FA7 + #F0EEE9 | portraits and footage mapped to two inks | prop |
| Night neon | ground #07070C, #FF2E88, #00E5FF, #B4FF39 | night city, gaming; neon as thin lines, not centre glows [H] | prop |
| Pastel 3D | ground #F7F5F2, #F6D6E8, #CDE7F0, #E6E1F7, #FFF1C9 | soft clay renders | prop |
| Wes Anderson pastel (Grand Budapest analysis) | #FFBDD8, #F4A8B9, #A4D8FF, #F9D1BC, #8B5FBF | symmetrical, centred, storybook | ref (blog swatches; sources disagree on reds) |
| Brutalist | #FFFFFF, #000000, #0000FF, #FF0000 | system fonts, hard cuts, no easing | prop |
| Noir monochrome | #0A0A0A, #1C1C1C, #5E5E5E, #D9D4C7 | crime, luxury watches; light does the work | prop |
| Portra warm | highlight #F6E7D2, skin #E8B496, lifted shadow #3A3530 | nostalgic lifestyle | prop |

[H] Banned looks for Edits presets: no radial or centre background glow, no inner glows, no thick translucent rings, no accent confetti. Depth comes from flat neutrals, edge vignette, grain and hairlines.

### C2. Colour grading in code

CSS `filter` (order matters, applied left to right): `brightness() contrast() saturate() hue-rotate() sepia() grayscale() invert() blur() drop-shadow() url(#svgFilter)`. `backdrop-filter` grades what is behind an element. [S, CSS Filter Effects]

SVG filters (the real grading tools in a browser):
- `feColorMatrix type="matrix"` (5×4 RGBA matrix: channel mixing, split tone), `type="saturate"`, `type="hueRotate"`, `type="luminanceToAlpha"` (instant luma matte).
- `feComponentTransfer` with `feFuncR/G/B type="table" tableValues="..."` is a per-channel curve (a 1D LUT). `type="gamma"` (amplitude, exponent, offset) is lift/gamma/gain. Duotone = grayscale, then table "0.11 1.0" style two-value tables per channel.
- `feTurbulence type="fractalNoise"` for grain, paper and smoke.

WebGL:
- three.js `LUTPass` (lut: texture3D, intensity default 1) with `LUTCubeLoader` (parses .cube into a 3D data texture, UnsignedByteType default, FloatType optional), `LUT3dlLoader`; example `webgl_postprocessing_3dlut`. [S]
- pmndrs postprocessing LUT effect: lookup texture from .cube or a constructed texture; `tetrahedralInterpolation` off by default (turn it on for smoother gradients). LUTCubeLoader does not load 1D .cube files. [S]
- Tone mapping in three.js: set `renderer.toneMapping` and `toneMappingExposure`; ACESFilmic is the usual start; AgX and Khronos PBR Neutral are also available in current three.js and keep product colours truer than ACES. [S/knowledge]
- 2D LUT strip in a fragment shader (for non-three engines): 64³ cube laid out as a 512×512 or 4096×64 texture; sample two slices and mix by the blue fraction. [P]

Film emulation [S hobbyist comparisons]: Kodak Portra 400 leans warm (orange and yellow undertones), Kodak generally accentuates yellows and reds; Fuji Pro 400H (discontinued) leans cooler with blues and greens standing out and a blue-green tint; reports conflict on which has more contrast; Portra reported finer grain. Recipe [P]:
1. Lift blacks to 0.03 to 0.05 output (film never hits 0).
2. Soft shoulder: roll highlights off from about 0.8 input, so whites top out near 0.95.
3. Split tone: shadows toward teal or green (Fuji) or warm brown (Portra), highlights warm cream.
4. Saturation down 5 to 15% overall, skin hue protected.
5. Halation, then grain, then a light vignette (order below).

Halation [P] (red-orange bleed around highlights from light reflecting off the film base): threshold luma 0.75 to 0.85, blur radius 0.5 to 1.5% of frame width, tint toward red-orange (around #FF4A1C), add (screen or plus) at 0.1 to 0.3, red channel blurred widest. Keep it around edges of bright sources, never a centre glow. [H]

### C3. Grain, vignette, contrast

Grain starting values (Vindral Composer docs) [S]:

| Look | Amount | Size | Softness | Luma | Chroma |
|---|---|---|---|---|---|
| 35mm fine (ISO 50 to 100) | 15% | 15 | 40% | 90% | 10% |
| 35mm standard (ISO 200 to 400) | 25% | 25 | 30% | 80% | 20% |
| 35mm high speed (ISO 800 to 1600) | 40% | 40 | 20% | 75% | 25% |
| 16mm | 50% | 60 | 25% | 70% | 30% |
| Super 8 / vintage | 65% | 80 | 15% | 65% | 35% |
| Digital camera noise | 30% | 10 | 0% | 50% | 50% (chroma sat 150%) |

Defaults there: overlay blend, shadow protection 30% (advice 20 to 40%), highlight protection 0, animated on, chroma well below luma (80/20 start). [S]

Colorist practice (Frame.io): put grain at the timeline level before the look nodes so every clip gets the same grain; start from a preset (35mm 200T example), set size then strength, then drop opacity (example lands about 30%); coarser for 16mm or Super 8; grain should be "felt rather than seen". [S]

In code [P]: pre-render 4 to 8 tiling noise frames (512 px), cycle them at 24 fps regardless of render fps, blend overlay or soft-light at 4 to 10% for "35mm standard" on 1080p, luma-only (grey noise), reduce in shadows. Encode at a high enough bitrate or the codec deletes it (grain is the first thing low-bitrate H.264 smooths away).

Vignette [S]: pmndrs `VignetteEffect` offset 0.5, darkness 0.5. [P] Premium: corners 10 to 25% darker, falloff starting 50 to 60% from centre, shape matched to frame aspect. [H] Edge vignette yes, centre glow never.

Text over video contrast [S, WCAG 2.2 SC 1.4.3 and 1.4.6]: 4.5:1 for normal text, 3:1 for large text (24 px, or 18.67 px bold), AAA 7:1 and 4.5:1. [P] Measure against the brightest pixels behind the text across the whole shot, not one frame. If footage varies, add a scrim (bottom gradient from 0 to 55 to 70% black over the lower third), or a 1 px dark outline plus a soft shadow (0 2px 8px rgba(0,0,0,0.5)). White text on bright skies fails more than any other case.

---

## D. Blending and compositing

### D1. Every blend mode

Formulas from W3C Compositing and Blending Level 1 (Cb = backdrop, Cs = source, 0 to 1 per channel). [S]

| Mode | Formula | Motion-design uses |
|---|---|---|
| normal | Cs | default |
| multiply | Cb × Cs | paper texture, shadows, ink, riso overprint, darkening dust |
| screen | Cb + Cs - Cb×Cs | light leaks, lens flares, smoke on black, sparks, film burns |
| overlay | HardLight(Cb, Cs) with arguments swapped (backdrop decides) | grain on 50% grey, contrast textures |
| darken / lighten | min / max | combine mattes, keep the brightest of two light passes |
| color-dodge | Cb = 0: 0; Cs = 1: 1; else min(1, Cb/(1 - Cs)) | hot glows, sabers, energy cores (use small and sparingly) |
| color-burn | Cb = 1: 1; Cs = 0: 0; else 1 - min(1, (1 - Cb)/Cs) | deep burnt edges, aged paper |
| hard-light | Cs ≤ 0.5: Multiply(Cb, 2Cs); else Screen(Cb, 2Cs - 1) | punchy texture where the layer decides |
| soft-light | Cs ≤ 0.5: Cb - (1 - 2Cs)Cb(1 - Cb); else Cb + (2Cs - 1)(D(Cb) - Cb), D = ((16Cb - 12)Cb + 4)Cb if Cb ≤ 0.25 else √Cb | subtle grain, gentle dodge and burn, colour washes |
| difference | \|Cb - Cs\| | type over image that inverts as it passes, transitions, glitch |
| exclusion | Cb + Cs - 2CbCs | softer difference, pastel inversions |
| hue | SetLum(SetSat(Cs, Sat(Cb)), Lum(Cb)) | recolour footage keeping light |
| saturation | SetLum(SetSat(Cb, Sat(Cs)), Lum(Cb)) | desaturate zones by a matte |
| color | SetLum(Cs, Lum(Cb)) | tint footage, duotone base |
| luminosity | SetLum(Cb, Lum(Cs)) | luma-only grain, relight with a texture |
| add / plus-lighter | min(1, Cs + Cb) (Porter-Duff lighter: co = αsCs + αbCb) | particles, sparks, light, crossfades without the mid dip |
| subtract (WebGL only) | Cb - Cs | eat light, inverse leaks |

Non-separable helpers [S]: Lum(C) = 0.3R + 0.59G + 0.11B; Sat = max - min; ClipColor and SetLum keep results in gamut.

Where to set each:
- **CSS** `mix-blend-mode`: normal, multiply, screen, overlay, darken, lighten, color-dodge, color-burn, hard-light, soft-light, difference, exclusion, hue, saturation, color, luminosity, plus `plus-lighter` (and `plus-darker` in the Level 2 list). It creates a stacking context and blends only with the backdrop in the same stacking context; use `isolation: isolate` on the parent to stop it blending with the page; it is not animatable; `background-blend-mode` blends an element's own background layers. MDN notes `plus-lighter` prevents the brightness dip when two layers crossfade. Baseline since Jan 2020. [S]
- **Canvas 2D** `globalCompositeOperation`: all 16 blend modes above (same names), plus Porter-Duff source-over, source-in, source-out, source-atop, destination-over, destination-in, destination-out, destination-atop, lighter (add), copy, xor. [S]
- **WebGL** fixed-function (premultiplied alpha) [S/knowledge]: normal `blendFunc(ONE, ONE_MINUS_SRC_ALPHA)`; add `(ONE, ONE)`; multiply `(DST_COLOR, ONE_MINUS_SRC_ALPHA)`; screen `(ONE, ONE_MINUS_SRC_COLOR)`; subtract `blendEquation(FUNC_REVERSE_SUBTRACT)`. three.js: `NormalBlending`, `AdditiveBlending`, `SubtractiveBlending`, `MultiplyBlending`, `CustomBlending`. Everything else (overlay, soft light, dodge, burn, hue modes) must be done in a shader that samples both layers.
- **GLSL** (drop-in, from the W3C formulas):
```glsl
vec3 bMultiply(vec3 b, vec3 s){ return b*s; }
vec3 bScreen(vec3 b, vec3 s){ return b + s - b*s; }
vec3 bHardLight(vec3 b, vec3 s){
  return mix(b*2.0*s, bScreen(b, 2.0*s - 1.0), step(0.5, s)); }
vec3 bOverlay(vec3 b, vec3 s){ return bHardLight(s, b); }
vec3 bSoftLight(vec3 b, vec3 s){
  vec3 d = mix(((16.0*b - 12.0)*b + 4.0)*b, sqrt(b), step(0.25, b));
  return mix(b - (1.0 - 2.0*s)*b*(1.0 - b), b + (2.0*s - 1.0)*(d - b), step(0.5, s)); }
vec3 bDodge(vec3 b, vec3 s){ return mix(min(vec3(1.0), b/max(1.0 - s, 1e-5)), vec3(0.0), step(b, vec3(0.0))); }
vec3 bBurn(vec3 b, vec3 s){ return mix(1.0 - min(vec3(1.0), (1.0 - b)/max(s, 1e-5)), vec3(1.0), step(vec3(1.0), b)); }
vec3 bDifference(vec3 b, vec3 s){ return abs(b - s); }
vec3 bExclusion(vec3 b, vec3 s){ return b + s - 2.0*b*s; }
float lum(vec3 c){ return dot(c, vec3(0.3, 0.59, 0.11)); }
```

### D2. Track mattes, masks, feathering

- **Alpha matte**: CSS `mask-image: url(matte.png)` or any gradient; `mask-mode: alpha`. **Luma matte**: `mask-mode: luminance` (Baseline 2023; Chrome/Edge 120, Firefox 53, Safari 15.4); SVG `<mask>` is luminance by default (`mask-type` switches). Canvas: draw matte, then `destination-in` (keep inside) or `destination-out` (inverted matte). GLSL: `col.a *= dot(matte.rgb, vec3(0.2126, 0.7152, 0.0722))` (Rec. 709 luma). [S/knowledge]
- **Feathering**: gradient stops in the mask (`linear-gradient(to bottom, #000 70%, transparent)`), or blur the matte (SVG feGaussianBlur on the mask content, or a blurred matte texture). [P] Feather 1 to 3% of the masked object's size for "soft but intentional"; hard edges on type masks.
- [H] Mask wipes only for lines of text. Objects rise, scale from origin, slide, tip in or morph.
- **Chroma key** (WebGL) [P]: convert to YCbCr, distance d between pixel CbCr and key CbCr; `alpha = smoothstep(similarity, similarity + smoothness, d)` with similarity 0.25 to 0.4 and smoothness 0.05 to 0.1; spill: where g > max(r, b), pull g down to max(r, b) and add a touch of the backdrop colour. Key on video textures in three.js (`VideoTexture`) or a 2D canvas pass.
- **Depth maps and parallax** [P]: offset UVs by `(depth - focusDepth) * strength * cameraOffset`, strength 0.01 to 0.03 of frame width for believable 2.5D; larger values tear at depth edges, so inpaint or blur the depth map edges and limit camera travel. Use depth for fog, DOF and relighting too.
- **Light wrap** [P]: blur the background 2 to 4% of frame width, mask it to a thin band just inside the foreground alpha edge (alpha eroded vs original), screen it onto the foreground at 0.3 to 0.6. Sells keyed or 3D subjects into plates.

### D3. Texture overlays: premium vs cheap

| Texture | Blend | Premium setting [P] | Reads cheap when |
|---|---|---|---|
| Film grain | overlay or soft-light | see C3; luma only; animated at 24 fps | static grain, coloured RGB noise, visible tiling, over 15% on 1080p |
| Dust and scratches | screen (light specks on dark) or multiply (dark on light) | 1 to 3 specks per frame, held 1 to 2 frames, a scratch every few seconds | constant scratches, same overlay loop visibly repeating |
| Paper | multiply | paper scanned around mid-light, opacity 40 to 100%, slightly moving (0.5 px/s) | perfect seamless tile, too dark |
| Halftone | multiply or normal | GLSL grid rotated to print screen angles (classic CMYK: C 15, M 75, Y 0, K 45 degrees), dot radius from √(1 - luma), 6 to 12 px cell at 1080p | dots at 0 degrees for all inks, moiré on motion |
| Scanlines | multiply or overlay | 2 to 3 px period at 1080p, 8 to 15% darkening, slight roll | 1 px lines that alias, 50% darkening |
| CRT | shader | barrel distortion k 0.02 to 0.08, RGB triad mask at 3 px, soft edge vignette, tiny flicker (RoughEase) | fisheye bulge, neon bloom everywhere |
| Chromatic aberration | shader | pmndrs default offset (0.001, 0.0005) UV = about 1.9 px × 0.5 px at 1920×1080 [S/D]; radial (stronger at edges), 0 at centre | 5 px or more uniform RGB split, on body text |
| Light leaks | screen or add | warm, off-centre, from frame edges, 0.5 to 1.5 s, on cuts | centred blooms [H banned], every cut |

---

## E. 2D and 3D techniques in code

### E1. Libraries and licences

| Library | Licence | What it gives Edits | Notes |
|---|---|---|---|
| GSAP 3.13+ (`gsap` npm) | Standard No-Charge GSAP License (free commercial) | timelines, eases, SplitText, MorphSVG, DrawSVG, MotionPath, ScrambleText, Text, CustomEase/Bounce/Wiggle, Physics2D, Inertia, ScrollTrigger, Flip | Prohibited Use: visual no-code animation builders competing with Webflow, unless written consent; AI-written GSAP code is permitted (see finding 1) [S] |
| three.js | MIT | 3D scenes, PBR, instancing, post | standard |
| postprocessing (pmndrs) | zlib | bloom, DOF, LUT, noise, vignette, CA, SMAA | defaults in C3/D3/E8 [S] |
| Lottie (lottie-web) | MIT | AE to JSON via Bodymovin; SVG, canvas, HTML renderers | supports expressions and masks; no image sequences, video or audio; negative layer stretch unsupported [S] |
| Rive | runtimes MIT; editor free, production exports paid since 20 Oct 2025 (Cadet $9/month annual) | state-machine interactive animation | [S] |
| Theatre.js | `@theatre/core` Apache-2.0; `@theatre/studio` AGPL-3.0 | keyframe editor for three.js and DOM | only core ships in the bundle; studio is dev-time [S] |
| Motion Canvas | MIT | code-first generator-based animation with a preview editor | good for explainer diagrams [S] |
| Remotion | custom licence: free up to 3 employees; Company License above; Automators $0.01/render, $100/month min | React video, `spring()`, `interpolate()`, motion-blur package | check before Edits renders for paying users [S] |
| HyperFrames | Apache-2.0 | HTML to MP4, deterministic frame seek, GSAP/CSS/Lottie/three/anime/WAAPI adapters | Node 22+, FFmpeg; built for agents [S] |
| anime.js v4 | MIT | `animate()`, `createTimeline()`, `splitText`, `morphTo`, ES modules | v4 full rewrite (April 2025 per secondary source) [S] |
| Motion (motion.dev) | MIT | springs, WAAPI-backed animate, React | spring defaults in A5 |
| vfx-js | MIT | WebGL shader effects on img/video/DOM (glitch preset, PixelateEffect, BloomEffect) | [S] |
| OGL | Unlicense (public domain) | minimal WebGL, about 29 kB gz total (core 8, math 6, extras 15) | [S] |
| curtains.js | MIT | DOM elements as WebGL textured planes | [S] |
| flubber | MIT (Noah Veltman, 2017) | best-guess interpolation between arbitrary 2D shapes | [S] |
| gl-transitions | MIT (two transitions BSD) | 100+ GLSL transitions, `vec4 transition(vec2 uv)` with `getFromColor`, `getToColor`, `progress`, `ratio` | GLSL ES 1.00 [S] |
| webgl-noise (Ashima Arts, Stefan Gustavson) | MIT | simplex, classic and cellular noise in GLSL | maintained at stegu/webgl-noise [S] |
| LYGIA | Prosperity License (non-commercial) + Patron License for sponsors/contributors | huge shader function library | commercial use needs sponsorship or a per-version licence; mixbox files separately non-commercial [S] |
| Shadertoy code | default licence on shadertoy.com is CC BY-NC-SA 3.0 unless the author states otherwise | reference only | do not paste into commercial builds without the author's licence [knowledge, check per shader] |

### E2. Shape morphing and path drawing

- GSAP MorphSVG options [S]: `shape` (required); `type` "linear" (default) or "rotational" (interpolates rotation and length, avoids mid-tween kinks); `shapeIndex` "auto" (offsets start points; closed paths only; numbers skip auto maths); `map` "size" (default), "position", "complexity" (fastest); `origin` "50% 50%"; `precision` 2 decimals; `smooth` (adds points; `points`, `redraw`, `persist`); `curveMode` (3.14+, interpolates handle angle and length); `render` callback for canvas; `updateTarget` true; `precompile` for heavy morphs.
- [P] Morph rules: same number of subpaths or the morph tears; pick shapeIndex by eye in a dev control; morph duration 0.6 to 1.0 s with power3.inOut; rotational for organic shapes, linear for geometric.
- flubber for arbitrary shapes (one to many, many to one, `separate`, `combine`) when MorphSVG point matching fails.
- Path drawing: DrawSVG (tween `drawSVG: "0% 100%"`) or plain `stroke-dasharray`/`stroke-dashoffset` with `pathLength="1"` on the path so 0 to 1 means the whole stroke. [P] Draw at constant speed (linear or sine.inOut) about 600 to 1200 px of path per second; ease only the ends.

### E3. Liquid and blobs

- Gooey metaballs (SVG): `feGaussianBlur stdDeviation="10"` then `feColorMatrix` alpha row `0 0 0 18 -7` (Lucas Bebber's classic CSS-Tricks recipe) so blurred alpha re-thresholds into merged blobs. [knowledge]
- Organic wobble: `feTurbulence` + `feDisplacementMap scale="20 to 60"`, animate `baseFrequency` slowly (0.005 to 0.02).
- GLSL SDF blobs: Inigo Quilez's smooth minimum `smin(a, b, k)` with k 0.1 to 0.5 merges circles; domain-warped fbm for liquid surfaces.

### E4. Particles and instancing

[P] `THREE.Points` up to about 100k sprites; `InstancedMesh` for 1k to 100k real meshes (one draw call, per-instance matrix and colour); GPGPU (`GPUComputationRenderer`) for 100k to 1M with simulated velocity. Additive blending with `depthWrite: false` for light particles; normal blending with soft shadows for physical ones (confetti is banned as accent decoration [H]). Seed every random so renders are repeatable.

### E5. 3D text

`TextGeometry` with `FontLoader` (typeface JSON) for extruded, bevelled hero words; troika-three-text (MIT) for crisp SDF text that stays sharp at any scale and supports any font file. [P] Bevel 2 to 4% of cap height, extrusion 8 to 20%; one material, one key light, real contact shadow.

### E6. Product turntables and camera rigs

- OrbitControls `autoRotateSpeed` default 2 = 30 s per orbit at 60 fps; `enableDamping` false by default, `dampingFactor` 0.05; call `controls.update()` each frame. [S] For rendered film drive rotation from time instead (`angle = t / period × 2π`) so it is seekable.
- Lens to three.js vertical FOV (full-frame 24 mm sensor height) [D]: fov = 2·atan(12 / f). 24 mm = 53.1°, 35 mm = 37.8°, 50 mm = 27.0°, 85 mm = 16.1°, 135 mm = 10.2°. three.js `PerspectiveCamera.setFocalLength(mm)` uses `filmGauge` (default 35 mm, the larger axis), so its numbers differ from this table; pick one convention per project. [P] Products: 50 to 100 mm look premium (less distortion); 24 to 35 mm for spaces.
- Rig hierarchy [P]: `rig (position: dolly, truck, pedestal) > pivot (rotation: orbit, crane arc) > shake group (noise) > camera (lens)`. Moves:
  - Dolly: translate along view axis; push-ins 5 to 15% of distance over 3 to 5 s.
  - Crane: arc on pivot Y plus pitch change 5 to 20°.
  - Orbit: pivot rotation 15 to 60° per shot for hero, not 360.
  - Handheld: simplex noise on rotation 0.1 to 0.5° and position 0.2 to 1% of subject size at 0.3 to 1.2 Hz, two octaves.
- Theatre.js for hand-keyframed camera paths when code-only curves feel mechanical.

### E7. Depth of field

three.js `BokehPass` (focus, aperture, maxblur) or pmndrs `DepthOfFieldEffect` (focus distance, focal length, bokeh scale). [P] Rack focus 0.6 to 1.2 s with power2.inOut; keep the subject's eyes or the product logo on the focal plane; shallow DOF reads "macro" and miniaturises big scenes, so use deeper DOF for architecture.

### E8. Bloom (with the house warning)

pmndrs `BloomEffect` defaults [S]: blend SCREEN, luminanceThreshold 1.0, luminanceSmoothing 0.03, mipmapBlur true, intensity 1.0, radius 0.85, levels 8. three.js `UnrealBloomPass(resolution, strength, radius, threshold)`. [H] Sanjay bans centre and background glows. Edits rule [P]: bloom only on true HDR speculars (threshold ≥ 1.0 with emissive or HDR lights), intensity 0.2 to 0.6, radius ≤ 0.6, never on the background, never a halo behind a logo.

### E9. PBR materials and HDRI lighting

- `MeshStandardMaterial` (metalness, roughness) and `MeshPhysicalMaterial` (adds clearcoat, clearcoatRoughness, transmission, thickness, ior default 1.5, iridescence, sheen, anisotropy, specularIntensity). [knowledge, three.js docs]
- Environment: `PMREMGenerator` prefilters an HDRI or scene so roughness maps to reflection blur; without it PBR reflections are physically wrong; `RoomEnvironment` is a built-in studio room for `pmrem.fromScene()`; dispose the generator after. [S]
- HDRIs: Poly Haven (CC0). [knowledge]
- [H] 3D needs insides, studio light, texture and wear, or it reads cheap: roughness maps with smudges and micro-scratches (roughness variation 0.05 to 0.2), edge wear on metal, one material per scene on the portfolio.
- [P] Studio light: HDRI for reflections at 0.6 to 1.0 intensity plus one rect area key light at 45° and a rim from behind; tone map AgX or Neutral for products, ACES for cinematic.

### E10. Shaders worth knowing

- Noise: value, simplex (webgl-noise, MIT), fbm (4 to 6 octaves, lacunarity 2, gain 0.5), curl noise for smoke-like flow fields, Worley/cellular for caustics and cells.
- Domain warping (IQ): fbm(p + fbm(p)) for marble, smoke, liquid backgrounds (keep them dark and slow; no centre glow).
- Displacement transitions: sample a noise or depth texture and step a threshold across `progress` for burn, dissolve and liquid wipes; gl-transitions provides 100+ ready ones in the `getFromColor/getToColor/progress` signature.
- SDFs for shapes, rounded boxes, outlines and morphs that stay sharp at any resolution.
- Dither (Bayer 4×4 or 8×8) to kill gradient banding in 8-bit video output: add ±0.5/255 ordered noise before encode. [P]
- Learning: The Book of Shaders (Patricio Gonzalez Vivo, Jen Lowe), Inigo Quilez articles (iquilezles.org).

### E11. Determinism rules for frame-seek renderers (HyperFrames, Remotion)

[P] Every animation is a pure function of time. Build GSAP timelines `paused: true` and seek them; no `requestAnimationFrame`-accumulated state; seed all randomness; `await document.fonts.ready` and image decode before frame 0; snap keys to frames; video textures must be seeked, not played; keep motion blur sample counts identical across frames.

---

## F. References library

| Source | URL | What it is for |
|---|---|---|
| Motionographer | https://motionographer.com | the long-running curated home of motion design, studios, credits |
| Art of the Title | https://www.artofthetitle.com | title sequences with designer interviews; the type-in-film bible |
| Stash | https://www.stashmedia.tv | curated motion, VFX and animation work with full credits (subscription) |
| Vimeo Staff Picks | https://vimeo.com/channels/staffpicks | hand-picked shorts, many motion pieces |
| Behance Motion | https://www.behance.net/galleries/motion | studio case studies with styleframes and process |
| Dribbble (motion) | https://dribbble.com/tags/motion | short UI and brand motion loops |
| Savee | https://savee.com (also savee.it) | designer moodboards, ad-free, "More like this" search |
| Cosmos | https://www.cosmos.so | Pinterest-like visual library, no ads or likes, search by colour and similarity, AI attribution |
| Are.na | https://www.are.na | research boards for references, essays and images |
| Godly | https://godly.website | curated web design with video previews of motion |
| Awwwards | https://www.awwwards.com | award-winning interactive sites (Sanjay's Why Zero won FWA) |
| The FWA | https://thefwa.com | interactive and web motion awards |
| Codrops | https://tympanus.net/codrops | WebGL, GSAP and shader tutorials with source |
| motion.dev examples | https://motion.dev/examples | code examples for springs, layout and scroll motion |
| GSAP showcase and demos | https://gsap.com/showcase | GSAP-built sites and CodePen demos |
| ShotDeck | https://shotdeck.com | searchable film stills by lens, colour, lighting (about $13/month or $100/year, 2-week trial) |
| Film-Grab | https://film-grab.com | free high-res film stills by title |
| Layers | https://layers.to | designer community for sharing work, free |
| Shadertoy | https://www.shadertoy.com | live GLSL reference (check each shader's licence) |
| Fonts In Use | https://fontsinuse.com | real-world typeface usage, find a face from a reference |
| Typewolf | https://www.typewolf.com | type pairings and "free alternatives" lists |
| Poly Haven | https://polyhaven.com | CC0 HDRIs, textures and models for three.js |
| Mobbin | https://mobbin.com | real app screens to replicate UI 1:1 inside films |

---

## Sources

Motion and easing
- GSAP Standard License: https://gsap.com/community/standard-license/
- Webflow, GSAP becomes free: https://webflow.com/blog/gsap-becomes-free
- GSAP eases: https://gsap.com/docs/v3/Eases/ ; RoughEase: https://gsap.com/docs/v3/Eases/RoughEase ; CustomBounce: https://gsap.com/docs/v3/Eases/CustomBounce ; CustomWiggle: https://gsap.com/docs/v3/Eases/CustomWiggle
- GSAP SplitText: https://gsap.com/docs/v3/Plugins/SplitText/ ; ScrambleText: https://gsap.com/docs/v3/Plugins/ScrambleTextPlugin/ ; TextPlugin: https://gsap.com/docs/v3/Plugins/TextPlugin/ ; MorphSVG: https://gsap.com/docs/v3/Plugins/MorphSVGPlugin/
- Adobe community, ease vs eased keyframes: https://community.adobe.com/t5/after-effects-discussions/ease-vs-eased-keyframes/td-p/7493370
- Adobe community, Easy Ease in scripting: https://community.adobe.com/t5/after-effects-discussions/easy-ease-keyframe-temporal-interpolation-in-ae-scripting/m-p/10096541/highlight/true
- School of Motion, Flow review: https://www.schoolofmotion.com/blog/flow-after-effects
- easings.net: https://easings.net/
- material-components-android Motion.md: https://github.com/material-components/material-components-android/blob/master/docs/theming/Motion.md
- Material (M1) duration and easing: https://m1.material.io/motion/duration-easing.html
- Apple SwiftUI Spring: https://developer.apple.com/documentation/swiftui/spring
- Apple SwiftUI Animation: https://developer.apple.com/documentation/swiftui/animation
- spring(duration:bounce:): https://developer.apple.com/documentation/swiftui/animation/spring(duration:bounce:blendduration:)
- spring(response:dampingFraction:): https://developer.apple.com/documentation/swiftui/animation/spring(response:dampingfraction:blendduration:)
- interactiveSpring: https://developer.apple.com/documentation/swiftui/animation/interactivespring(response:dampingfraction:blendduration:)
- snappy: https://developer.apple.com/documentation/swiftui/animation/snappy(duration:extrabounce:) ; bouncy: https://developer.apple.com/documentation/swiftui/animation/bouncy(duration:extrabounce:)
- CASpringAnimation stiffness and damping: https://developer.apple.com/documentation/quartzcore/caspringanimation/stiffness ; https://developer.apple.com/documentation/quartzcore/caspringanimation/damping
- Apple-design skill summary of WWDC18 Designing Fluid Interfaces (secondhand): https://mcpservers.org/agent-skills/emilkowalski/apple-design
- Motion spring and transitions: https://motion.dev/docs/spring ; https://motion.dev/docs/react-transitions
- Chrome, CSS linear() easing: https://developer.chrome.com/docs/css-ui/css-linear-easing-function
- Josh Comeau, linear(): https://joshwcomeau.com/animation/linear-timing-function
- Remotion spring: https://www.remotion.dev/docs/spring ; CameraMotionBlur: https://www.remotion.dev/docs/motion-blur/camera-motion-blur ; Trail: https://www.remotion.dev/docs/motion-blur/trail
- ProVideo Coalition, motion blur: https://www.provideocoalition.com/motion_blur/
- Creative Cow, AE motion blur defaults: https://creativecow.net/?p=97118
- motionscript.com, bounce and overshoot: https://www.motionscript.com/articles/bounce-and-overshoot.html
- Adobe community, inertial bounce threads: https://community.adobe.com/t5/after-effects-discussions/inertial-bounce-multiple-times-on-the-same-property/m-p/13578026
- Adobe, After Effects August 2025 (Quick Offset): https://helpx.adobe.com/after-effects/desktop/using/whats-new/2025-4.html
- NN/g, animation duration: https://www.nngroup.com/articles/animation-duration/
- Netflix English (USA) Timed Text Style Guide: https://partnerhelp.netflixstudios.com/hc/en-us/articles/217350977-English-USA-Timed-Text-Style-Guide
- Netflix Supplementals and Marketing Timed Text Style Guide: https://backlothelp.netflix.com/hc/en-us/articles/115000239632-Timed-Text-Style-Guide-Supplementals-Marketing-Assets
- BBC subtitling guidelines (copy): https://clevercast.com/bbc-subtitling-guidelines
- SSW, time to read texts: https://www.ssw.com.au/rules/post-production-do-you-give-enough-time-to-read-texts-in-your-videos

Typography
- Google Fonts metadata (per family): https://github.com/google/fonts/tree/main/ofl (fraunces, robotoflex, recursive, bricolagegrotesque, monasans, archivo, anybody, bigshoulders, bodonimoda, instrumentsans, instrumentserif, newsreader, inter, unbounded, playfair, ballet, syne, jetbrainsmono, spacegrotesk, anton, geist)
- Inter dynamic metrics (v3 archive): https://d.rsms.me/inter-website/v3/dynmetrics/
- Inter releases: https://github.com/rsms/inter/releases
- Geist font: https://github.com/vercel/geist-font
- WWDC20 note on SF tracking: https://wwdcnotes.com/notes/wwdc20/10175
- Fontshare licensing summaries: https://licenseorg.com/guide/fonts/fontshare ; https://madegooddesigns.com/fontshare/
- Pangram Pangram about: https://pangrampangram.com/pages/about ; https://licenseorg.com/guide/fonts/pangram-pangram
- Apple fonts and SF licence discussion: https://developer.apple.com/fonts ; https://developer.apple.com/forums/thread/733267
- Neue Haas Grotesk history: https://creativepro.com/original-helvetica/ ; https://www.myfonts.com/collections/neue-haas-grotesk-font-Linotype/
- Bebas Neue: https://fontsinuse.com/typefaces/31989/bebas-neue
- Split-flap components: https://github.com/socketopp/svelte-split-flap ; https://github.com/tthompson-figma/react-split-flap-display ; https://www.framer.com/marketplace/components/split-flap-display/

Colour
- Apple palette analyses: https://kombai.com/examples/design-systems/apple-kombai ; https://webdesignhot.com/design.md/apple/
- Riso inks: https://www.monikerpress.ca/colours/ ; https://www.npmjs.org/package/riso-colors
- Pantone Cloud Dancer: https://office-watch.com/2025/pantone-2026-color-cloud-dancer-office/ ; https://pantonecolors.net/pantone/cloud-dancer-11-4201-tcx/
- International Klein Blue: https://en.wikipedia.org/wiki/International_Klein_Blue
- Swiss flag colours: https://www.flagcolorcodes.com/switzerland
- Brat green: https://thenightly.com.au/politics/brat-green-aka-hex-8ace00-you-cant-escape-this-colour-thanks-to-charlie-xcx-c-15494520
- Grand Budapest palettes: https://spotlightfx.com/blog/wes-anderson-color-palette ; https://pixflow.net/blog/the-grand-budapest-hotel-color-palette-analysis-wes-anderson/
- Portra vs 400H: https://slrlounge.com/fuji-400h-vs-kodak-portra-400-the-film-battle-of-titans ; https://emulsive.org/reviews/film-reviews/fuji-film-reviews/fujifilm-pro-400h-the-best-film-ill-never-shoot-again-by-simon-king
- Vindral film grain: https://composer.docs.vindral.com/docs/film-grain
- Frame.io, pro colorist on film grain: https://blog.frame.io/2023/08/14/how-a-pro-colorist-uses-film-grain/
- three.js LUTPass and LUTCubeLoader: https://threejs.org/docs/pages/LUTPass.html ; https://threejs.org/docs/pages/LUTCubeLoader.html
- react-postprocessing LUT: https://react-postprocessing.docs.pmnd.rs/effects/lut
- WCAG 2.2: https://www.w3.org/TR/WCAG22/

Blending and compositing
- W3C Compositing and Blending Level 1: https://www.w3.org/TR/compositing-1/
- MDN mix-blend-mode: https://developer.mozilla.org/en-US/docs/Web/CSS/mix-blend-mode
- MDN globalCompositeOperation: https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/globalCompositeOperation
- MDN mask-mode: https://developer.mozilla.org/docs/Web/CSS/mask-mode
- pmndrs postprocessing source (ChromaticAberrationEffect, VignetteEffect, BloomEffect, NoiseEffect, LICENSE): https://github.com/pmndrs/postprocessing

Code and libraries
- HyperFrames: https://github.com/heygen-com/hyperframes
- Remotion licence and pricing: https://www.remotion.dev/docs/license ; https://www.remotion.dev/docs/pricing ; https://github.com/remotion-dev/remotion/blob/main/LICENSE.md
- Theatre.js licence: https://www.npmjs.com/package/@theatre/studio
- Rive pricing change: https://rive.app/blog/rive-s-new-9-mo-plan
- lottie-web: https://github.com/airbnb/lottie-web
- Motion Canvas: https://github.com/motion-canvas/motion-canvas
- anime.js v4 notes: https://newreleases.io/project/npm/animejs/release/4.0.0
- vfx-js: https://github.com/fand/vfx-js
- OGL: https://github.com/oframe/ogl
- curtains.js: https://github.com/martinlaxenaire/curtainsjs
- flubber: https://www.npmjs.com/package/flubber
- gl-transitions: https://github.com/gl-transitions/gl-transitions
- webgl-noise: https://github.com/stegu/webgl-noise
- LYGIA: https://www.npmjs.com/package/lygia
- three.js OrbitControls: https://threejs.org/docs/pages/OrbitControls.html ; RoomEnvironment: https://threejs.org/docs/pages/RoomEnvironment.html ; PMREMGenerator: https://threejs.org/docs/pages/PMREMGenerator.html

References
- ShotDeck pricing: https://nofilmschool.com/shotdeck-perfect-resource-searchable-movie-images ; https://robinpiree.com/blog/shotdeck
- Cosmos: https://www.cosmos.so/blog/the-future-of-cosmos
- Savee: https://inspire.savee.com

Gaps I could not verify (so not stated as fact above): official Material 3 Expressive spring values, Motion Design School numeric presets, Flow's 25 preset names, DaVinci Resolve Film Grain default numbers, a published frame-offset standard for overlapping action, an official Apple tracking table.
