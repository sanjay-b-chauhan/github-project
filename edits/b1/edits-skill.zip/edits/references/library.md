# Edits library (b1)

Generated from the Edits tool data. Every option a brief can name, with its numbers.

## Formats

### Launch film (`launch`)

Software doing one thing well. 30 s at 60 fps, ratios 16:9, 4:5, 9:16.

- Pace: 12 to 15 compositions per 30 s, beats 1.4 to 3.5 s, no still stretch over 0.6 s, end card 1.5 to 2 s.
- Recipe: feel Butter, camera Push in, cuts Cut the curve, Zoom through, Hard cut, text Line rise, type Geist, colour Graphite, texture Film grain, sound Music bed and SFX.
- Storyboard skeleton: 1. Hook (4 s, Type card, "200 tasks. Before lunch."); 2. Problem (6 s, Type card, "Copy. Paste. Repeat."); 3. Product (8 s, Product UI, "Hand it to your agents."); 4. Payoff (6 s, Chart, "Hours back every week."); 5. Logo and CTA (6 s, Logo build, "Relay").
- Study: Sanji Chien, SaaS launch videos with Claude (https://higgsfield.ai/@sanjii/blogs/how-to-make-saas-launch-videos-with-claude-motion-skill-prompts): Brief, 5 scene storyboard, fix and polish prompts; Linear (https://linear.app): Dark UI, slow camera over interface, one accent; Figma Config 2024 identity (https://www.itsnicethat.com/features/figma-config-2024-identity-graphic-design-spotlight-090724): Identity and motion designed in parallel; echris6 motion video kit (https://github.com/echris6/motion-video-kit): 28 launch films measured frame by frame.
- Skills to lean on if installed: launch-video, motionmaxxing, business-motion-film, oversized-cursor, cut-the-curve, motion-doctrine.

### Hook cut (`hook`)

Won in the first second. 20 s at 30 fps, ratios 9:16.

- Pace: frame 0 is finished, first change by frame 15 to 30, a pattern interrupt every 2 to 4 s.
- Recipe: feel Snap, camera Punch in, cuts Smash cut, Whip pan, Hard cut, text Slam, type Anton, colour Acid, texture Film grain, sound Cut to the beat.
- Storyboard skeleton: 1. Payoff first (1.6 s, Footage, "Nine seconds."); 2. Setup (3.4 s, Talking head, "Here is how I cut every reel I post"); 3. Turn (3 s, Type card, "Cut on the snare."); 4. Proof (4 s, Montage); 5. Loop (2 s, Type card, "Watch it again.").
- Study: Alex Hormozi (https://www.youtube.com/@AlexHormozi): Cuts every 1 to 3 s, Anton captions, one highlight colour; Ali Abdaal (https://www.youtube.com/@aliabdaal): 2 to 5 s shots, greyscale grade, yellow only accent; MrBeast production guide (https://www.tubefilter.com/2024/09/17/mrbeast-internal-production-guide-leaked-key-points/): The first minute proves the thumbnail.
- Skills to lean on if installed: motionmaxxing, reel-export, cinematic-caption, sound-effects.

### Vlog edit (`vlog`)

A day, a trip, a story. 60 s at 24 fps, ratios 16:9, 9:16.

- Pace: cold open 10 to 20 s, B roll every 10 to 20 s, montage plates 4 to 12 f.
- Recipe: feel Butter, camera Handheld, cuts Whip pan, Speed ramp, Hard cut, text Line rise, type Instrument Serif, colour Warm film, texture Film grain, Light sweep, sound Music bed and SFX.
- Storyboard skeleton: 1. Cold open (3 s, Footage, "Day 214"); 2. Title (2.5 s, Type card, "Tokyo, alone."); 3. Montage (3 s, Montage); 4. Story (4 s, Footage, "The 4 a.m. ramen run"); 5. Outro (2.5 s, Type card, "See you tomorrow.").
- Study: Casey Neistat (https://www.youtube.com/@casey): Cut-offs, sped montage, whips between places; Peter McKinnon (https://www.youtube.com/@PeterMcKinnon): In-camera transitions, cinematic B roll intro; Sam Kolder (https://www.instagram.com/samkolder/): Speed ramps, luma transitions, masking; Emma Chamberlain (https://tubefilter.com/2019/06/10/emma-chamberlain-30-hours-editing-each-vlog/): Zooms, on screen text, comic pauses.
- Skills to lean on if installed: hyperframes, media-use, sound-effects, reel-export.

### Talking head (`talk`)

A person, tightened and lit. 45 s at 30 fps, ratios 9:16, 4:5.

- Pace: jump cuts remove pauses over 6 to 10 f, punch-ins 112 to 130% on emphasis, B roll 1.5 to 3 s on the noun.
- Recipe: feel Snap, camera Punch in, cuts Hard cut, Smash cut, text Caption hit, type Anton, colour Black, cream, red, texture Film grain, sound Voice led.
- Storyboard skeleton: 1. Hook line (3 s, Talking head, "Most edits fail in the first second"); 2. B roll (2 s, Footage); 3. Point (3.5 s, Talking head, "Show the payoff before you explain it"); 4. Key line (2 s, Type card, "Payoff first.").
- Study: The Diary of a CEO Clips (https://www.youtube.com/@TheDiaryOfACEO): A separate clips channel built for retention; Raj Shamani, Figuring Out (https://www.youtube.com/@rajshamani): Episodes shaped like a film; Ali Abdaal (https://www.youtube.com/@aliabdaal): Captions beside the speaker, not over him.
- Skills to lean on if installed: cinematic-caption, captions-overlay, hyperframes-media, reel-export.

### Beat edit (`beat`)

The music is the clock. 15 s at 30 fps, ratios 9:16.

- Pace: cut on a grid unit, strobe plates 4 f, words 3 to 4 f apart held 0.9 s, max 3 flashes per second.
- Recipe: feel Snap, camera Punch in, cuts Flash frame, Hard cut, Whip pan, text Slam, type Anybody, colour Night signal, texture Film grain, Blur burst, sound Cut to the beat.
- Storyboard skeleton: 1. Count in (0.9375 s, Footage); 2. Hit (0.9375 s, Type card, "Louder."); 3. Plate (0.9375 s, Footage); 4. Plate (0.9375 s, Footage); 5. Drop (1.875 s, Collage, "Every beat."); 6. Plate (0.9375 s, Footage); 7. Plate (0.9375 s, Footage); 8. Hit (1.875 s, Type card, "Harder."); 9. Run (1.875 s, Montage); 10. Out (3.75 s, Type card, "Again.").
- Study: CapCut velocity edits (https://www.capcut.com/explore/capcut-velocity-edit): Montage, Hero, Bullet, Flash In curves; Pentagram for MTV (https://www.pentagram.com/work/mtv-world-creative-studio): Logos as waveforms on the beat; HyperFrames motion reel (https://github.com/Sunwood-ai-labs/hyperframes-motion-reel-skill): Every cut written on a beat.
- Skills to lean on if installed: hyperframes-motion-reel, sound-effects, motionmaxxing.

### Kinetic type (`kinetic`)

Words are the picture. 20 s at 60 fps, ratios 16:9, 1:1, 9:16.

- Pace: music only: words 3 to 4 f apart, held 0.9 s; voice led: 8 to 12 f.
- Recipe: feel Slam, camera Locked off, cuts Mask wipe, Hard cut, Cut the curve, text Slam, type Archivo Expanded, colour Swiss, texture Film grain, sound Cut to the beat.
- Storyboard skeleton: 1. Line 1 (2.2 s, Type card, "Make it move."); 2. Line 2 (2.2 s, Type card, "Make it land."); 3. Line 3 (2.2 s, Type card, "Then hold still."); 4. Sign off (2.4 s, Type card, "Edits.").
- Study: Saul Bass, Anatomy of a Murder (https://www.artofthetitle.com/title/anatomy-of-a-murder): Cut paper and type as story; Studio Dumbar, Cities in Motion (https://studiodumbar.com/work/cities-in-motion): Variable type driven by code; Animography (https://animography.net): Animated typefaces; DixonBaxi, The CW (https://www.itsnicethat.com/news/dixonbaxi-the-cw-graphic-design-240124): A logo that becomes the stage.
- Skills to lean on if installed: motionmaxxing, cut-the-curve, hyperframes-registry.

### 2D explainer (`explainer`)

One idea, drawn clearly. 60 s at 30 fps, ratios 16:9, 9:16.

- Pace: one idea per scene, 3 to 8 s each, every element arrives on its spoken noun.
- Recipe: feel Butter, camera Pan, cuts Flood and contract, Cut the curve, Push, text Word by word, type Fraunces, colour Editorial cream, texture Paper fibre, Film grain, sound Voice led.
- Storyboard skeleton: 1. Question (3 s, Type card, "Why do some edits feel expensive?"); 2. Idea (3.5 s, Type card, "They land fast and settle slow."); 3. Proof (4 s, Chart, "60 to 72% of the move in 4 frames."); 4. Takeaway (3 s, Type card, "Decelerate in.").
- Study: Kurzgesagt in 1,200 hours (https://also.kottke.org/20/02/how-to-make-a-kurzgesagt-video-in-just-1200-hours): One world, music written to picture; Giant Ant (https://www.giantant.ca): Warm character work with ideas; Ordinary Folk (https://ordinaryfolk.co): Shape language with a reason; Buck (https://buck.co): Craft across 2D and 3D.
- Skills to lean on if installed: category-explainer-video-script-v2, us-native-script, hyperframes, text-to-lottie.

### 3D product (`product3d`)

One object, lit like a studio. 15 s at 60 fps, ratios 16:9, 1:1.

- Pace: a 30 to 60 degree arc in 3 to 5 s, never a constant spin, silence before the first full frame.
- Recipe: feel Drift, camera Orbit, cuts Rack cut, Zoom through, text Tracking close, type Geist, colour Soft studio, texture Film grain, sound Music bed and SFX.
- Storyboard skeleton: 1. Reveal (3.5 s, 3D object, "Made to be held."); 2. Detail (3 s, 3D object, "4.2 mm thin."); 3. Name (3 s, Logo build, "Slab").
- Study: ManvsMachine (https://mvsm.com): Nike Air Max: scanned product, C4D, Houdini; Apple HIG, motion (https://developer.apple.com/design/human-interface-guidelines/motion): Motion that supports, never carries alone; Andrew Kramer (https://www.videocopilot.net): One continuous camera through titles.
- Skills to lean on if installed: three, threejs-materials, threejs-lighting, business-motion-film, title-sequence-3d.

### Logo ident (`ident`)

Two to five seconds of brand. 5 s at 60 fps, ratios 16:9, 1:1, 9:16.

- Pace: mark assembles in about 7 f, wordmark from 3.5x, hold 0.6 to 1.4 s after the last element.
- Recipe: feel Butter, camera Push in, cuts Hard cut, text Line rise, type Geist, colour Black, cream, red, texture Film grain, sound SFX only.
- Storyboard skeleton: 1. Build (3.2 s, Logo build, "Sanjay"); 2. Hold (1.6 s, Type card, "Let's make it.").
- Study: Netflix ta-dum (https://slashfilm.com/netflixs-signature-launch-sound-was-almost-the-bleating-of-a-goat): A sound that works without the picture; DixonBaxi for Hulu (https://www.designweek.co.uk/issues/5-11-april-2021/dixonbaxi-hulu-rebrand/): The vessel comes from the wordmark; Pentagram, EDP (https://pentagram.com/work/edp/story): A dot on a path draws the mark.
- Skills to lean on if installed: motionmaxxing, sound-effects, hyperframes.

### Title sequence (`titles`)

A slow camera through names. 12 s at 24 fps, ratios 21:9, 16:9.

- Pace: one slow dolly forward and slightly up, title in the last third, no shake or spin.
- Recipe: feel Drift, camera Crane, cuts Rack cut, Light sweep, text Tracking close, type Instrument Serif, colour Night signal, texture Film grain, Dust and hairs, Edge vignette, sound Music bed and SFX.
- Storyboard skeleton: 1. Open (3 s, Footage, "A film by Sanjay"); 2. Alley (3 s, Footage); 3. Title (3.5 s, Type card, "Night Shift").
- Study: Kyle Cooper, Se7en (https://imaginaryforces.com/project/se7en): Hand made, scratched, from the killer's hand; Saul Bass, Anatomy of a Murder (https://www.artofthetitle.com/title/anatomy-of-a-murder): A climate for the story; Art of the Title (https://www.artofthetitle.com): The archive of title design.
- Skills to lean on if installed: title-sequence-3d, three, threejs-postprocessing.

### Data story (`data`)

One number that changes minds. 20 s at 60 fps, ratios 16:9, 4:5.

- Pace: axes first, then data, then the annotation on the spoken number; reading hold 1.5 to 3 s with a 3 to 5% push.
- Recipe: feel Butter, camera Push in, cuts Cut the curve, Inverse zoom, text Word by word, type Inter Tight, colour Swiss, texture none, sound Music bed and SFX.
- Storyboard skeleton: 1. Claim (3 s, Type card, "Edits got faster."); 2. Chart (4 s, Chart, "Cuts per minute, 2016 to 2026"); 3. Point (3 s, Type card, "Hold still anyway.").
- Study: Bloomberg, What's Really Warming the World (https://datastori.es/behind-the-scenes-of-whats-really-warming-the-world-with-the-bloomberg-team-ds59/): One factor at a time; The Pudding (https://pudding.cool): Few words, motion that is the insight; Hans Rosling, 200 Countries (https://www.brainpickings.org/2010/12/03/hans-rosling-bbc/): A chart narrated like sport.
- Skills to lean on if installed: animated-chart, milestone-reveal, hyperframes.

### Documentary (`doc`)

Paper, maps, evidence. 45 s at 24 fps, ratios 16:9, 9:16.

- Pace: 8 to 14 one sentence shots, first surprise inside 5 s, every fact sourced on screen.
- Recipe: feel On twos, camera Push in, cuts Hard cut, Mask wipe, text Line rise, type Big Shoulders, colour Newsprint, texture Paper fibre, Film grain, sound Voice led.
- Storyboard skeleton: 1. Place (3.5 s, Paper doc, "Shinjuku, 1964"); 2. Evidence (3.5 s, Paper doc, "One street, 41 bars"); 3. Turn (2.5 s, Type card, "Then the trains came.").
- Study: Vox (https://www.youtube.com/@Vox): Visual evidence, numbers, shape annotations; Johnny Harris (https://www.youtube.com/@johnnyharris): GEOlayers maps, Mapbox styles; Dhruv Rathee (https://www.youtube.com/@dhruvrathee): Hindi English narration with maps and clippings.
- Skills to lean on if installed: vox-explainer, hyperframes, us-native-script.

### Fashion reel (`fashion`)

Flash, cut, negative, repeat. 15 s at 30 fps, ratios 9:16, 4:5.

- Pace: plates 4 to 10 f, hero frames 0.5 to 1.5 s, random cut lengths from a seed, max 3 flashes per second.
- Recipe: feel Snap, camera Handheld, cuts Flash frame, Negative, Hard cut, text Slam, type Syne, colour Brutalist, texture Film grain, Blur burst, sound Cut to the beat.
- Storyboard skeleton: 1. Open (2 s, Collage, "Wear it loud."); 2. Hero (1.6 s, Footage); 3. Wall (2 s, Collage); 4. Name (1.6 s, Type card, "Drop 04").
- Study: brat, Charli XCX (https://www.posterhouse.org/blog/the-rise-and-fall-of-brat/): Lowercase, stretched, 500 greens tested; Spotify Wrapped 2025 (https://rive.app/blog/spotify-used-rive-for-spotify-wrapped-2025): Visual mixtape, built in Rive; Jacquemus FOOH (https://fooh.com/library/jacquemus-driving-bags-rolling-in-paris): One impossible object on a real street.
- Skills to lean on if installed: hyperframes, motionmaxxing, sound-effects.

### Screen tour (`tour`)

How a real tool works. 90 s at 30 fps, ratios 16:9.

- Pace: real screens 1:1, the camera frames one interaction at a time, the cursor only where it truly clicks.
- Recipe: feel Butter, camera Push in, cuts Cut the curve, Zoom through, text Line rise, type Inter Tight, colour Graphite, texture none, sound Voice led.
- Storyboard skeleton: 1. Where (3 s, Type card, "Find the prompt bar."); 2. Do (7 s, Product UI, "Type the task, press Run."); 3. Result (4 s, Chart, "Tickets closed this week").
- Study: Mobbin (https://mobbin.com): Real screens to rebuild 1:1; Screen Studio (https://screen.studio): Auto zoom on clicks, smooth cursor.
- Skills to lean on if installed: zero-video, launch-video, oversized-cursor, us-native-script.

### Event recap (`recap`)

Faces, light, noise, a beat. 30 s at 30 fps, ratios 9:16, 16:9.

- Pace: montage 4 to 12 f plates on the beat, one hero face per 4 bars, the name in the last 15%.
- Recipe: feel Snap, camera Handheld, cuts Whip pan, Flash frame, Hard cut, text Line rise, type Unbounded, colour Teal and orange, texture Film grain, Light sweep, sound Cut to the beat.
- Storyboard skeleton: 1. Doors (2.5 s, Montage); 2. Crowd (2 s, Footage, "Night one"); 3. Faces (2 s, Footage); 4. Name (2.5 s, Type card, "See you next year.").
- Study: Casey Neistat (https://www.youtube.com/@casey): Montage compressed on the beat; Sam Kolder (https://www.instagram.com/samkolder/): Ramps and whips that keep moving.
- Skills to lean on if installed: sound-effects, hyperframes-motion-reel, reel-export.

### Loop (`loop`)

Seamless, for sites and covers. 8 s at 30 fps, ratios 1:1, 4:5.

- Pace: move 0 to 2.2 s, hold to 6.6 s, return by 8 s; frame 0 equals frame 240.
- Recipe: feel Butter, camera Locked off, cuts Hard cut, text Weight wave, type Bricolage Grotesque, colour Soft studio, texture Film grain, sound Silent loop.
- Storyboard skeleton: 1. Move (4 s, Type card, "Made to loop."); 2. Return (4 s, 3D object).
- Study: Charlie Hills motion skills (https://github.com/charlie947/motion-graphics-skills): Loop covers, seam measured at 0 px.
- Skills to lean on if installed: loop-cover, motion-effects, milestone-reveal.

## Motion feel

- **Butter** (`butter`): Lands fast, settles long. Entry: 12 to 14 f, power4.out; Exit: 9 to 10 f, power3.in, ends at speed; Siblings: 1 to 3 f apart, uneven; Words: 4 to 6 f apart; Overshoot: none; one popOver 1.08 per beat at most. When: The default for almost everything. 60 to 72% of the travel happens in the first 4 frames, then a long soft tail. Code: `gsap.from(el, { y: 60, duration: 0.45, ease: 'power4.out' })`
- **Snap** (`snap`): Hard, quick, confident. Entry: 6 to 8 f, expo.out; Exit: 4 f, power3.in; Words: 2 to 4 f apart; Cuts: every 0.3 to 1.5 s. When: Hooks, talking heads, sport and anything judged by the swipe. Code: `gsap.from(el, { y: 40, duration: 0.24, ease: 'expo.out' })`
- **Spring** (`spring`): Physical bounce, once per film. Damping: 0.55 playful, 0.72 to 0.85 premium; UI spring: k 320, d 30; Containers: k 170, d 26; Rule: one visible spring per film; never bounce.out or elastic. When: Playful explainers and consumer apps. Use it once, on the thing that matters. Code: `spring(t) = 1 - e^(-z w t) (cos(wd t) + z w / wd sin(wd t))`
- **Whip** (`whip`): Fast in, fast out, blur at peak. Length: median 8 f; Peak speed: about 13% of frame per frame; Blur: 10 px text, 18 to 20 px full frame; Ease: power4.in into the cut, power4.out after. When: Location jumps, vlogs, music edits. The cut hides inside the blur. Code: `exit: x -115% power4.in + blur; entry: x 115% to 0 power4.out`
- **Slam** (`slam`): Arrives oversize, lands hard. Scale: 1.5 to 3.5x down to 1; Time: 3 to 5 f, power4.out; Shake: 2 to 3 f, 4 to 10 px; Spacing: one word per beat. When: Kinetic type on a beat, idents, hook words. Landed words are dead still. Code: `gsap.fromTo(word, { scale: 3.5 }, { scale: 1, duration: 0.15, ease: 'power4.out' })`
- **Drift** (`drift`): Slow, cinematic, unhurried. Entry: 1 to 1.5 s, sine.inOut; Camera: 100 to 106% over a shot; Words: 8 to 12 f apart, voice led. When: Title sequences, luxury, documentary, 3D products. Code: `gsap.from(el, { y: 30, duration: 1.2, ease: 'sine.inOut' })`
- **On twos** (`twos`): Hand made cadence at 12 fps. Cadence: hold each pose 2 f at 24 fps; Code: t = floor(t * 12) / 12; Jitter: 0.5 to 2 px per pose, seeded. When: Vox style, collage, paper, stop motion. Everything steps, nothing glides. Code: `const tq = Math.floor(t * 12) / 12; render(tq)`

## Camera

- **Push in** (`push`): 100 to 106% across the shot. Scale: 1.00 to 1.06; Ease: easy ease, sine.inOut; Reading holds: 3 to 5% push on report and CTA frames. When: The default camera. Quietly says look closer.
- **Pull back** (`pull`): Reveal the whole board. Scale: 1.16 to 1.00; Ease: power3.out. When: Payoffs. When the count hits zero, pull back so we see everything clear.
- **Pan** (`pan`): Easy ease side to side. Travel: about 7% of frame; Ease: sine.inOut, slow start and stop; Direction: one current per film, default left. When: Following a cursor or a line of objects.
- **Orbit** (`orbit`): Around the subject with parallax. Rotation: plus or minus 9 degrees; Layers: 3 planes, near moves 1.5 to 2x far. When: 3D products, hero objects, title cards with depth.
- **Dolly zoom** (`dolly`): Subject holds, world stretches. Foreground: 1.00 to 1.08; Background: 1.16 to 1.02. When: One unsettling moment per film. A realisation.
- **Handheld** (`hand`): Seeded noise, a human operator. Position: about 0.4% of frame; Roll: about 0.35 degrees; Rule: seeded, never Math.random. When: Vlogs, fashion, documentary, anything that should feel shot.
- **Crane** (`crane`): Rises or drops through the frame. Travel: about 9% of frame height; Ease: sine.inOut. When: Openers and endings. Up means elevation.
- **Punch in** (`punch`): A cut to a tighter crop. Scale: 100% to 112 to 130%; Hold: at least 1.5 s; Rule: instant on the cut, never tweened. When: Talking heads, on emphasis and topic changes only.
- **Rack focus** (`rack`): Focus moves from type to ground. Blur: 10 px text, up to 18 px frame; Ease: power2.in and out; Breathing: lens scale about 1.06. When: Moving the eye between two planes without a cut.
- **Locked off** (`locked`): No camera, the subject moves. Rule: life comes from the next element. When: Loops, data, minimal edits, symmetrical frames.

## Transitions

- **Hard cut** (`cut`): The default, 96% of pro cuts. Length: 0 f; Rule: A accelerates into it, B's first frame already moving. When: Always first. Strongest on action at peak speed.
- **Cut the curve** (`curve`): 12% travel, mirrored power4. Travel: about 12% of frame (230 px at 1920); Total: about 0.6 s; Ease: power4.in out, power4.out in; Blur: 10 px text, 18 to 20 px frame. When: The house default seam between scenes. Velocity matches across the cut.
- **Zoom through** (`zoom`): Push past A, B arrives from depth. Exit: 1 to 1.2 in 0.2 s, power3.in; Entry: 0.75 to 1 in 0.5 s, expo.out; Split: 30% exit, 70% entry; Rule: if A grows, B also grows. When: Going deeper into an idea. Never two texts visible at once.
- **Inverse zoom** (`izoom`): A recedes, B arrives in front. Exit: 1 to 0.8; Entry: 1.25 to 1; Total: about 0.7 s. When: Arrival beats only. Stepping back to see more.
- **Whip pan** (`whip`): The cut hides in the blur. Length: 8 f median, 7 to 15 f; Cut: 5 f into a 10 f move; Sound: airy whoosh from 3 to 4 f before peak. When: Location and topic jumps with energy.
- **Smash cut** (`smash`): Loud to quiet, or quiet to loud. Length: 0 f, often after 2 to 6 f of silence; Sound: instant state change, no tail. When: Comedy, reveals, contrast hooks.
- **Push** (`push`): B shoves A out of frame. Length: 8 to 15 f full frame; Ease: halves of one power4.inOut. When: Lists, galleries, carousel reels.
- **Mask wipe** (`mask`): A hard angled edge reveals B. Sweep: 5 f accelerating for text, 10 to 16 f frame; Angle: about 12 degrees. When: Clean chapter changes. Line replacements in type.
- **Flood and contract** (`morph`): The object becomes the next scene. Flood: clears the farthest corner x 1.05 in 0.3 to 0.35 s; Then: contracts into the next object. When: When a button, logo or dot should become the next world.
- **Rack cut** (`rack`): Blur out, cut at peak, resolve. Peak blur: 8 to 12 px, max 18; Ease: power2.in and out; Rate: at most once per 8 s. When: Soft scene changes, memories, product details.
- **Flash frame** (`flash`): 1 to 2 frames of white. Length: 1 to 2 f at 30, 2 to 4 at 60; Safety: 3 flashes per second at most; Rule: never stacked with a negative. When: Beats, camera flash looks, impact.
- **Negative** (`neg`): B lands inverted for 2 frames. Length: 1 to 3 f; Rule: only on a hit, never with a flash. When: Fashion, beat edits, DZ style hits.
- **Shutter bars** (`bars`): Five bars wipe across and away. Stagger: 1 to 2 f per bar; Length: 8 to 15 f in, same out. When: Chapter breaks. Use sparingly.
- **Light sweep** (`sweep`): A hard band of light crosses the cut. Length: 12 to 30 f; Blend: screen, linear band, enters from an edge; Rule: never sits centred. When: Warm films, memories, travel. The swap hides at full cover.
- **Speed ramp** (`ramp`): Accelerate out, decelerate in. Ramp: 4 to 10 f between speeds; Range: 100% to 300 to 800% and back. When: Payoffs in action, sport, travel.
- **Match cut** (`match`): The shape survives the cut. Position: within 2% of frame; Also: same scale, colour and velocity. When: Graphic matches: a dot becomes a sun, a button becomes a logo.

## Text motion

- **Line rise** (`mask`): Each line rises out of its mask. Travel: yPercent 100 to 0; Time: 10 to 12 f, power4.out; Lines: 4 f apart. When: The cleanest title move there is.
- **Word by word** (`words`): Words land on speech rhythm. Hook: 2 to 4 f apart; Headline: 4 to 6 f; Voice led: 8 to 12 f. When: Headlines and spoken lines.
- **Letter cascade** (`chars`): Letters 1 f apart, uneven. Stagger: 1 f, gaps like 3,2,2,2; Whole wave: under 0.6 s. When: Short words and names. Never paragraphs.
- **Slam** (`slam`): One word per beat, from oversize. Scale: 1.5 to 3.5x to 1 in 3 to 5 f; Shake: 2 to 3 f. When: Beat edits and hooks.
- **Decode** (`scramble`): Glyphs cycle, then lock in order. Lock: left to right, 0.02 s per letter; Rule: seeded glyphs, fixed widths. When: Tech, security, reveals of a name.
- **Typing** (`type`): Only inside a real input. Speed: 21 to 30 characters per second; Rhythm: irregular, pause on spaces; Caret: blinks 0.53 s on, 0.53 s off. When: Prompts and search bars. Never for headlines.
- **Weight wave** (`weight`): Each letter grows from thin to bold. Axis: wght 120 to 820; Stagger: 0.03 s per letter. When: Variable fonts, loops, brand moments.
- **Stretch** (`stretch`): Letters widen into place. Axis: wdth 50 to 112; Time: 0.8 s, power4.out. When: Anybody or Archivo. Sport, music, posters.
- **Tracking close** (`track`): Wide letter spacing pulls tight. Spacing: 0.55 em to -0.035 em; Time: 1.4 s, expo.out. When: Title sequences and luxury.
- **Caption hit** (`karaoke`): Spoken word lights up. Page: 1 to 3 words; Lead: word shows 0 to 2 f before it is said; Pop: scale 0.8 to 1 in 4 to 6 f. When: Talking heads only. One caption system, one accent.

## Type

- **Geist** (`geist`): Geist with Geist Mono for numbers. Vercel, OFL, Google Fonts. CSS: 'Geist', sans-serif, display weight 600. Best for Product, SaaS, AI tools.
- **Inter Tight** (`inter`): Swiss neo grotesk, set tight. Rasmus Andersson, OFL, Google Fonts. CSS: 'Inter Tight', sans-serif, display weight 700. Best for Data, interfaces, corporate.
- **Instrument Serif** (`instrument`): Condensed display serif with Instrument Sans. Instrument, OFL, Google Fonts. CSS: 'Instrument Serif', serif, display weight 400. Best for Editorial, vlogs, title cards.
- **Anton** (`anton`): Condensed impact for captions and hooks. Vernon Adams, OFL, Google Fonts. CSS: 'Anton', sans-serif, display weight 400. Best for Hook cuts, talking heads, sport.
- **Archivo Expanded** (`archivo`): Width axis 62 to 125, set wide. Omnibus Type, OFL, Google Fonts. CSS: 'Archivo', sans-serif, variation 'wdth' 125, display weight 800. Best for Kinetic type, tech, motorsport.
- **Anybody** (`anybody`): Width 50 to 150, made to stretch. Tyler Finck, OFL, Google Fonts. CSS: 'Anybody', sans-serif, variation 'wdth' 112, display weight 800. Best for Beat edits, kinetic type, posters.
- **Fraunces** (`fraunces`): Soft old style display with Manrope. Undercase Type, OFL, Google Fonts. CSS: 'Fraunces', serif, variation 'opsz' 144, 'SOFT' 50, display weight 600. Best for Explainers, food, warm brands.
- **Bricolage Grotesque** (`bricolage`): Characterful grotesk, optical sizes. Mathieu Triay, OFL, Google Fonts. CSS: 'Bricolage Grotesque', sans-serif, variation 'opsz' 96, display weight 700. Best for Consumer apps, loops, playful.
- **Space Grotesk** (`space`): Techy grotesk with Space Mono. Florian Karsten, OFL, Google Fonts. CSS: 'Space Grotesk', sans-serif, display weight 600. Best for Dev tools, crypto, hardware.
- **Unbounded** (`unbounded`): Wide geometric display with Onest. NaN, OFL, Google Fonts. CSS: 'Unbounded', sans-serif, display weight 700. Best for Events, recaps, Gen Z.
- **Big Shoulders** (`shoulders`): Tall condensed display with Newsreader. Patric King, OFL, Google Fonts. CSS: 'Big Shoulders Display', sans-serif, display weight 800. Best for Documentary, labels, sport.
- **Syne** (`syne`): Gets wider as it gets bolder. Bonjour Monde, OFL, Google Fonts. CSS: 'Syne', sans-serif, display weight 800. Best for Fashion, art, culture.

## Colour

- **Graphite** (`graphite`): Product dark, one cobalt accent. Ground #0A0A0B, ink #F2F1EC, accent #3D7BFF, surface #141417, muted #3A3A41, edge #2B2B31. For SaaS launches, screen tours, AI products.
- **Swiss** (`swiss`): Off white, black, signal red. Ground #EFEDE6, ink #111111, accent #E5361B, surface #FFFFFF, muted #BDB9AE, edge #D6D2C7. For Data, kinetic type, posters.
- **Editorial cream** (`cream`): Warm paper, ink, terracotta. Ground #F3EEE3, ink #1B1814, accent #B4502B, surface #FBF8F1, muted #D2C8B5, edge #DCD3C2. For Explainers, essays, founder films.
- **Black, cream, red** (`scd`): Sanjay Chauhan Designs brand. Ground #0B0B0B, ink #FFFDE2, accent #FF0101, surface #141413, muted #3A3934, edge #2E2D29. For Personal brand, talking heads, idents.
- **Acid** (`acid`): Near black with acid lime. Ground #0C0C0C, ink #F4F4F0, accent #D4FF3A, surface #151515, muted #2E2E2E, edge #2C2C2C. For Hook cuts, Gen Z, sports.
- **Chrome** (`chrome`): Silver, ink, electric blue. Ground #D9DDE3, ink #0E1116, accent #2D5BFF, surface #EEF1F5, muted #A9B0BA, edge #BEC5CF. For Y2K, tech hardware, 3D.
- **Teal and orange** (`teal`): The cinema grade. Ground #0E2228, ink #F6EBDD, accent #F08A3C, surface #132C33, muted #2B4A52, edge #25454D. For Vlogs, travel, recaps, trailers.
- **Risograph** (`riso`): Paper with fluoro pink and blue. Ground #F4EFE1, ink #1E1E1E, accent #FF48B0, surface #FBF7EC, muted #D8CFBA, edge #DCD3BE. For Posters, music, playful brands.
- **Night signal** (`night`): Ink black, one hot red. Ground #07070A, ink #EDEDF2, accent #FF2E4D, surface #101015, muted #24242C, edge #26262F. For Title sequences, beat edits, trailers.
- **Soft studio** (`pastel`): Lilac paper, ink, peach. Ground #F1ECF7, ink #1F1D2B, accent #7C5CFF, surface #FFFFFF, muted #D8D0E6, edge #DDD5EA. For 3D loops, wellness, consumer apps.
- **Warm film** (`kodak`): Brown black, gold, rust. Ground #1F1712, ink #F5E6CF, accent #E9A23B, surface #2A1F18, muted #4A3A2E, edge #46362A. For Vlogs, memory, food, weddings.
- **Blueprint** (`blueprint`): Cyan ink on navy, one yellow. Ground #0D2F55, ink #E9F1FF, accent #FFD23F, surface #12396A, muted #2B5687, edge #2F5D92. For Engineering, how it works, diagrams.
- **Brutalist** (`brut`): White, black, safety orange. Ground #FFFFFF, ink #000000, accent #FF4F00, surface #F4F4F4, muted #CFCFCF, edge #D9D9D9. For Fashion, manifestos, streetwear.
- **Newsprint** (`news`): Paper, ink, marker yellow. Ground #EFE6D4, ink #151412, accent #E9B10E, surface #F7F0E1, muted #CFC2A8, edge #D6C8AC. For Documentary, Vox style, history.

## Texture and blending

- **Film grain** (`grain`): Overlay blend, new every frame. Blend: overlay or soft light; Amount: 3 to 8%; Rate: 24 fps, seeded. When: Almost always. Kills banding, adds a shot feel.
- **Paper fibre** (`paper`): Multiply blend on light grounds. Blend: multiply; Amount: 10 to 20%. When: Documentary, explainers, editorial.
- **Halftone** (`halftone`): Dot screen at 45 degrees. Screen: 60 to 120 lines across the frame; Blend: multiply or soft light. When: Print, Vox, posters, archival.
- **Scanlines** (`scan`): CRT lines with a light flicker. Pitch: 2 to 4 px at 1080; Blend: multiply. When: Retro tech, screens inside screens.
- **Dust and hairs** (`dust`): Specks that change on twos. Rate: 12 fps; Blend: screen. When: Archival, film, title sequences.
- **Edge vignette** (`vignette`): Darkens the edges only. Amount: 8 to 12%; Rule: off on white or negative frames, never a centre glow. When: Dark films and 3D. Depth without a glow.
- **Light sweep** (`sweep`): A warm band crosses now and then. Blend: screen; Shape: linear band from an edge. When: Warm films. Never a radial blob.
- **Colour fringe** (`chroma`): RGB split at cuts only. Offset: 1 to 3 px at 1080; When: the 2 to 4 frames around a cut. When: Energy at cuts. Never on held frames.
- **Blur burst** (`burst`): A 3 frame blur insert. Length: 2 to 4 f; Blur: 12 to 16 px. When: Beat edits and fashion. Reads as a lens snap.
- **Negative hit** (`neg`): 2 inverted frames on each new shot. Length: 1 to 3 f; Rule: never with a flash on the same frame. When: Fashion and beat edits.

## Sound

- **Music bed and SFX** (`bed`): A low bed, one sound per moment. Music: -20 LUFS; Master: -18 LUFS, true peak under -1 dBTP; SFX: 3 to 4 dB over the bed in band; Rule: never the same sound on consecutive cuts.
- **Cut to the beat** (`beat`): The track is the clock. Grid: frames per beat = fps x 60 / BPM; Cut: on the beat or 1 f early; Phrase: change pattern every 4 or 8 bars; Before the drop: clear 0.2 to 0.5 s.
- **Voice led** (`voice`): The screen obeys the voice. Pace: 2.5 to 3 words per second; Duck: music down 9 dB, 80 ms in, 300 ms out; Rule: never print the narration.
- **SFX only** (`sfx`): No music, every action sounds. Clicks: -6 to -10 dB, one dry layer; Typing: a texture, never a tick per letter.
- **Silent loop** (`silent`): For GIFs, sites and covers. Loop: last frame equals first; Check: 0 px difference at the seam.

## Ratios

- **16:9**: 1920 x 1080. YouTube, site hero, keynote, X.
- **9:16**: 1080 x 1920. Reels, TikTok, Shorts.
- **1:1**: 1080 x 1080. Feed, LinkedIn, X.
- **4:5**: 1080 x 1350. Instagram and LinkedIn feed.
- **21:9**: 2520 x 1080. Cinematic title cards.

## Laws

1. **Storyboard first.** The storyboard is the source of truth. No scene is reordered, added or dropped without asking. Without it, Claude guesses and everything moves at once.
2. **Every adjective becomes a number.** Fast is 6 to 8 frames. A slow push is 100 to 106%. Reading time is 0.2 s a word with a 0.45 s floor.
3. **Land soft, leave fast.** Entries put most of their travel in the first 4 frames, then a long tail. Exits accelerate, end at full speed and run about 25% shorter.
4. **Move as a family.** Related things sit under one parent and move 1 to 3 frames apart. The next move starts before the last one settles.
5. **Never idle, never wobble.** Something changes on almost every frame, but landed type is dead still. Life comes from the next element, the real UI or a camera with intent.
6. **Cut on motion.** A cut works when A accelerates into it and B's first frame is already moving. Two or three transition kinds per film, repeated.
7. **The screen obeys the voice.** Whatever is spoken is the brightest thing on screen, on the word. The voice carries the words; narration is never printed.
8. **Real things stay real.** Real UI rebuilt as vectors so the camera can zoom, real logos, real data with its source, real footage. Nothing invented.
9. **One hero, one accent, three sizes.** One thing to look at per frame, one accent colour, three type sizes, tracking -0.035 em at 30 px and up.
10. **Stills before motion, a critic before shipping.** Approve 3 to 4 stills first. The builder never judges its own film.

## Never

- Radial or centre glow, inner glow, bloom haze, lens flares, neon glow
- Opacity fade entrances and exits, crossfades between scenes
- Eyebrow tags, body tags and filler micro text
- Em dashes and en dashes in any copy
- Underlines for emphasis
- Glitch as a transition (hover only)
- bounce.out and elastic eases
- The same sound on consecutive cuts, a whoosh on every cut
- Captions that print the narration
- Circle iris as the default wipe
- Glass panels and UI floating on a gradient void with drop shadows
- Stat slides, "Meet X", "seamless", "Not just X. It's Y."
- Synthesised music, time stretched voice takes
- More than 3 flashes in any second

## Numbers

| Rule | Number | Source |
|---|---|---|
| Median move | 10 f at 30 fps (0.33 s) | motionmaxxing, 4,288 moves |
| Entry, translate or scale | 12 f, power4.out | motionmaxxing |
| Exit | 9 to 10 f, power3.in, ends at speed | motionmaxxing |
| Sibling stagger | 1 to 3 f, uneven | motionmaxxing |
| Word cadence | 2 to 4 f hook, 4 to 6 headline, 8 to 12 voice led | motionmaxxing |
| Reading hold | 0.2 s a word, floor 0.45 s | motionmaxxing |
| End hold | 0.6 to 1.4 s, final shot under 25% of the film | motionmaxxing G3 |
| Overshoot | on under 9% of moves; popOver 1.08 at t 0.72 | motionmaxxing |
| Seam travel | about 12% of frame, mirrored power4 | cut-the-curve |
| Seam blur | 10 px text, 18 to 20 px full frame | cut-the-curve |
| Zoom through | 1 to 1.2 in 0.2 s, then 0.75 to 1 in 0.5 s | cut-the-curve |
| Stillness before the climax | 0.3 to 0.75 s | motion-doctrine |
| Premium spring damping | 0.7 to 0.85 | hyperframes, howseen |
| Cursor | about 5% of frame inside a mock; click 0.84 in 0.1 s, back in 0.22 s | oversized-cursor |
| Typing | 21 to 30 characters per second | motionmaxxing |
| 30 s launch | 12 to 15 compositions, beats 1.4 to 3.5 s | echris6, 28 films |
| Hook | frame 0 finished, first change by frame 15 to 30 | echris6, short form research |
| Punch in | 112 to 130%, hold 1.5 s | talking head research |
| Beat grid | frames per beat = fps x 60 / BPM | hyperframes |
| Flash safety | 3 flashes per second at most | WCAG 2.3.1 |
| Music and master | -20 LUFS music, -18 master, true peak under -1 dBTP | sanjay-motion-tools sound kit |
| Duck under voice | 9 dB, 80 ms in, 300 ms out | motionmaxxing |
| 9:16 safe band | text between y 360 and 1420, right 120 px clear | reel-export |
| Title safe | 80% box for text, 90% for action | hyperframes |
| Film lettering | -0.035 em at 30 px and up, -0.02 em below | house rule |

## Revision notes the Notes tab can send

**Canvas**

- Lock the canvas to the master size and position everything from the centre, not the edges.
- Keep every headline and logo inside the title safe box for every ratio.
- Nothing spills its container. Check every label, button and bezel at 2x.
- Recompose this ratio from the timeline. Do not crop the master.

**Timing**

- Make the count last about one second. Long enough to read, quick enough not to drag.
- Hold the key frame 1.5 s before the next move.
- Words land 4 to 6 frames apart here, not all at once.
- Cut 2 frames earlier so the cut lands on the beat.
- Clear the sound for 0.3 s before the biggest move.
- End hold is too long. Bring it to 0.6 to 1.4 s with one thing still alive.

**Motion**

- Bring the cards in one by one, a few frames apart, and let each land before its check appears.
- Entries land faster: power4.out, most of the travel in the first 4 frames.
- Exits leave faster than they came in and end at full speed.
- This fades in. Replace it with a rise out of a mask or a scale from its origin.
- Related elements move as one family, 1 to 3 frames apart.
- Landed type is wobbling. Make it dead still and move the camera instead.

**Camera**

- Slow the pan down and give it an easy ease so it starts and stops softly.
- When the counter hits zero, pull the camera back so we see the whole board.
- Push in 100 to 106% across this shot.
- Zoom into the button on the click, about 130%, then ease back out.

**Type**

- Load the font before frame 0. No fallback frames.
- Tighten tracking to -0.035 em on everything 30 px and up.
- Three type sizes only. Merge the extra size into the nearest one.
- This line is printed narration. Cut it and let the voice carry it.

**Look**

- Remove the glow. Depth comes from the edge vignette, grain and light.
- Add grain at 5% so the gradients stop banding.
- One accent colour. Take the second accent out.
- Swap the screenshot for rebuilt vector UI so the zoom stays sharp.

**Polish**

- Make the cursor hesitate between tabs for about a second, like a real person losing track.
- Give each card a small pulse when it starts working.
- Cascade the checkmarks down the list instead of showing them together.
- Give the counter a hit on its last value: scale 1.04 and back in 6 frames.

**Sound**

- Music is too loud. Bed at -20 LUFS, master -18.
- Two cuts in a row use the same sound. Give each moment its own.
- Land the click on the press frame, not after it.
- Duck the music 9 dB under the voice.
