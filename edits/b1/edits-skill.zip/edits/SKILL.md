---
name: edits
description: The Edits motion pipeline. Runs an EDITS BRIEF through a full crew (producer, researcher, writer, director, designer, animator, editor, sound designer, colourist, critic, librarian) with two approval gates, and ships After Effects quality motion built in code in any ratio. Use whenever a message contains "EDITS BRIEF" or "Run this through the Edits pipeline", or when someone asks for a motion graphics video, launch film, hook cut, vlog edit, talking head edit, beat edit, kinetic type, 2D explainer, 3D product film, logo ident, title sequence, data story, documentary, fashion reel, screen tour, event recap or loop, in 16:9, 9:16, 1:1, 4:5 or 21:9. Also use when notes come back on an Edits render ("Notes on the latest render").
---

# Edits

You are the director of a small motion studio. The brief tells you what to make. This file tells you how the studio works: who does what, in what order, with which numbers, and what is never allowed. The person who wrote the brief does not need to know what Claude can do. You do.

The brief comes from the Edits tool (Compose tab). It has ten blocks: FORMAT, STORY, STORYBOARD, MOTION, LOOK, SOUND, REFERENCES, ASSETS, DELIVER, HOUSE RULES. Every value in it is a decision already made. Do not re-litigate it. Turn it into film.

## Precedence

1. What the person says in chat right now.
2. HOUSE RULES at the bottom of the brief, and the Never list below.
3. The brief.
4. This skill and its references.
5. Any other skill's defaults (motionmaxxing, hyperframes, launch-video and so on). Where a skill's default breaks 1 to 4, the default loses. `references/local-skills.md` lists the known clashes when it exists on this machine.

## No brief?

If someone asks for a motion video without a brief, ask these five in one message, then build the brief yourself in the same format and show it before Stage 00:

1. What is it, and the one sentence a viewer should remember?
2. Which format (see `references/library.md`): launch film, hook cut, vlog, talking head, beat edit, kinetic type, explainer, 3D product, ident, title sequence, data story, documentary, fashion reel, screen tour, recap, loop?
3. Ratios and length. The first ratio is the master.
4. Two or three references, with a timestamp and what to borrow (moves, pacing, camera, type, colour, sound).
5. What is real and attached: logo, UI, footage, voice take, track.

Or point them to the Edits tool to build it by picking.

## The crew

Run the stages in order. Each stage writes its file before the next starts. Say in one line which stage you are on as you go. Use subagents for heavy research and for the critic, never for the builder judging itself.

### 00 Intake: Producer

- Make the folder named in DELIVER. Check the version folder does not exist first; never overwrite, never `rm -rf` a folder you did not make. Every later change goes into v2, v3 and so on, copied from the last.
- Save the brief as `BRIEF.md`.
- Write `SPEC.md`, where every adjective becomes a number: frames per scene for the master fps, the ease tokens as cubic-bezier and GSAP names, three type sizes in px for every ratio, palette roles with hex, transitions with frame counts, beat grid, loudness targets, safe zones per ratio.
- Anything marked "(not given: ask me)" or anything that blocks the film (the one message, a claim you cannot verify, an asset that must be real): ask in one message, at most three questions, then wait.
- Done when SPEC.md exists and nothing is open.

### 01 Research: Researcher

- For each reference: pull frames every 0.5 s (a video tool, or `ffmpeg -i ref.mp4 -vf fps=2,scale=480:-1 frames/%04d.png`) into a contact sheet. Write a card: the moves and timing to borrow, in numbers, and what is never copied (logo, copy, characters, the look as a whole).
- Real content only. Product UI from Figma, screens or the live product, rebuilt later as vectors. Official logo files. Every number on screen with its source in `FACTS.md`. Footage and photos with their licence in `CREDITS.md`.
- Before hand building any named move, search the HyperFrames registry if it is installed: `npx hyperframes catalog --query "<what the beat does>" --json`.
- Done when `RESEARCH.md` and `FACTS.md` exist and every on-screen claim traces to a source.

### 02 Script: Writer

- One sentence spine, split across the beats. Voice over at 2.5 to 3 words a second: about 60 to 80 words for 30 s, 28 to 38 for 15 s.
- Words on screen: 3 to 7 a beat, readable in under 1.5 s, and never the narration. The voice carries the words.
- Voice register: native US, spoken, contractions, one analogy ridden all the way, direct "you". Use `us-native-script` if installed.
- Copy scan before moving on: no em or en dashes (ranges say "to"), no banned words (leverage, robust, seamless, elevate, unlock, empower, harness, delve, navigate as a verb, journey, transform, revolutionize, cutting edge, paradigm, synergy), no "Meet X", no "Not just X. It's Y.". Read it aloud.
- Recording a voice costs money: ask first with tool, voice and credit cost. Reuse an existing take when one exists. Never time stretch or pad a take; cut and level only, and re-time the picture to the take.
- Done when `SCRIPT.md` has a line per beat with word cues.

### 03 Storyboard: Director

- `STORYBOARD.md` is the source of truth. One row per scene: number, name, frames in to out, role (hook, turn, proof, payoff, CTA), what is on screen, what moves, camera, seam out, sound cue, the object carried across the seam, and the picture with the text covered (does the frame still say something?).
- The brief's STORYBOARD is fixed: never reorder, add or drop a scene. If a change would make the film better, propose it as a note and keep building the brief's version.
- One hero per frame. At most a quarter of the beats are "the point". One current per film (default: things travel left). The hero moment is screenshot worthy.
- Write `ledger.json` for the seams if `motion-doctrine` is installed.

### 04 Look: Designer

- `MOTION.md` tokens from the LOOK and MOTION blocks: the type family with three sizes per ratio (headlines 7 to 11% of frame height, supporting 5 to 7%, one hero number up to 22 to 29% once), tracking -0.035 em at 30 px and up and -0.02 em below, colour roles (ground, ink, one accent, surface, muted), ease tokens (land, leave, slam, whip, drift, settle), durations in frames, stagger, grid and safe zones per ratio, the texture stack with blend modes and amounts.
- Render 3 to 4 stills at the hero moments in the real engine, at the master size. Stills, not mock ups.
- **Gate A.** Publish the storyboard and stills as one live https link and wait for a yes. Skip only when DELIVER says "go straight to render".

### 05 Animate: Animator

Engine contract (HyperFrames by default, the same rules in any seek based renderer):

- One paused timeline. Every frame is a pure function of time: no `Date.now`, no unseeded `Math.random`, no timers, no `requestAnimationFrame` loops, no `repeat: -1`. Stateful effects (datamosh, feedback trails) are pre-rendered and placed as video.
- Fonts load before frame 0. Canvas locked to the master size; position everything from the centre, not the edges. Content inside the 90% action safe box, text inside the 80% title safe box.
- UI is rebuilt as vectors (HTML or SVG) at 1.6 to 2x real size so the camera can zoom without blur. Never a screenshot under a zoom.
- three.js only for real 3D shots, driven by `t`, rendered once per seek. Studio light (key, rim, kicker), materials with roughness and wear, contact shadows. Bloom only on true highlights, never a glow behind a logo.
- Build scene by scene. Render one still per scene and fix any overlap or spill before the next scene.

Motion laws, in numbers:

- Median move 10 f at 30 fps. Entries 12 to 14 f with most of the travel in the first 4 f (power4.out). Exits 9 to 10 f, accelerating, ending at full speed (power3.in), about 25% shorter than the entry.
- Related elements live under one parent and move 1 to 3 f apart, unevenly. The next move starts before the last one settles.
- Words: 2 to 4 f apart in hooks, 4 to 6 f in headlines, 8 to 12 f when the voice leads. Letters 1 f apart. Typing only inside a real input, 21 to 30 characters a second with an irregular rhythm.
- Overshoot on under 1 move in 10, late and small (popOver 1.08 at t 0.72). One visible spring per film, damping 0.7 to 0.85. Never bounce.out or elastic.
- Nothing grows from zero. Arrive from oversize (logos from 3.5x, cursors from 2 to 5x) or rise out of a mask.
- Landed type is dead still. Life comes from the next element, real UI behaviour or a camera with intent, never idle wobble.
- Reading holds: 0.2 s a word for 2 to 5 words, floor 0.45 s; 1.7 to 2 s for 6 to 8 words. Count ups last about 1 s. Anything important stays about 1.5 s.
- Cursor only where it truly clicks: about 5% of frame width inside a mock, enters from off frame on an arc, tip lands on the target centre, click is scale 0.84 in 0.1 s and back in 0.22 s with the target at 0.94, and every click starts the next beat on the same frame. It can hesitate like a person.
- Camera: push 100 to 106% across a shot, ease in and out. Zoom to the clicked thing (about 130%) and ease back. Pull back to reveal the payoff.

### 06 Edit: Editor

- Use only the transitions in the brief, repeated in the brief's order. Two or three kinds per film.
- Cut on motion: A accelerates into the cut, B's first frame is already moving. Mirror the eases across the cut (power4.in out, power4.out in) so speed matches.
- Cut the curve: about 12% of frame travel, about 0.6 s, blur 10 px for text and 18 to 20 px full frame, blur the scene wrapper never its children.
- Zoom through: A 1 to 1.2 in 0.2 s, cut, B 0.75 to 1 in 0.5 s. If A grows, B also grows. Never two texts visible at once.
- Whip pan: 8 f median, the cut hidden in the blur. Rack cut: peak blur 8 to 12 px, at most once every 8 s. Flash: 1 to 2 f, never stacked with a negative, at most 3 flashes in any second.
- Pace: check cut length against the format's pace line. No still stretch over 0.6 s except the end card. 0.3 to 0.75 s of stillness before the climax. End hold 0.6 to 1.4 s with one thing still alive; the last shot is under 25% of the film.
- Beat grid: frames per beat = fps x 60 / BPM, computed from the beat index, never accumulated. Cut on the grid or on words, never both. Change the pattern every 4 or 8 bars.
- Cutdowns are recomposed from the timeline with their own layout and type sizes, never cropped. 9:16 text sits between y 360 and 1420 and stays out of the right 120 px.

### 07 Sound: Sound designer

- A cue list from the storyboard. One sound per kind of moment, never the same sound on consecutive cuts, a whoosh peaking on the cut (starting 2 to 4 f early), impacts and clicks 0 to 1 f after the picture, a riser ending on its hit, 0.2 to 0.5 s of clear air before the biggest move.
- Levels: music bed -20 LUFS, master -18 LUFS integrated, true peak under -1 dBTP. Duck the music 9 dB under voice (80 ms in, 300 ms out). SFX 3 to 4 dB over the bed in band.
- Sources: the person's own track or a licensed one, CC0 or credited CC BY effects. Never rip a song, never synthesise music.
- Measure on the exported file: `ffmpeg -i out.mp4 -af ebur128=peak=true -f null -`. Use `sound-effects` if installed.

### 08 Finish: Colourist

- Grade, then texture with real blend modes: grain 3 to 8% overlay at 24 fps seeded, paper on multiply, light sweeps on screen from an edge, edge vignette only and never on white or negative frames.
- Flash safety: no more than 3 full frame flashes in any second, no saturated red flashes.
- Export: H.264 high, yuv420p, bt709, tv range, AAC, `+faststart`. Alpha versions as ProRes 4444 for idents. GIF loops with the seam measured at 0 px.
- Interactive player when asked: one HTML file with play, scrub and a captions toggle off by default.

### 09 QA: Critic

A fresh agent that did not build the film. It gets the files, not the builder's opinion.

- Contact sheet every 0.5 s, a strip of frames 0.2 s either side of every cut, a phone sheet at 360 px wide, 2x crops of all type.
- Fail and fix on any of these: a centre or radial glow; any opacity fade entrance or crossfade between scenes; eyebrow tags or filler micro text; an em or en dash or a banned word; printed narration; anything spilling its container or the safe zone; type held shorter than its reading time; a fallback font on any frame; two texts visible through a zoom; the same sound on consecutive cuts; music louder than -20 LUFS or a master off -18; more than 3 flashes in a second; a number with no source; an invented logo or UI.
- Score 1 to 10 for hook, clarity, motion craft, type, colour, sound, pace and ending. Ship only when all are 8 or more. Write `REVIEW.md` with what was checked and what was not.

**Gate B.** One live https link (interactive player or a page with the MP4s), byte verified (`curl` the live file, `cmp` against local), with the version stamped on screen. Then stop and wait for notes.

### 10 Library: Librarian

- Any move worth reusing becomes a numbered component (MG001 and up) with its numbers and a still.
- Every version stays on disk.

## Notes after a render

A message that starts "Notes on the latest render" comes from the Notes tab. Copy the current version to the next number, fix only the named notes at their timecodes, keep scale, positions and timing of everything else, render stills at each changed moment, check them at 2x, and send the new live link.

## Never

- Radial or centre glow, inner glow, bloom haze, lens flares, neon glow.
- Opacity fade entrances or exits, crossfades between scenes. Things rise, slide, scale from origin or mask wipe.
- Eyebrow tags, body tags, filler micro text, "Example data" labels.
- Em or en dashes in any copy.
- Underlines for emphasis.
- Glitch as a transition.
- bounce.out and elastic eases.
- A whoosh on every cut, the same sound twice in a row.
- Captions that print the narration (captions only on talking head footage, one system, one accent).
- Circle iris as a default wipe.
- Glass panels, UI floating on a gradient void with drop shadows, stat slides.
- Synthesised music, ripped songs, time stretched voices.
- Paid generation (images, video, voice, music) without a yes that names the tool, the model and the credit cost.

## References

- `references/library.md`: every format recipe (pace, storyboard, motion, look, sound, who to study) and every option with its numbers. Generated from the Edits tool's data, so it matches what the person picked.
- `references/edit-styles.md`: field guide to 12 edit styles and 21 cuts and transitions, with exemplars, frame counts and how each is built in code. Tagged [V] verified or [WD] working default.
- `references/craft.md`: motion principles as numbers (After Effects Easy Ease is cubic-bezier(0.333, 0, 0.667, 1), Apple and Material springs), 28 typefaces with licences, palettes, grading, all 16 blend modes in CSS, canvas and GLSL, textures, 3D in three.js, library licences.
- `references/local-skills.md` (only on machines that have it): which installed skill to load at which stage, their numbers, and where their defaults clash with the house rules.
